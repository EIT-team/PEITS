// -*- tab-width: 4; indent-tabs-mode: nil; c-basic-offset: 2 -*-
// vi: set et ts=4 sw=2 sts=2:
#ifndef DUNE_MPITRAITS_HH
#warning dune/common/mpitraits.hh is deprecated, please use dune/common/parallel/mpitraits.hh
#include "parallel/mpitraits.hh"
#endif
