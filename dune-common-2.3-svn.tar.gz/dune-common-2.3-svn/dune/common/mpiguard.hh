// -*- tab-width: 4; indent-tabs-mode: nil; c-basic-offset: 2 -*-
// vi: set et ts=4 sw=2 sts=2:
#ifndef DUNE_COMMON_MPIGUARD_HH
#warning dune/common/mpiguard.hh is deprecated, please use dune/common/parallel/mpiguard.hh
#include "parallel/mpiguard.hh"
#endif
