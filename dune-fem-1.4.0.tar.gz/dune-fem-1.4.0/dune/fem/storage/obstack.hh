/**************************************************************************
 
  The dune-fem module is a module of DUNE (see www.dune-project.org).
  It is based on the dune-grid interface library 
  extending the grid interface by a number of discretization algorithms
  for solving non-linear systems of partial differential equations.

  Copyright (C) 2003 - 2013 Robert Kloefkorn
  Copyright (C) 2003 - 2010 Mario Ohlberger 
  Copyright (C) 2004 - 2013 Andreas Dedner
  Copyright (C) 2005        Adrian Burri
  Copyright (C) 2005 - 2012 Mirko Kraenkel
  Copyright (C) 2006 - 2013 Christoph Gersbacher
  Copyright (C) 2006 - 2013 Martin Nolte
  Copyright (C) 2011 - 2013 Tobias Malkmus

  The dune-fem module is free software; you can redistribute it and/or 
  modify it under the terms of the GNU General Public License as 
  published by the Free Software Foundation; either version 2 of 
  the License, or (at your option) any later version.

  The dune-fem module is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along
  with this program; if not, write to the Free Software Foundation, Inc.,
  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 
**************************************************************************/
#ifndef DUNE_FEM_OBJECTSTACK_HH
#define DUNE_FEM_OBJECTSTACK_HH

#include <obstack.h>
#include <iostream>

#include <dune/fem/storage/arrayallocator.hh>


namespace Dune
{

  namespace Fem
  {

#define obstack_chunk_alloc &std::malloc
#define obstack_chunk_free &std::free
#define obstack_alloc_failed_handler = &ObStack::allocFailed;

    class ObStack
    {
    private:
      typedef ObStack ThisType;

    protected:
      struct obstack info_;

    public:
      inline ObStack ()
      {
        obstack_init( &info_ );
        // align on 16 byte boundaries
        obstack_alignment_mask( &info_ ) = 15;
      }

      inline ObStack ( unsigned int chunkSize )
      {
        obstack_init( &info_ );
        obstack_chunk_size( &info_ ) = chunkSize;
        // align on 16 byte boundaries
        obstack_alignment_mask( &info_ ) = 15;
      }

      inline ~ObStack ()
      {
        // free the entire object stack
        obstack_free( &info_, 0 );
      }
      
      inline void *allocate ( unsigned int size )
      {
        return obstack_alloc( &info_, size );
      }

      inline void free ( void *ptr )
      {
        if( ptr != 0 )
          obstack_free( &info_, ptr );
      }

    private:
      static inline void allocFailed ()
      {
        DUNE_THROW( OutOfMemoryError, "ObStack went out of memory." );
      }
    };

    #undef obstack_chunk_alloc
    #undef obstack_chunk_free
    #undef obstack_alloc_failed_handler



    template< class Element >
    class ObStackArrayAllocator;



    template< class Element >
    struct ObStackArrayAllocatorTraits
    {
      typedef Element ElementType;

      typedef Element *ElementPtrType;

      typedef ObStackArrayAllocator< ElementType > ArrayAllocatorType;
    };



    template< class Element >
    class ObStackArrayAllocator
    : public ArrayAllocatorDefault< ObStackArrayAllocatorTraits< Element > >
    {
    public:
      typedef Element ElementType;

      typedef ObStackArrayAllocatorTraits< ElementType > TraitsType;

    private:
      typedef ObStackArrayAllocator< ElementType > ThisType;
      typedef ArrayAllocatorDefault< TraitsType > BaseType;

    public:
      typedef typename TraitsType :: ElementPtrType ElementPtrType;

    public:
      inline void allocate ( unsigned int size,
                             ElementPtrType &array ) const
      {
        if( size > 0 )
        {
          array = (ElementPtrType)obStack().allocate( size * sizeof( ElementType ) );
          assert( array != 0 );
        }
        else
          array = 0;
      }
    
      inline void free ( ElementPtrType &array ) const
      {
        if( array != 0 )
        {
          obStack().free( array );
          array = 0;
        }
      }

    private:
      static inline ObStack& obStack ()
      {
        static ObStack stack( 2 << 20 );
        return stack;
      }
    };

  } // namespace Fem
   
} // namespace Dune

#endif // #ifndef DUNE_FEM_OBJECTSTACK_HH
