/**************************************************************************
 
  The dune-fem module is a module of DUNE (see www.dune-project.org).
  It is based on the dune-grid interface library 
  extending the grid interface by a number of discretization algorithms
  for solving non-linear systems of partial differential equations.

  Copyright (C) 2003 - 2013 Robert Kloefkorn
  Copyright (C) 2003 - 2010 Mario Ohlberger 
  Copyright (C) 2004 - 2013 Andreas Dedner
  Copyright (C) 2005        Adrian Burri
  Copyright (C) 2005 - 2012 Mirko Kraenkel
  Copyright (C) 2006 - 2013 Christoph Gersbacher
  Copyright (C) 2006 - 2013 Martin Nolte
  Copyright (C) 2011 - 2013 Tobias Malkmus

  The dune-fem module is free software; you can redistribute it and/or 
  modify it under the terms of the GNU General Public License as 
  published by the Free Software Foundation; either version 2 of 
  the License, or (at your option) any later version.

  The dune-fem module is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along
  with this program; if not, write to the Free Software Foundation, Inc.,
  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 
**************************************************************************/
#ifndef DUNE_FEM_BLASVECTOR_HH
#define DUNE_FEM_BLASVECTOR_HH

#include <iostream>
#include <cassert>
#include <cmath>
#include <vector>

#include <dune/fem/solver/pardg.hh>
#include <dune/fem/storage/vector.hh>

namespace Dune
{

  namespace Fem 
  {

    class BlasVector
    : public  VectorDefault< double, BlasVector >
    {
      bool owner_;

    public:
      typedef double FieldType;
      BlasVector(unsigned int n);
      BlasVector(unsigned int n, const double *a);
      BlasVector(const BlasVector &v); // copy constructor
      ~BlasVector();
      
      // element access
      double& operator[](unsigned int i);
      double operator[](unsigned int i) const;

      // assignment operators
      BlasVector& operator=(const BlasVector& v);
      BlasVector& operator+=(const BlasVector& v);
      BlasVector& operator-=(const BlasVector& v);
      BlasVector& operator*=(double alpha);
      BlasVector& operator=(double alpha);

      unsigned int size() const;

      double* leakPointer() {
        return data;
      }
      const double* leakPointer() const {
        return data;
      }
      void reserve(unsigned int newSize) {
        assert(owner_);
        if (newSize<n) return;
        unsigned int useSize = newSize;
        double* newData = new double[useSize];
        if (!data) data = newData;
        else {
          double* oldData;
          PARDG::cblas_dcopy(n,data,1,newData,1);
          data = newData;
          delete [] oldData;
        }
        totalSize = useSize;

      }
      void resize(unsigned int newSize) {
        assert(owner_);
        if (newSize>totalSize) 
          reserve(newSize);
        else 
          n = newSize;
      }
    private:
      unsigned int n,totalSize;
      double *data;
    };


    // class BlasVector inline implementation

    inline 
    BlasVector::BlasVector(unsigned int pn) : owner_(true),
    n(pn), totalSize(pn), data(new double[pn])
    {
      assert(data);
      PARDG::dset(n, 0.0, data, 1);
    }


    inline 
    BlasVector::BlasVector(unsigned int pn, const double *a) : owner_(false),
    n(pn), totalSize(pn), data(const_cast<double*>(a))
    {
      assert(data);
      // PARDG::cblas_dcopy(n, a, 1, data, 1);
    }


    inline 
    BlasVector::BlasVector(const BlasVector &v) : owner_(true),
    n(v.n), totalSize(v.n), data(new double[v.n])
    {
      assert(data);
      PARDG::cblas_dcopy(n, v.data, 1, data, 1);
    }


    inline 
    BlasVector::~BlasVector()
    {
      if (owner_)
        delete[] data;
    }

    inline
    double& BlasVector::operator[](unsigned int i)
    {
      assert(i<n);
      return data[i];
    }


    inline
    double BlasVector::operator[](unsigned int i) const
    {
      assert(i>=0 && i<n);
      return data[i];
    }


    inline
    BlasVector& BlasVector::operator=(const BlasVector& v)
    {
      assert(n==v.n);
      PARDG::cblas_dcopy(n, v.data, 1, data, 1);
      return *this;
    }


    inline
    BlasVector& BlasVector::operator+=(const BlasVector& v)
    {
      assert(n==v.n);
      PARDG::cblas_daxpy(n, 1.0, v.data, 1, data, 1);
      return *this;
    }


    inline
    BlasVector& BlasVector::operator-=(const BlasVector& v)
    {
      assert(n==v.n);
      PARDG::cblas_daxpy(n, -1.0, v.data, 1, data, 1);
      return *this;
    }


    inline
    BlasVector& BlasVector::operator*=(double alpha)
    {
      PARDG::cblas_dscal(n, alpha, data, 1);
      return *this;
    }


    inline
    BlasVector& BlasVector::operator=(double alpha)
    {
      PARDG::dset(n, alpha, data, 1);
      return *this;
    }


    inline
    unsigned int BlasVector::size() const
    {
      return n;
    }

  } // namespace Fem  

} // namespace Dune

#endif // #ifndef DUNE_FEM_BLASVECTOR_HH
