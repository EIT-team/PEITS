/**************************************************************************
 
  The dune-fem module is a module of DUNE (see www.dune-project.org).
  It is based on the dune-grid interface library 
  extending the grid interface by a number of discretization algorithms
  for solving non-linear systems of partial differential equations.

  Copyright (C) 2003 - 2013 Robert Kloefkorn
  Copyright (C) 2003 - 2010 Mario Ohlberger 
  Copyright (C) 2004 - 2013 Andreas Dedner
  Copyright (C) 2005        Adrian Burri
  Copyright (C) 2005 - 2012 Mirko Kraenkel
  Copyright (C) 2006 - 2013 Christoph Gersbacher
  Copyright (C) 2006 - 2013 Martin Nolte
  Copyright (C) 2011 - 2013 Tobias Malkmus

  The dune-fem module is free software; you can redistribute it and/or 
  modify it under the terms of the GNU General Public License as 
  published by the Free Software Foundation; either version 2 of 
  the License, or (at your option) any later version.

  The dune-fem module is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along
  with this program; if not, write to the Free Software Foundation, Inc.,
  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 
**************************************************************************/
#ifndef DUNE_FEM_EMPTYINDEXSET_HH
#define DUNE_FEM_EMPTYINDEXSET_HH

//- system includes 
#include <iostream>
#include <string> 
#include <rpc/types.h>
#include <rpc/xdr.h>
#include <cassert>

#include <dune/common/exceptions.hh>

/** @file
 @brief Provides default empty index set class for persistent index sets. 
*/

namespace Dune
{

  namespace Fem 
  { 

    /*!
      The EmptyIndexSet implements all additional method of a DUNE fem index set with 
      an empty default implementation. 
    */
    class EmptyIndexSet
    {
      // dummy value 
      enum { myType = -1 };
    public:  
      //! return false mean the no memory has to be allocated 
      //! and no compress of date has to be done 
      bool compress () { 
        return false; 
      }

      //! return true if the index set is consecutive 
      bool consecutive () const
      {
        return false;
      }

      //! return true if the index set is persistent 
      bool persistent () const
      {
        return false;
      }

      //! do nothing here, because fathers index should already exist 
      template< class EntityType >
      void insertEntity ( const EntityType &entity )
      {}

      //! do nothing here, because fathers index should already exist 
      template< class EntityType >
      void removeEntity ( const EntityType &entity )
      {}

      //! nothing to do here 
      void resize ()
      {}

      //! no extra memory for restriction is needed
      int additionalSizeEstimate () const
      {
        return 0;
      }

      static int type ()
      {
        return myType;
      }

      //! we have no old size 
      int numberOfHoles ( const int codim ) const
      {
        return 0;
      }
      
      //! return old index, for dof manager only 
      int oldIndex ( const int hole, const int codim ) const
      {
        return 0;
      }
      
      //! return new index, for dof manager only 
      int newIndex ( const int hole, const int codim ) const
      {
        return 0;
      }
      
      //! write index set to xdr file 
      bool write_xdr ( const std::string &filename, int timestep )
      {
        DUNE_THROW(Dune::NotImplemented,"write_xdr is deprecated");
        return false;
      }
      
      //! read index set to xdr file 
      bool read_xdr ( const std::string &filename, int timestep )
      {
        DUNE_THROW(Dune::NotImplemented,"read_xdr is deprecated");
        return false;
      }
    };

  }  // namespace Fem 

} // namespace Dune 
#endif // #ifndef DUNE_FEM_EMPTYINDEXSET_HH
