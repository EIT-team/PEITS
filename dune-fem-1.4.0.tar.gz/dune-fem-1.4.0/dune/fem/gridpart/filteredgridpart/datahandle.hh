/**************************************************************************
 
  The dune-fem module is a module of DUNE (see www.dune-project.org).
  It is based on the dune-grid interface library 
  extending the grid interface by a number of discretization algorithms
  for solving non-linear systems of partial differential equations.

  Copyright (C) 2003 - 2013 Robert Kloefkorn
  Copyright (C) 2003 - 2010 Mario Ohlberger 
  Copyright (C) 2004 - 2013 Andreas Dedner
  Copyright (C) 2005        Adrian Burri
  Copyright (C) 2005 - 2012 Mirko Kraenkel
  Copyright (C) 2006 - 2013 Christoph Gersbacher
  Copyright (C) 2006 - 2013 Martin Nolte
  Copyright (C) 2011 - 2013 Tobias Malkmus

  The dune-fem module is free software; you can redistribute it and/or 
  modify it under the terms of the GNU General Public License as 
  published by the Free Software Foundation; either version 2 of 
  the License, or (at your option) any later version.

  The dune-fem module is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along
  with this program; if not, write to the Free Software Foundation, Inc.,
  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 
**************************************************************************/
#ifndef DUNE_FEM_GRIDPART_FILTEREDGRIDPART_DATAHANDLE_HH
#define DUNE_FEM_GRIDPART_FILTEREDGRIDPART_DATAHANDLE_HH

//- dune-common includes
#include <dune/common/typetraits.hh>

//- dune-grid includes
#include <dune/grid/common/datahandleif.hh>


namespace Dune
{

  namespace Fem
  {

    // Forward declaration
    // -------------------

    template< class HostGridPartImp, class FilterImp, bool useFilteredIndexSet >
    class FilteredGridPart;



    // FilteredGridPartDataHandle
    // --------------------------

    template< class WrappedHandle, class GridPart >
    class FilteredGridPartDataHandle
    : public CommDataHandleIF< FilteredGridPartDataHandle< WrappedHandle, GridPart >, typename WrappedHandle::DataType >
    {
      typedef CommDataHandleIF< FilteredGridPartDataHandle< WrappedHandle, GridPart >,
              typename WrappedHandle::DataType > BaseType;
      typedef GridPart GridPartType;
      typedef typename remove_const< GridPartType >::type::Traits Traits;

    public:
      FilteredGridPartDataHandle ( WrappedHandle &dataHandle, const GridPart &gridPart )
      : gridPart_( gridPart ),
        wrappedHandle_( dataHandle )
      { } 

      bool contains ( int dim, int codim ) const
      {
        return wrappedHandle_.contains( dim, codim );
      }

      bool fixedsize ( int dim, int codim ) const
      {
        return false; 
      }

      template< class HostEntity >
      size_t size ( const HostEntity &hostEntity ) const
      {
        if( gridPart().contains( hostEntity ) )          
          return wrappedHandle_.size( hostEntity );
        else
          return 0;
      }

      template< class MessageBuffer, class HostEntity >
      void gather ( MessageBuffer &buffer, const HostEntity &hostEntity ) const
      {
        if( gridPart().contains( hostEntity ) )          
          wrappedHandle_.gather( buffer, hostEntity );
      }

      template< class MessageBuffer, class HostEntity >
      void scatter ( MessageBuffer &buffer, const HostEntity &hostEntity, size_t size )
      {
        if( gridPart().contains( hostEntity ) )          
          wrappedHandle_.scatter( buffer, hostEntity, size );
        else
        {
          typename BaseType::DataType tmp;
          for (size_t i=0;i<size;++i) 
            buffer.read(tmp);
        }
      }

    protected:
      const GridPart &gridPart () const
      {
        return gridPart_;
      }

    private:
      const GridPart &gridPart_;
      WrappedHandle &wrappedHandle_;
    };

  }  // namespace Fem

}  // namespace Dune

#endif // #ifndef DUNE_FEM_GRIDPART_FILTEREDGRIDPART_DATAHANDLE_HH
