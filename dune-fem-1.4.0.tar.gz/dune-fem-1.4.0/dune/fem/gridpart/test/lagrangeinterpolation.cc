/**************************************************************************
 
  The dune-fem module is a module of DUNE (see www.dune-project.org).
  It is based on the dune-grid interface library 
  extending the grid interface by a number of discretization algorithms
  for solving non-linear systems of partial differential equations.

  Copyright (C) 2003 - 2013 Robert Kloefkorn
  Copyright (C) 2003 - 2010 Mario Ohlberger 
  Copyright (C) 2004 - 2013 Andreas Dedner
  Copyright (C) 2005        Adrian Burri
  Copyright (C) 2005 - 2012 Mirko Kraenkel
  Copyright (C) 2006 - 2013 Christoph Gersbacher
  Copyright (C) 2006 - 2013 Martin Nolte
  Copyright (C) 2011 - 2013 Tobias Malkmus

  The dune-fem module is free software; you can redistribute it and/or 
  modify it under the terms of the GNU General Public License as 
  published by the Free Software Foundation; either version 2 of 
  the License, or (at your option) any later version.

  The dune-fem module is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along
  with this program; if not, write to the Free Software Foundation, Inc.,
  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 
**************************************************************************/
#if defined ALUGRID_CUBE || defined ALUGRID_SIMPLEX 
#if GRIDDIM == 3 
#define COMPILE_TEST 
#endif
#endif

#include <config.h>
#include <iostream>

#include <dune/fem/gridpart/adaptiveleafgridpart.hh>
#include <dune/fem/gridpart/filteredgridpart.hh>
#include <dune/fem/gridpart/filter/radialfilter.hh>
#include <dune/fem/gridpart/filter/basicfilterwrapper.hh>

#include <dune/fem/misc/double.hh>
#include <dune/fem/space/lagrange.hh>
#include <dune/fem/function/adaptivefunction.hh>
#include <dune/fem/operator/lagrangeinterpolation.hh>
#include <dune/fem/io/streams/xdrstreams.hh>
#include <dune/fem/io/streams/asciistreams.hh>
#include <dune/fem/io/streams/virtualstreams.hh>
#include <dune/fem/io/file/vtkio.hh>

#include <dune/fem/test/exactsolution.hh>

using namespace Dune;

// polynom approximation order of quadratures, 
// at least poolynom order of basis functions 
#ifdef POLORDER
  const int polOrder = POLORDER;
#else
  const int polOrder = 1;
#endif

#ifdef COMPILE_TEST
#include <dune/grid/alugrid.hh>
#include <dune/grid/io/file/dgfparser/dgfalu.hh>
  typedef Dune :: GridSelector :: GridType MyGridType;

  // typedef AdaptiveLeafGridPart< MyGridType > HostGridPartType;
  typedef Fem::LeafGridPart< MyGridType > HostGridPartType;
  typedef Fem::RadialFilter< MyGridType::ctype, MyGridType::dimensionworld > BasicFilterType;
  typedef Fem::BasicFilterWrapper< HostGridPartType, BasicFilterType > FilterType;
  typedef Fem::FilteredGridPart< HostGridPartType, FilterType, true > GridPartType;
  // typedef AdaptiveLeafGridPart< MyGridType > GridPartType;

  typedef Fem::FunctionSpace< double, double, MyGridType::dimensionworld, 1 > FunctionSpaceType;

  typedef Fem::LagrangeDiscreteFunctionSpace< FunctionSpaceType, GridPartType, polOrder >
    DiscreteFunctionSpaceType;

  typedef Fem::AdaptiveDiscreteFunction< DiscreteFunctionSpaceType > DiscreteFunctionType;

  typedef Fem::ExactSolution< FunctionSpaceType > ExactSolutionType;



  void writeOut ( Fem::VirtualOutStream out, const DiscreteFunctionType &solution )
  {
    out << solution;
    out.flush();
  }

  void readBack ( Fem::VirtualInStream in, DiscreteFunctionType &solution )
  {
    solution.clear();
    in >> solution;
  }

  template <class HGridType>
  class TestGrid
  {
    typedef TestGrid<HGridType> ThisType;

  protected:
    TestGrid ()
    : gridptr_( macroGridName() )
    {
      gridptr_->loadBalance();
    }

  private:
    TestGrid ( const ThisType & );

    ThisType &operator= ( const ThisType & );

  public:
    static ThisType &instance ()
    {
      static ThisType staticInstance;
      return staticInstance;
    }

    static HGridType &grid ()
    {
      return *(instance().gridptr_);
    }

    static int refineStepsForHalf ()
    {
      return DGFGridInfo< HGridType >::refineStepsForHalf();
    }

  protected:
    static std::string macroGridName ()
    {
      std::ostringstream s;
      s << HGridType::dimension << "dgrid.dgf";
      return s.str();
    }

    GridPtr< HGridType > gridptr_;
  };


  int main(int argc, char ** argv) 
  {
    Dune::Fem::MPIManager :: initialize( argc, argv );
    try
    {
      MyGridType &grid = TestGrid<MyGridType> :: grid();
      const int step = TestGrid<MyGridType> :: refineStepsForHalf();
      grid.globalRefine( 2*step );
      HostGridPartType hostGridPart (grid );
      BasicFilterType::GlobalCoordinateType center( 0 );
      BasicFilterType basicFilter( center, .25 );
      FilterType filter( hostGridPart, basicFilter );
      GridPartType gridPart( hostGridPart, filter );
      // GridPartType gridPart ( grid );


      DiscreteFunctionSpaceType discreteFunctionSpace( gridPart );
      ExactSolutionType f;
      DiscreteFunctionType solution( "solution", discreteFunctionSpace );
      solution.clear();

      std :: cout << "maxDofs = " << discreteFunctionSpace.mapper().maxNumDofs() << std :: endl;

      //! perform Lagrange interpolation
      Fem::LagrangeInterpolation< ExactSolutionType, DiscreteFunctionType >
        :: interpolateFunction( f, solution );
      solution.communicate();

      // output to vtk file
      Fem::VTKIO<GridPartType> vtkWriter(gridPart);
      vtkWriter.addVertexData(solution);
      vtkWriter.pwrite("vtxprojection",
                        Fem::Parameter::commonOutputPath().c_str(),"",
                        Dune::VTK::ascii);
      return 0;
    }
    catch( Exception e )
    {
      std :: cerr << e.what() << std :: endl;
      return 1;
    }
  }
#else 
  // no ALUGrid, no test 
  int main(int argc, char ** argv) 
  {
    return 0;
  }
#endif
