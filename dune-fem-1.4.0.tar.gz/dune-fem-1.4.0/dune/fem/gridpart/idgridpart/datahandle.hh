/**************************************************************************
 
  The dune-fem module is a module of DUNE (see www.dune-project.org).
  It is based on the dune-grid interface library 
  extending the grid interface by a number of discretization algorithms
  for solving non-linear systems of partial differential equations.

  Copyright (C) 2003 - 2013 Robert Kloefkorn
  Copyright (C) 2003 - 2010 Mario Ohlberger 
  Copyright (C) 2004 - 2013 Andreas Dedner
  Copyright (C) 2005        Adrian Burri
  Copyright (C) 2005 - 2012 Mirko Kraenkel
  Copyright (C) 2006 - 2013 Christoph Gersbacher
  Copyright (C) 2006 - 2013 Martin Nolte
  Copyright (C) 2011 - 2013 Tobias Malkmus

  The dune-fem module is free software; you can redistribute it and/or 
  modify it under the terms of the GNU General Public License as 
  published by the Free Software Foundation; either version 2 of 
  the License, or (at your option) any later version.

  The dune-fem module is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along
  with this program; if not, write to the Free Software Foundation, Inc.,
  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 
**************************************************************************/
#ifndef DUNE_FEM_GRIDPART_IDGRIDPART_DATAHANDLE_HH
#define DUNE_FEM_GRIDPART_IDGRIDPART_DATAHANDLE_HH

#include <dune/common/typetraits.hh>

#include <dune/grid/common/datahandleif.hh>

#include <dune/fem/gridpart/idgridpart/entity.hh>

namespace Dune
{

  namespace Fem
  {

    // IdDataHandle
    // ------------

    template< class GridFamily, class WrappedHandle >
    class IdDataHandle
    : public CommDataHandleIF< IdDataHandle< GridFamily, WrappedHandle >, typename WrappedHandle::DataType >
    {
      typedef typename remove_const< GridFamily >::type::Traits Traits;

      template< class HostEntity >
      class EntityProxy;

    public:
      IdDataHandle ( WrappedHandle &handle )
      : wrappedHandle_( handle )
      {}

      bool contains ( int dim, int codim ) const
      {
        return wrappedHandle_.contains( dim, codim );
      }

      bool fixedsize ( int dim, int codim ) const
      {
        return wrappedHandle_.fixedsize( dim, codim );
      }

      template< class HostEntity >
      size_t size ( const HostEntity &hostEntity ) const
      {
        EntityProxy< HostEntity > proxy( hostEntity );
        return wrappedHandle_.size( *proxy );
      }

      template< class MessageBuffer, class HostEntity >
      void gather ( MessageBuffer &buffer, const HostEntity &hostEntity ) const
      {
        EntityProxy< HostEntity > proxy( hostEntity );
        wrappedHandle_.gather( buffer, *proxy );
      }

      template< class MessageBuffer, class HostEntity >
      void scatter ( MessageBuffer &buffer, const HostEntity &hostEntity, size_t size )
      {
        EntityProxy< HostEntity > proxy( hostEntity );
        wrappedHandle_.scatter( buffer, *proxy, size );
      }

    private:
      WrappedHandle &wrappedHandle_;
    };



    template< class GridFamily, class WrappedHandle >
    template< class HostEntity >
    struct IdDataHandle< GridFamily, WrappedHandle >::EntityProxy
    {
      static const int dimension = HostEntity::dimension;
      static const int codimension = HostEntity::codimension;
      
      typedef Dune::Entity< codimension, dimension, const GridFamily, IdEntity > Entity;

    private:
      typedef IdEntity< codimension, dimension, const GridFamily > EntityImpl;

    public:
      EntityProxy ( const HostEntity &hostEntity )
      : entity_( EntityImpl( hostEntity ) )
      {}

      const Entity &operator* () const
      {
        return entity_;
      }

    private:
      Entity entity_;
    };

  } // namespace Fem

} // namespace Dune

#endif // #ifndef DUNE_FEM_GRIDPART_IDGRIDPART_DATAHANDLE_HH
