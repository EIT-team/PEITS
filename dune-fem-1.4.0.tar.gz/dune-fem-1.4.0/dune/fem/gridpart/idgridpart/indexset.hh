/**************************************************************************
 
  The dune-fem module is a module of DUNE (see www.dune-project.org).
  It is based on the dune-grid interface library 
  extending the grid interface by a number of discretization algorithms
  for solving non-linear systems of partial differential equations.

  Copyright (C) 2003 - 2013 Robert Kloefkorn
  Copyright (C) 2003 - 2010 Mario Ohlberger 
  Copyright (C) 2004 - 2013 Andreas Dedner
  Copyright (C) 2005        Adrian Burri
  Copyright (C) 2005 - 2012 Mirko Kraenkel
  Copyright (C) 2006 - 2013 Christoph Gersbacher
  Copyright (C) 2006 - 2013 Martin Nolte
  Copyright (C) 2011 - 2013 Tobias Malkmus

  The dune-fem module is free software; you can redistribute it and/or 
  modify it under the terms of the GNU General Public License as 
  published by the Free Software Foundation; either version 2 of 
  the License, or (at your option) any later version.

  The dune-fem module is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along
  with this program; if not, write to the Free Software Foundation, Inc.,
  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 
**************************************************************************/
#ifndef DUNE_FEM_GRIDPART_IDGRIDPART_INDEXSET_HH
#define DUNE_FEM_GRIDPART_IDGRIDPART_INDEXSET_HH

#include <vector>

#include <dune/common/typetraits.hh>

#include <dune/grid/common/gridenums.hh>
#include <dune/grid/common/indexidset.hh>
#include <dune/fem/gridpart/dunefemindexsets.hh>

namespace Dune
{

  namespace Fem
  {

    // IdIndexSet
    // ----------

    template< class HostIndexSet >
    class IdIndexSet
      : public PersistentIndexSetInterface 
    {
      typedef IdIndexSet< HostIndexSet > This;

    public:
      typedef typename HostIndexSet::IndexType IndexType;

      explicit IdIndexSet ( const HostIndexSet &hostIndexSet )
      : hostIndexSet_( const_cast<HostIndexSet *> (&hostIndexSet) )
      {}

      int size ( const GeometryType &type ) const { return hostIndexSet().size( type ); }
      int size ( const int codim ) const { return hostIndexSet().size( codim ); }

      template< class Entity >
      int index ( const Entity &entity ) const
      {
        return hostIndexSet().index( entity.impl().hostEntity() );
      }

      template< class Entity >
      int subIndex ( const Entity &entity, const int local, const unsigned int codim ) const
      {
        return hostIndexSet().subIndex( entity.impl().hostEntity(), local, codim );
      }

      const std::vector< GeometryType > &geomTypes ( const int codim ) const
      {
        return hostIndexSet().geomTypes( codim );
      }

      template< class Entity >
      bool contains ( const Entity &entity ) const
      {
        return hostIndexSet().contains( entity.impl().hostEntity() );
      }

      bool consecutive () const { return hostIndexSet().consecutive(); }
      bool persistent () const { return hostIndexSet().persistent(); }

      void compress () 
      { 
        assert( consecutive() );
        hostIndexSet().compress(); 
      }

      void addBackupRestore() 
      { 
        if( persistent() ) 
        {
          // this cast should work, since we have a persistent index set 
          ((PersistentIndexSetInterface &) hostIndexSet()).addBackupRestore();
        }
      }
      void removeBackupRestore() 
      { 
        if( persistent() ) 
        {
          // this cast should work, since we have a persistent index set 
          ((PersistentIndexSetInterface &) hostIndexSet()).removeBackupRestore();
        }
      }

      int numberOfHoles ( const int codim ) const { return hostIndexSet().numberOfHoles( codim ); }

      int oldIndex ( const int hole, const int codim ) const
      {
        return hostIndexSet().oldIndex( hole, codim );
      }

      int newIndex ( const int hole, const int codim ) const
      {
        return hostIndexSet().newIndex( hole, codim );
      }

      std::string name () const { return "IdGridPart::IndexSet" ; }

    private:
      const HostIndexSet &hostIndexSet () const
      {
        assert( hostIndexSet_ );
        return *hostIndexSet_;
      }

      HostIndexSet &hostIndexSet () 
      {
        assert( hostIndexSet_ );
        return *hostIndexSet_;
      }

      HostIndexSet *hostIndexSet_;
    };

  } // namespace Fem

} // namespace Dune

#endif // #ifndef DUNE_FEM_GRIDPART_IDGRIDPART_INDEXSET_HH
