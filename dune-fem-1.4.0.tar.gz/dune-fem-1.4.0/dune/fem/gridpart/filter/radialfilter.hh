/**************************************************************************
 
  The dune-fem module is a module of DUNE (see www.dune-project.org).
  It is based on the dune-grid interface library 
  extending the grid interface by a number of discretization algorithms
  for solving non-linear systems of partial differential equations.

  Copyright (C) 2003 - 2013 Robert Kloefkorn
  Copyright (C) 2003 - 2010 Mario Ohlberger 
  Copyright (C) 2004 - 2013 Andreas Dedner
  Copyright (C) 2005        Adrian Burri
  Copyright (C) 2005 - 2012 Mirko Kraenkel
  Copyright (C) 2006 - 2013 Christoph Gersbacher
  Copyright (C) 2006 - 2013 Martin Nolte
  Copyright (C) 2011 - 2013 Tobias Malkmus

  The dune-fem module is free software; you can redistribute it and/or 
  modify it under the terms of the GNU General Public License as 
  published by the Free Software Foundation; either version 2 of 
  the License, or (at your option) any later version.

  The dune-fem module is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along
  with this program; if not, write to the Free Software Foundation, Inc.,
  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 
**************************************************************************/
#ifndef DUNE_FEM_GRIDPART_FILTER_RADIALFILTER_HH
#define DUNE_FEM_GRIDPART_FILTER_RADIALFILTER_HH

// dune-common includes
#include <dune/common/fvector.hh>

namespace Dune
{

  namespace Fem
  {

    // RadialFilter
    // ------------

    /**! \brief example implementation; given center x and radius r, 
     *          filter is characteristic function of clos B_r( x )
     */
    template < typename ct, int dimw >
    class RadialFilter
    {
    public:
      //! \brief export template parameter
      typedef ct ctype;

      //! \brief export dimension
      static const int dimensionworld = dimw;

      //! \brief coordinate type
      typedef Dune::FieldVector< ct, dimw > GlobalCoordinateType; 

      //! \brief constructor
      RadialFilter( const GlobalCoordinateType & center, 
                    const ctype radius ) 
      : center_( center ),
        radius_( radius )
      { }

      RadialFilter ()
      : center_( 0 ),
        radius_( 0.25 )
      { }

      //! \brief check whether entity center is inside of circle 
      template< class Entity >
      bool contains ( const Entity & entity ) const
      {
        static const int cc = Entity::codimension;
        if( cc != 0 )
          DUNE_THROW( InvalidStateException, "RadialFilter::contains only available for codim 0 entities" );
        ctype dist = (entity.geometry().center() - center_).two_norm();
        return (dist > radius_);
      }
     
      //! \brief default implementation returns contains from neighbor
      template< class Intersection >
      bool interiorIntersection( const Intersection &intersection ) const
      {
        typedef typename Intersection::EntityPointer EntityPointerType;
        const EntityPointerType outside = intersection.outside();
        return contains( *outside );
      }

      //! \brief return what boundary id we have in case of boundary intersection 
      //         which is either it.boundary == true or contains (it.ouside()) == false 
      //         so here true is a good choice 
      template < class IntersectionIteratorType >
      inline bool intersectionBoundary( const IntersectionIteratorType & it ) const 
      {
        return true;
      }
      //! \brief return what boundary id we have in case of boundary intersection 
      //          which is either it.boundary == true or contains (it.ouside()) == false 
      template < class IntersectionIteratorType >
      inline int intersectionBoundaryId(const IntersectionIteratorType & it) const
      {
        return 1;
      }

      //! \brief if contains() is true then we have an interior entity 
      template <class IntersectionIteratorType>
      inline bool intersectionNeighbor( const IntersectionIteratorType & it ) const
      {
        return false;
      }

    private:
      const GlobalCoordinateType center_;
      const ctype radius_;

    }; // end RadialFilter

  }  // namespace Fem

}  // namespace Dune

#endif // #ifndef DUNE_FEM_GRIDPART_FILTER_RADIALFILTER_HH 

