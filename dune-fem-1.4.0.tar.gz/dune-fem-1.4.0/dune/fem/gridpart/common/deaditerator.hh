/**************************************************************************
 
  The dune-fem module is a module of DUNE (see www.dune-project.org).
  It is based on the dune-grid interface library 
  extending the grid interface by a number of discretization algorithms
  for solving non-linear systems of partial differential equations.

  Copyright (C) 2003 - 2013 Robert Kloefkorn
  Copyright (C) 2003 - 2010 Mario Ohlberger 
  Copyright (C) 2004 - 2013 Andreas Dedner
  Copyright (C) 2005        Adrian Burri
  Copyright (C) 2005 - 2012 Mirko Kraenkel
  Copyright (C) 2006 - 2013 Christoph Gersbacher
  Copyright (C) 2006 - 2013 Martin Nolte
  Copyright (C) 2011 - 2013 Tobias Malkmus

  The dune-fem module is free software; you can redistribute it and/or 
  modify it under the terms of the GNU General Public License as 
  published by the Free Software Foundation; either version 2 of 
  the License, or (at your option) any later version.

  The dune-fem module is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along
  with this program; if not, write to the Free Software Foundation, Inc.,
  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 
**************************************************************************/
#ifndef DUNE_FEM_GRIDPART_COMMON_DEADINTERSECTIONITERATOR_HH
#define DUNE_FEM_GRIDPART_COMMON_DEADINTERSECTIONITERATOR_HH

#include <dune/grid/common/entityiterator.hh>
#include <dune/grid/common/intersection.hh>
#include <dune/grid/common/intersectioniterator.hh>

namespace Dune
{

  namespace Fem
  {

    // DeadIterator
    // ------------
    
    template< class EntityPointer >
    struct DeadIterator
    : public EntityPointer
    {
      explicit DeadIterator ( const EntityPointer &entityPointer )
      : EntityPointer( entityPointer )
      {}

      void increment ()
      {
        DUNE_THROW( InvalidStateException, "Trying to increment a dead iterator." );
      }
    };



    // DeadIntersection
    // ----------------

    template< class GridFamily >
    class DeadIntersection
    {
      typedef typename remove_const< GridFamily >::type::Traits Traits;

    public:
      typedef typename remove_const< GridFamily >::type::ctype ctype;
      
      static const int dimension = remove_const< GridFamily >::type::dimension;
      static const int dimensionworld = remove_const< GridFamily >::type::dimensionworld;

      typedef typename Traits::template Codim< 0 >::Entity Entity;
      typedef typename Traits::template Codim< 0 >::EntityPointer EntityPointer;
      typedef typename Traits::template Codim< 1 >::Geometry Geometry;
      typedef typename Traits::template Codim< 1 >::LocalGeometry LocalGeometry;

    public:
      const EntityPointer inside () const
      {
        DUNE_THROW( InvalidStateException, "Call to inside on dead intersection." );
      }
      
      EntityPointer outside () const
      {
        DUNE_THROW( InvalidStateException, "Call to outside on dead intersection." );
      }

      bool boundary () const
      {
        DUNE_THROW( InvalidStateException, "Call to boundary on dead intersection." );
      }

      bool conforming () const
      {
        DUNE_THROW( InvalidStateException, "Call to conforming on dead intersection." );
      }
          
      bool neighbor () const
      {
        DUNE_THROW( InvalidStateException, "Call to neighbor on dead intersection." );
      }
          
      int boundaryId () const
      {
        DUNE_THROW( InvalidStateException, "Call to boundaryId on dead intersection." );
      }
          
      size_t boundarySegmentIndex () const
      {
        DUNE_THROW( InvalidStateException, "Call to boundarySegmentIndex on dead intersection." );
      }
          
      const LocalGeometry &geometryInInside () const
      {
        DUNE_THROW( InvalidStateException, "Call to geometryInInside on dead intersection." );
      }
      
      const LocalGeometry &geometryInOutside () const
      {
        DUNE_THROW( InvalidStateException, "Call to geometryInOutside on dead intersection." );
      }
     
      const Geometry &geometry () const
      {
        DUNE_THROW( InvalidStateException, "Call to geometry on dead intersection." );
      }

      GeometryType type () const
      {
        DUNE_THROW( InvalidStateException, "Call to type on dead intersection." );
      }

      int indexInInside () const
      {
        DUNE_THROW( InvalidStateException, "Call to indexInInside on dead intersection." );
      }
      
      int indexInOutside () const
      {
        DUNE_THROW( InvalidStateException, "Call to indexInOutside on dead intersection." );
      }
      
      FieldVector< ctype, dimensionworld >
      integrationOuterNormal ( const FieldVector< ctype, dimension-1 > &local ) const
      {
        DUNE_THROW( InvalidStateException, "Call to integrationOuterNormal on dead intersection." );
      }
      
      FieldVector< ctype, dimensionworld >
      outerNormal ( const FieldVector< ctype, dimension-1 > &local ) const
      {
        DUNE_THROW( InvalidStateException, "Call to outerNormal on dead intersection." );
      }

      FieldVector< ctype, dimensionworld >
      unitOuterNormal ( const FieldVector< ctype, dimension-1 > &local ) const
      {
        DUNE_THROW( InvalidStateException, "Call to unitOuterNormal on dead intersection." );
      }

      FieldVector< ctype, dimensionworld > centerUnitOuterNormal () const
      {
        DUNE_THROW( InvalidStateException, "Call to centerUnitOuterNormal on dead intersection." );
      }
    };



    // DeadIntersectionIterator
    // ------------------------

    template< class GridFamily >
    class DeadIntersectionIterator
    {
      typedef DeadIntersectionIterator< GridFamily > ThisType;

      typedef DeadIntersection< const GridFamily > DeadIntersectionType;

    public:
      typedef Dune::Intersection< const GridFamily, DeadIntersectionType > Intersection;

      DeadIntersectionIterator ()
      {}

      bool equals ( const ThisType &other ) const
      {
        return true;
      }
      
      void increment ()
      {
        DUNE_THROW( InvalidStateException, "Trying to increment a dead intersection iterator." );
      }

      const Intersection &dereference () const
      {
        DUNE_THROW( InvalidStateException, "Trying to dereference a dead intersection iterator." );
      }
    };

  } // namespace Fem

} // namespace Dune

#endif // #ifndef DUNE_FEM_GRIDPART_COMMON_DEADINTERSECTIONITERATOR_HH
