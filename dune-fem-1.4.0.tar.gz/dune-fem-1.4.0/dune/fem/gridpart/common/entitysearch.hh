/**************************************************************************
 
  The dune-fem module is a module of DUNE (see www.dune-project.org).
  It is based on the dune-grid interface library 
  extending the grid interface by a number of discretization algorithms
  for solving non-linear systems of partial differential equations.

  Copyright (C) 2003 - 2013 Robert Kloefkorn
  Copyright (C) 2003 - 2010 Mario Ohlberger 
  Copyright (C) 2004 - 2013 Andreas Dedner
  Copyright (C) 2005        Adrian Burri
  Copyright (C) 2005 - 2012 Mirko Kraenkel
  Copyright (C) 2006 - 2013 Christoph Gersbacher
  Copyright (C) 2006 - 2013 Martin Nolte
  Copyright (C) 2011 - 2013 Tobias Malkmus

  The dune-fem module is free software; you can redistribute it and/or 
  modify it under the terms of the GNU General Public License as 
  published by the Free Software Foundation; either version 2 of 
  the License, or (at your option) any later version.

  The dune-fem module is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along
  with this program; if not, write to the Free Software Foundation, Inc.,
  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 
**************************************************************************/
#ifndef DUNE_FEM_GRIDPART_ENTITYSEARCH_HH
#define DUNE_FEM_GRIDPART_ENTITYSEARCH_HH

#include <dune/common/typetraits.hh>

#include <dune/geometry/referenceelements.hh>

#include <dune/grid/common/gridenums.hh>
#include <dune/grid/common/exceptions.hh>
#include <dune/grid/utility/hierarchicsearch.hh>

#include <dune/fem/gridpart/common/capabilities.hh>

namespace Dune
{

  namespace Fem
  {

    // DefaultEntitySearch
    // -------------------

    template< class GridPart, int codim, PartitionIteratorType partition >
    class DefaultEntitySearch
    {
      typedef DefaultEntitySearch< GridPart, codim, partition > ThisType;

      static const int dimension = GridPart::dimension;
      static const int dimensionworld = GridPart::dimensionworld;
      static const int codimension = codim;
      static const int mydimension = dimension - codimension;

      typedef typename GridPart::template Codim< codimension >::GeometryType GeometryType;
      typedef typename GridPart::template Codim< codimension >::template Partition< partition >::IteratorType IteratorType;

      typedef typename GeometryType::ctype ctype;
      typedef typename GeometryType::LocalCoordinate LocalCoordinateType;

    public:
      typedef GridPart GridPartType;

      typedef typename GridPart::template Codim< codimension >::EntityType EntityType;
      typedef typename GridPart::template Codim< codimension >::EntityPointerType EntityPointerType;

      typedef typename GeometryType::GlobalCoordinate GlobalCoordinateType;

      explicit DefaultEntitySearch ( const GridPartType &gridPart )
      : gridPart_( gridPart )
      {}

      EntityPointerType operator() ( const GlobalCoordinateType &x ) const
      {
        const IteratorType end = gridPart_.template end< codimension, partition >();
        for( IteratorType it = gridPart_.template begin< codimension, partition >(); it != end; ++it )
        {
          const EntityType &entity = *it;
          const GeometryType geo = entity.geometry();

          const LocalCoordinateType &z = geo.local( x );
          if( (mydimension < dimensionworld) && ((geo.global( z ) - x).two_norm() > 1e-8 ) )
            continue;

          if( ReferenceElements< ctype, mydimension >::general( geo.type() ).checkInside( z ) )
            return EntityPointerType( it );
        }
        DUNE_THROW( GridError, "Coordinate " << x << " is outside the grid." );
      }

    private:
      const GridPartType &gridPart_;
    };



    // GridEntitySearch
    // ----------------

    template< class GridPart, int codim, PartitionIteratorType partition >
    class GridEntitySearch
    : public DefaultEntitySearch< GridPart, codim, partition >
    {
      typedef GridEntitySearch< GridPart, codim, partition > ThisType;
      typedef DefaultEntitySearch< GridPart, codim, partition > BaseType;

    public:
      typedef typename BaseType::GridPartType GridPartType;

      explicit GridEntitySearch ( const GridPartType &gridPart )
      : BaseType( gridPart )
      {}
    };

    template< class GridPart, PartitionIteratorType partition >
    class GridEntitySearch< GridPart, 0, partition >
    {
      typedef GridEntitySearch< GridPart, 0, partition > ThisType;

      static const int dimension = GridPart::dimension;
      static const int dimensionworld = GridPart::dimensionworld;
      static const int codimension = 0;
      static const int mydimension = dimension - codimension;

      typedef typename GridPart::template Codim< codimension >::GeometryType GeometryType;

    public:
      typedef GridPart GridPartType;

      typedef typename GridPart::template Codim< codimension >::EntityType EntityType;
      typedef typename GridPart::template Codim< codimension >::EntityPointerType EntityPointerType;

      typedef typename GeometryType::GlobalCoordinate GlobalCoordinateType;

      explicit GridEntitySearch ( const GridPartType &gridPart )
      : hierarchicSearch_( gridPart.grid(), gridPart.indexSet() )
      {}

      EntityPointerType operator() ( const GlobalCoordinateType &x ) const
      {
        return hierarchicSearch_.template findEntity< partition >( x );
      }

    private:
      Dune::HierarchicSearch< typename GridPartType::GridType, typename GridPartType::IndexSetType > hierarchicSearch_;
    };



    // EntitySearch
    // ------------

    template< class GridPart, int codim = 0, PartitionIteratorType partition = All_Partition >
    class EntitySearch
    : public conditional< GridPartCapabilities::hasGrid< GridPart >::v, GridEntitySearch< GridPart, codim, partition >, DefaultEntitySearch< GridPart, codim, partition > >::type
    {
      typedef EntitySearch< GridPart, codim, partition > ThisType;
      typedef typename conditional< GridPartCapabilities::hasGrid< GridPart >::v, GridEntitySearch< GridPart, codim, partition >, DefaultEntitySearch< GridPart, codim, partition > >::type BaseType;

    public:
      typedef typename BaseType::GridPartType GridPartType;

      explicit EntitySearch ( const GridPartType &gridPart )
      : BaseType( gridPart )
      {}
    };

  } // namespace Fem

} // namespace Dune

#endif // #ifndef DUNE_FEM_GRIDPART_ENTITYSEARCH_HH
