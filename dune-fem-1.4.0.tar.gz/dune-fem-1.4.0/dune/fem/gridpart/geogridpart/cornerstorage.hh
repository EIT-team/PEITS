/**************************************************************************
 
  The dune-fem module is a module of DUNE (see www.dune-project.org).
  It is based on the dune-grid interface library 
  extending the grid interface by a number of discretization algorithms
  for solving non-linear systems of partial differential equations.

  Copyright (C) 2003 - 2013 Robert Kloefkorn
  Copyright (C) 2003 - 2010 Mario Ohlberger 
  Copyright (C) 2004 - 2013 Andreas Dedner
  Copyright (C) 2005        Adrian Burri
  Copyright (C) 2005 - 2012 Mirko Kraenkel
  Copyright (C) 2006 - 2013 Christoph Gersbacher
  Copyright (C) 2006 - 2013 Martin Nolte
  Copyright (C) 2011 - 2013 Tobias Malkmus

  The dune-fem module is free software; you can redistribute it and/or 
  modify it under the terms of the GNU General Public License as 
  published by the Free Software Foundation; either version 2 of 
  the License, or (at your option) any later version.

  The dune-fem module is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along
  with this program; if not, write to the Free Software Foundation, Inc.,
  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 
**************************************************************************/
#ifndef DUNE_FEM_GRIDPART_GEOGRIDPART_CORNERSTORAGE_HH
#define DUNE_FEM_GRIDPART_GEOGRIDPART_CORNERSTORAGE_HH

#include <dune/common/typetraits.hh>

#include <dune/grid/geometrygrid/hostcorners.hh>
#include <dune/grid/geometrygrid/coordfunction.hh>

#include <dune/fem/function/localfunction/localfunction.hh>

namespace Dune
{

  namespace Fem
  {

    // External Forward Declarations
    // -----------------------------

    class IsDiscreteFunction;

    template< class, class, int, template< class > class >
    class LagrangeDiscreteFunctionSpace;



    // GeoDiscreteCoordFunctionCaller
    // ------------------------------

    template< int codim, class CoordFunction, class DFSpace = typename CoordFunction::DiscreteFunctionSpaceType >
    class GeoDiscreteCoordFunctionCaller;

    template< int codim, class CoordFunction, class FunctionSpace, class GridPart, template< class > class Storage >
    class GeoDiscreteCoordFunctionCaller< codim, CoordFunction, LagrangeDiscreteFunctionSpace< FunctionSpace, GridPart, 1, Storage > >
    {
      typedef LagrangeDiscreteFunctionSpace< FunctionSpace, GridPart, 1, Storage > DFSpace;
      dune_static_assert( (Conversion< DFSpace, typename CoordFunction::DiscreteFunctionSpaceType >::sameType), "Invalid use of template argument DFSpace." );

    public:
      typedef CoordFunction CoordFunctionType;

      typedef typename CoordFunctionType::GridPartType::template Codim< codim >::EntityType HostEntityType;
      typedef typename CoordFunctionType::RangeType RangeType;

      static const int dimRange = CoordFunctionType::FunctionSpaceType::dimRange;
      static const int dimension = HostEntityType::dimension;
      static const int mydimension = HostEntityType::mydimension;

      GeoDiscreteCoordFunctionCaller ( const CoordFunction &coordFunction,
                                       const HostEntityType &hostEntity )
      : coordFunction_( coordFunction ),
        hostEntity_( hostEntity )
      {}

      void evaluate ( unsigned int i, RangeType &y ) const
      {
        const int index = coordFunction_.gridPart().indexSet().subIndex( hostEntity_, i, dimension );
        assert( (index >= 0) && (index < (int)(coordFunction_.space().blockMapper().size())) );

        typedef typename CoordFunctionType::ConstDofBlockPtrType ConstDofBlockPtrType;
        ConstDofBlockPtrType block = coordFunction_.block( index );

        for( int k = 0; k < dimRange; ++k )
          y[ k ] = (*block)[ k ];
      }

      GeometryType type () const
      {
        return hostEntity_.type();
      }

      std::size_t numCorners () const
      {
        return ReferenceElements< typename CoordFunctionType::GridPartType::GridType::ctype, mydimension >::general( type() ).size( mydimension );
      }

    private:
      const CoordFunctionType &coordFunction_;
      const HostEntityType &hostEntity_;
    };



    // GeoCoordFunctionCaller
    // ----------------------

    template< int codim, class CoordFunction, bool discrete = Conversion< CoordFunction, IsDiscreteFunction >::exists >
    class GeoCoordFunctionCaller;

    template< int codim, class CoordFunction >
    class GeoCoordFunctionCaller< codim, CoordFunction, false >
    {
    public:
      typedef CoordFunction CoordFunctionType;

      typedef typename CoordFunctionType::GridPartType::template Codim< codim >::EntityType HostEntityType;
      typedef typename CoordFunctionType::RangeType RangeType;

      GeoCoordFunctionCaller ( const CoordFunction &coordFunction,
                               const HostEntityType &hostEntity )
      : coordFunction_( coordFunction ),
        hostCorners_( hostEntity )
      {}

      void evaluate ( unsigned int i, RangeType &y ) const
      {
        coordFunction_.evaluate( hostCorners_[ i ], y );
      }

      GeometryType type () const
      {
        return hostCorners_.type();
      }

      std::size_t numCorners () const
      {
        return hostCorners_.size();
      }

    private:
      const CoordFunction &coordFunction_;
      GeoGrid::HostCorners< HostEntityType > hostCorners_;
    };

    template< int codim, class CoordFunction >
    class GeoCoordFunctionCaller< codim, CoordFunction, true >
    : public GeoDiscreteCoordFunctionCaller< codim, CoordFunction >
    {
      typedef GeoDiscreteCoordFunctionCaller< codim, CoordFunction > BaseType;

    public:
      typedef typename BaseType::CoordFunctionType CoordFunctionType;
      typedef typename BaseType::HostEntityType HostEntityType;

      GeoCoordFunctionCaller ( const CoordFunctionType &coordFunction,
                               const HostEntityType &hostEntity )
      : BaseType( coordFunction, hostEntity )
      {}
    };



    // GeoCoordVector
    // --------------

    template< int mydim, class GridFamily >
    class GeoCoordVector
    {
      typedef typename remove_const< GridFamily >::type::Traits Traits;

      typedef typename remove_const< GridFamily >::type::ctype ctype;

      static const int dimension = remove_const< GridFamily >::type::dimension;
      static const int mydimension = mydim;
      static const int codimension = dimension - mydimension;
      static const int dimensionworld = remove_const< GridFamily >::type::dimensionworld;

      typedef FieldVector< ctype, dimensionworld > Coordinate;

      typedef typename Traits::HostGridPartType HostGridPartType;
      typedef typename Traits::CoordFunctionType CoordFunctionType;

      typedef typename HostGridPartType::template Codim< codimension >::EntityType HostEntityType;

      typedef GeoCoordFunctionCaller< codimension, CoordFunctionType > CoordFunctionCallerType;

    public:
      GeoCoordVector ( const CoordFunctionType &coordFunction,
                       const HostEntityType &hostEntity )
      : coordFunctionCaller_( coordFunction, hostEntity )
      {}

      template< std::size_t size >
      void calculate ( Dune::array< Coordinate, size > &corners ) const
      {
        const std::size_t numCorners = coordFunctionCaller_.numCorners();
        for( std::size_t i = 0; i < numCorners; ++i )
          coordFunctionCaller_.evaluate( i, corners[ i ] );
      }

    private:
      const CoordFunctionCallerType coordFunctionCaller_;
    };



    // GeoLocalCoordVector
    // -------------------

    template< int mydim, class GridFamily, class LCFTraits >
    class GeoLocalCoordVector
    {
      typedef typename remove_const< GridFamily >::type::Traits Traits;

      typedef typename remove_const< GridFamily >::type::ctype ctype;

      static const int dimension = remove_const< GridFamily >::type::dimension;
      static const int mydimension = mydim;
      static const int codimension = dimension - mydimension;
      static const int dimensionworld = remove_const< GridFamily >::type::dimensionworld;

      typedef FieldVector< ctype, dimensionworld > Coordinate;

    public:
      typedef LocalFunction< LCFTraits > LocalCoordFunctionType;

      explicit GeoLocalCoordVector ( const LocalCoordFunctionType &localCoordFunction )
      : localCoordFunction_( localCoordFunction )
      {}

      template< std::size_t size >
      void calculate ( Dune::array< Coordinate, size > &corners ) const
      {
        assert( (localCoordFunction_.numDofs() % dimensionworld) == 0 );
        const std::size_t numCorners = localCoordFunction_.numDofs() / dimensionworld;
        assert( size >= numCorners );
        for( std::size_t i = 0; i < numCorners; ++i )
        {
          for( int k = 0; k < dimensionworld; ++k )
            corners[ i ][ k ] = localCoordFunction_[ i*dimensionworld + k ];
        }
      }

    private:
      dune_static_assert( LocalCoordFunctionType::dimRange == dimensionworld, "Invalid local coordinate function." );

      const LocalCoordFunctionType &localCoordFunction_;
    };



    // IntersectionCoordVector
    // -----------------------

    template< class GridFamily >
    class GeoIntersectionCoordVector
    {
      typedef typename remove_const< GridFamily >::type::Traits Traits;

      typedef typename remove_const< GridFamily >::type::ctype ctype;

      static const int dimension = remove_const< GridFamily >::type::dimension;
      static const int codimension = 1;
      static const int mydimension = dimension-codimension;
      static const int dimensionworld = remove_const< GridFamily >::type::dimensionworld;

      typedef FieldVector< ctype, dimensionworld > Coordinate;

      typedef typename Traits::template Codim< 0 >::Geometry ElementGeometryType;
      typedef typename Traits::template Codim< codimension >::LocalGeometry HostLocalGeometryType;

      typedef typename ElementGeometryType::Implementation ElementGeometryImplType;

    public:
      GeoIntersectionCoordVector ( const ElementGeometryImplType &elementGeometry,
                                   const HostLocalGeometryType &hostLocalGeometry )
      : elementGeometry_( elementGeometry ),
        hostLocalGeometry_( hostLocalGeometry )
      {}

      template< std::size_t size >
      void calculate ( Dune::array< Coordinate, size > &corners ) const
      {
        const std::size_t numCorners = hostLocalGeometry_.corners();
        assert( size >= numCorners );
        for( std::size_t i = 0; i < numCorners; ++i )
          corners[ i ] = elementGeometry_.global( hostLocalGeometry_.corner( i ) );
      }

    private:
      const ElementGeometryImplType &elementGeometry_;
      HostLocalGeometryType hostLocalGeometry_;
    };



    // GeoCornerStorage
    // ----------------

    template< int mydim, int cdim, class GridFamily >
    class GeoCornerStorage
    {
      typedef typename remove_const< GridFamily >::type::ctype ctype;

      typedef FieldVector< ctype, cdim > Coordinate;

      typedef Dune::array< Coordinate, (1 << mydim) > Coords;

    public:
      typedef typename Coords::const_iterator const_iterator;

      explicit GeoCornerStorage ( const GeoCoordVector< mydim, GridFamily > &coords )
      {
        coords.calculate( coords_ );
      }

      template< class LCFTraits >
      explicit GeoCornerStorage ( const GeoLocalCoordVector< mydim, GridFamily, LCFTraits > &coords )
      {
        coords.calculate( coords_ );
      }

      explicit GeoCornerStorage ( const GeoIntersectionCoordVector< GridFamily > &coords )
      {
        coords.calculate( coords_ );
      }

      const Coordinate &operator[] ( unsigned int i ) const
      {
        return coords_[ i ];
      }

      const_iterator begin () const { return coords_.begin(); }
      const_iterator end () const { return coords_.end(); }

    private:
      Coords coords_;
    };

  } // namespace Fem

} // namespace Dune

#endif // #ifndef DUNE_FEM_GRIDPART_GEOGRIDPART_CORNERSTORAGE_HH
