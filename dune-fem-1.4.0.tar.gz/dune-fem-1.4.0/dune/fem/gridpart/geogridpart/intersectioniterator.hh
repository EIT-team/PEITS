/**************************************************************************
 
  The dune-fem module is a module of DUNE (see www.dune-project.org).
  It is based on the dune-grid interface library 
  extending the grid interface by a number of discretization algorithms
  for solving non-linear systems of partial differential equations.

  Copyright (C) 2003 - 2013 Robert Kloefkorn
  Copyright (C) 2003 - 2010 Mario Ohlberger 
  Copyright (C) 2004 - 2013 Andreas Dedner
  Copyright (C) 2005        Adrian Burri
  Copyright (C) 2005 - 2012 Mirko Kraenkel
  Copyright (C) 2006 - 2013 Christoph Gersbacher
  Copyright (C) 2006 - 2013 Martin Nolte
  Copyright (C) 2011 - 2013 Tobias Malkmus

  The dune-fem module is free software; you can redistribute it and/or 
  modify it under the terms of the GNU General Public License as 
  published by the Free Software Foundation; either version 2 of 
  the License, or (at your option) any later version.

  The dune-fem module is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along
  with this program; if not, write to the Free Software Foundation, Inc.,
  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 
**************************************************************************/
#ifndef DUNE_FEM_GRIDPART_GEOGRIDPART_INTERSECTIONITERATOR_HH
#define DUNE_FEM_GRIDPART_GEOGRIDPART_INTERSECTIONITERATOR_HH

#include <dune/grid/common/intersectioniterator.hh>

#include <dune/fem/gridpart/geogridpart/intersection.hh>

namespace Dune
{

  namespace Fem
  {

    // GeoIntersectionIterator
    // -----------------------

    template< class GridFamily >
    class GeoIntersectionIterator
    {
      typedef GeoIntersectionIterator< GridFamily > ThisType;

      typedef typename remove_const< GridFamily >::type::Traits Traits;

      typedef typename Traits::HostGridPartType::IntersectionIteratorType HostIntersectionIteratorType;

      typedef GeoIntersection< const GridFamily > IntersectionImplType;

    public:
      typedef Dune::Intersection< const GridFamily, IntersectionImplType > Intersection;

      template< class Entity >
      GeoIntersectionIterator ( const Entity &inside,
                                const HostIntersectionIteratorType &hostIterator )
      : hostIterator_( hostIterator ),
        intersection_( IntersectionImplType( inside.impl().coordFunction(), inside.geometry() ) )
      {}

      GeoIntersectionIterator ( const ThisType &other )
      : hostIterator_( other.hostIterator_ ),
        intersection_( IntersectionImplType( other.intersection_.impl() ) )
      {}

      const ThisType &operator= ( const ThisType &other )
      {
        hostIterator_ = other.hostIterator_;
        intersection_.impl() = other.intersection_.impl();
        return *this;
      }

      bool equals ( const ThisType &other ) const
      {
        return (hostIterator_ == other.hostIterator_);
      }
      
      void increment ()
      {
        ++hostIterator_;
        intersection_.impl().invalidate();
      }

      const Intersection &dereference () const
      {
        if( !intersection_.impl() )
          intersection_.impl().initialize( *hostIterator_ );
        return intersection_;
      }

    private:
      HostIntersectionIteratorType hostIterator_;
      mutable Intersection intersection_;
    };

  } // namespace Fem

} // namespace Dune

#endif // #ifndef DUNE_FEM_GRIDPART_GEOGRIDPART_INTERSECTIONITERATOR_HH
