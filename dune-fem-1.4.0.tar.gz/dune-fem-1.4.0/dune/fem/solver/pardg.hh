/**************************************************************************
 
  The dune-fem module is a module of DUNE (see www.dune-project.org).
  It is based on the dune-grid interface library 
  extending the grid interface by a number of discretization algorithms
  for solving non-linear systems of partial differential equations.

  Copyright (C) 2003 - 2013 Robert Kloefkorn
  Copyright (C) 2003 - 2010 Mario Ohlberger 
  Copyright (C) 2004 - 2013 Andreas Dedner
  Copyright (C) 2005        Adrian Burri
  Copyright (C) 2005 - 2012 Mirko Kraenkel
  Copyright (C) 2006 - 2013 Christoph Gersbacher
  Copyright (C) 2006 - 2013 Martin Nolte
  Copyright (C) 2011 - 2013 Tobias Malkmus

  The dune-fem module is free software; you can redistribute it and/or 
  modify it under the terms of the GNU General Public License as 
  published by the Free Software Foundation; either version 2 of 
  the License, or (at your option) any later version.

  The dune-fem module is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along
  with this program; if not, write to the Free Software Foundation, Inc.,
  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 
**************************************************************************/
#ifndef PARDG_INCLUDE_HH
#define PARDG_INCLUDE_HH

#include <unistd.h>
#include <time.h>
#include <sys/times.h>

#include <cassert>
#include <cmath>
#include <vector>
#include <cstdlib>
#include <cstring>
#include <iostream>

//#ifdef ENABLE_PARDG 
#define USE_PARDG_ODE_SOLVER 
//#endif

// use different namespaces in case of MPI or not 
#if HAVE_MPI 
#include <mpi.h>
#define PARDG_NS parDG_MPI 
#else 
#define PARDG_NS parDG_NoMPI
#endif

// define combined namespace for later use 
#define PARDG PARDG_NS::pardg

// if the preprocessor variable is defined, the ODE Solver from Dennis
// are used.
#ifdef USE_PARDG_ODE_SOLVER

// timer has no namespace therefore we put here 
namespace PARDG_NS {
namespace pardg {
// if pardg library was found 
#ifdef ENABLE_PARDG 
#include <timer.hpp>
#else 
#include "ode/timer.hpp"
#endif
} // end namespace pardg 

// include pardg communicator 
#include "ode/communicator.hpp"
} // end namespace PARDG_NS

// if pardg library was found 
#ifdef ENABLE_PARDG 

#include <blas.hpp>
namespace PARDG_NS {
namespace pardg {
// we also need vector to be in namespace parDG 
#include <vector.hpp>
} // end namespace pardg 

#include <quadrature.hpp>  
#include <ode_solver.hpp>
#include <linear_solver.hpp>
} // end namespace PARDG_NS
// else use build in ode solver (may be outdated)
#else

namespace PARDG_NS {
namespace pardg {
// we also need vector to be in namespace parDG 
#include "ode/vector.hpp"
} // end namespace pardg
#include "ode/blas.hpp"
#include "ode/quadrature.hpp"  
#include "ode/function.hpp"
#include "ode/ode_solver.hpp"
#include "ode/linear_solver.hpp"
} // end namespace PARDG_NS
#endif

#endif // end USE_DENNIS 

#endif // #ifndef PARDG_INCLUDE_HH
