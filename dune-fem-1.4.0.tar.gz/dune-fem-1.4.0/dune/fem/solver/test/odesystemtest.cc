/**************************************************************************
 
  The dune-fem module is a module of DUNE (see www.dune-project.org).
  It is based on the dune-grid interface library 
  extending the grid interface by a number of discretization algorithms
  for solving non-linear systems of partial differential equations.

  Copyright (C) 2003 - 2013 Robert Kloefkorn
  Copyright (C) 2003 - 2010 Mario Ohlberger 
  Copyright (C) 2004 - 2013 Andreas Dedner
  Copyright (C) 2005        Adrian Burri
  Copyright (C) 2005 - 2012 Mirko Kraenkel
  Copyright (C) 2006 - 2013 Christoph Gersbacher
  Copyright (C) 2006 - 2013 Martin Nolte
  Copyright (C) 2011 - 2013 Tobias Malkmus

  The dune-fem module is free software; you can redistribute it and/or 
  modify it under the terms of the GNU General Public License as 
  published by the Free Software Foundation; either version 2 of 
  the License, or (at your option) any later version.

  The dune-fem module is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along
  with this program; if not, write to the Free Software Foundation, Inc.,
  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 
**************************************************************************/
// ****************************************
//
// Solve the system of ODEs dy/dt = F(y,t)
//
// ****************************************

// standard includes
#include <config.h>
#include <iostream>

// dune includes
#include <dune/common/fvector.hh>
#include <dune/fem/solver/timeprovider.hh>
#include <dune/fem/operator/common/spaceoperatorif.hh>
#include <dune/fem/solver/rungekutta.hh>


using namespace Dune;
using namespace Fem;
using namespace DuneODE;
using namespace std;


// Data structure for our unknown: fieldvector of
// dimension N (N = number of ODEs) with some additional methods.
// In scalar case (N=1) we have nothing more
// than a simple, tuned up double. 
template <int N>
class myDest : public FieldVector<double, N> {
  typedef myDest< N > ThisType;
private:
  struct SpaceDummy {
    int size () const { return N; }
  };
  typedef FieldVector<double, N> BaseType;

public:
  typedef double DomainFieldType;
  typedef double RangeFieldType;
  typedef SpaceDummy DiscreteFunctionSpaceType;

  myDest(string, const SpaceDummy&, const double* u = 0) {
  }
  
  myDest() {
  }
  
  void clear() {
    BaseType::operator=(0.);
  }
  
  void assign(const myDest& other) {
    BaseType::operator=(other);
  }
  
  void axpy(RangeFieldType l, const myDest& other) {
    BaseType::axpy(l, other);
  }
  
  double operator()(int i) const {
    if (i<0 || i>this->size-1) {
      std::cout << "ERROR: Accessing element " << i << std::endl;
    }
    return (*this)[i];
  }

  double scalarProductDofs ( const ThisType &other ) const
  {
    double scp = 0;
    for( std::size_t i=0; i < N; ++i )
      scp += (*this)[ i ] * other[ i ];

    return scp;
  }
};


// implement right hand side F(y,t)
// here: system of three ODEs
class myRHS : public SpaceOperatorInterface<myDest<3> > {
public:
  myRHS() {
  }
  
  const SpaceType& space() const {
    return space_;
  }

  void operator()(const DestinationType& x,
                  DestinationType& y) const {
    y[0]=2.0*t_;
    y[1]=3.0*t_*t_;
    y[2]=x[2];
  }

  void setTime(const double time) {
    t_=time;
  }

private:
  SpaceType space_;
  double t_;
};


int main( int argc, char **argv ) 
{
  MPIManager::initialize( argc, argv );
  // problem data
  const double initialData = 1.0;
  const double startTime = -2.0;
  const double endTime = 2.0;

  // options
  const double stepSize = 0.01;
  const double cfl = 1.;
  const int order = 2;

  // types
  typedef myRHS SpaceOperatorType;
  typedef SpaceOperatorType::DestinationType DestinationType;
  typedef ExplicitRungeKuttaSolver<DestinationType> OdeSolverType;

  // create solver
  TimeProvider<> tp( startTime, cfl );
  SpaceOperatorType spaceOperator;
  OdeSolverType odeSolver( spaceOperator, tp, order );

  // initialize solution vector, same initial data for all components
  DestinationType U;
  for (unsigned int i=0; i<U.size(); i++)
    U[i] = initialData;

  // initialize odesolver
  odeSolver.initialize( U );

  // time loop
  for( tp.init(stepSize); tp.time() < endTime; tp.next(stepSize) ) {
    // do calculation
    odeSolver.solve(U);

    // print out solution
    std::cout << tp.time()
              << " " << U
              << std::endl;
  }
}
