/**************************************************************************
 
  The dune-fem module is a module of DUNE (see www.dune-project.org).
  It is based on the dune-grid interface library 
  extending the grid interface by a number of discretization algorithms
  for solving non-linear systems of partial differential equations.

  Copyright (C) 2003 - 2013 Robert Kloefkorn
  Copyright (C) 2003 - 2010 Mario Ohlberger 
  Copyright (C) 2004 - 2013 Andreas Dedner
  Copyright (C) 2005        Adrian Burri
  Copyright (C) 2005 - 2012 Mirko Kraenkel
  Copyright (C) 2006 - 2013 Christoph Gersbacher
  Copyright (C) 2006 - 2013 Martin Nolte
  Copyright (C) 2011 - 2013 Tobias Malkmus

  The dune-fem module is free software; you can redistribute it and/or 
  modify it under the terms of the GNU General Public License as 
  published by the Free Software Foundation; either version 2 of 
  the License, or (at your option) any later version.

  The dune-fem module is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along
  with this program; if not, write to the Free Software Foundation, Inc.,
  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 
**************************************************************************/
// *****************************
//
// Solve the ODE dy/dt = F(y,t)
//
// *****************************

// standard includes
#include <config.h>
#include <iostream>

// dune includes
#include <dune/fem/misc/mpimanager.hh>
#include <dune/fem/solver/timeprovider.hh>
#include <dune/fem/operator/common/spaceoperatorif.hh>
#include <dune/fem/solver/rungekutta/explicit.hh>


using namespace Dune;
using namespace Fem;
using namespace DuneODE;
using namespace std;


// Faked data structure for our unknown,
// nothing more than a "tuned up" double
class myDest {
  struct SpaceDummy 
  {
    int size () const { return 1; }
  };
  
public:
  typedef double DomainFieldType;
  typedef double RangeFieldType;
  typedef SpaceDummy DiscreteFunctionSpaceType;
  
  myDest(string, const SpaceDummy&, const double* u = 0) {
  }
  myDest() {
  }
  RangeFieldType operator[](int i) const {
    return d_;
  }
  RangeFieldType& operator[](int i) {
    return d_;
  }
  void assign(const myDest& other) {
    d_ = other.d_;
  }
  void axpy(RangeFieldType l, const myDest& other) {
    d_ += other.d_*l;
  }
  myDest& operator*=(RangeFieldType l) {
    d_ *= l;
    return *this;
  }
  myDest& operator+=(const myDest& other) {
    d_ += other.d_;
    return *this;
  }
  myDest& operator-=(const myDest& other) {
    d_ += other.d_;
    return *this;
  }

  RangeFieldType scalarProductDofs ( const myDest &other ) const { return d_ * other.d_; }

private:
  RangeFieldType d_;
};


// implement right hand side F(y,t)
class myRHS : public SpaceOperatorInterface<myDest> {
public:
  myRHS() {
  }

  const SpaceType& space() const {
    return space_;
  }

  void operator()(const DestinationType& x,
                  DestinationType& y) const {
    y[0]=2.0*t_;
    //y[0]=3.0*t_*t_;        
    //y[0]=x[0];
  }

  void setTime(const double time) {
    t_=time;
  }

private:
  SpaceType space_;
  double t_;
};


int main( int argc, char ** argv )
{
  Dune::Fem::MPIManager::initialize( argc, argv );

  // problem data
  const double initialData = 1.0;
  const double startTime = -2.0;
  const double endTime = 2.0;

  // options
  const double stepSize = 0.01;
  const double cfl = 1.;
  const int order = 2;

  // types
  typedef myRHS SpaceOperatorType;
  typedef SpaceOperatorType::DestinationType DestinationType;
  typedef ExplicitRungeKuttaSolver<DestinationType> OdeSolverType;

  // create solver
  TimeProvider<> tp( startTime, cfl );
  SpaceOperatorType spaceOperator;
  OdeSolverType odeSolver( spaceOperator, tp, order );

  // initialize solution vector
  DestinationType U;
  U[0] = initialData;

  // initialize odesolver
  odeSolver.initialize( U );

  // time loop
  for( tp.init(stepSize); tp.time() < endTime; tp.next(stepSize) ) {
    // do calculation
    odeSolver.solve(U);

    // print out solution
    std::cout << tp.time()
              << " " << U[0]
              << std::endl;
  }
}
