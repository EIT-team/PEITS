/**************************************************************************
 
  The dune-fem module is a module of DUNE (see www.dune-project.org).
  It is based on the dune-grid interface library 
  extending the grid interface by a number of discretization algorithms
  for solving non-linear systems of partial differential equations.

  Copyright (C) 2003 - 2013 Robert Kloefkorn
  Copyright (C) 2003 - 2010 Mario Ohlberger 
  Copyright (C) 2004 - 2013 Andreas Dedner
  Copyright (C) 2005        Adrian Burri
  Copyright (C) 2005 - 2012 Mirko Kraenkel
  Copyright (C) 2006 - 2013 Christoph Gersbacher
  Copyright (C) 2006 - 2013 Martin Nolte
  Copyright (C) 2011 - 2013 Tobias Malkmus

  The dune-fem module is free software; you can redistribute it and/or 
  modify it under the terms of the GNU General Public License as 
  published by the Free Software Foundation; either version 2 of 
  the License, or (at your option) any later version.

  The dune-fem module is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along
  with this program; if not, write to the Free Software Foundation, Inc.,
  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 
**************************************************************************/
#ifndef DUNE_FEM_SOLVER_ODESOLVERINTERFACE_HH
#define DUNE_FEM_SOLVER_ODESOLVERINTERFACE_HH

#include <iostream>

namespace DuneODE
{

  /** \brief Interface class for ODE Solver. */ 
  template <class DestinationImp>
  class OdeSolverInterface 
  {
  protected:
    //! constructor
    OdeSolverInterface () {}  

    struct Monitor 
    {
      double odeSolveTime_;
      double operatorTime_;
      std::size_t numberOfElements_;

      int newtonIterations_;
      int linearSolverIterations_;
      int maxNewtonIterations_;
      int maxLinearSolverIterations_;

      Monitor() { reset(); }

      // reset all counters 
      void reset() 
      { 
        odeSolveTime_ = 0;
        operatorTime_ = 0;
        numberOfElements_ = 0;
        newtonIterations_ = 0; 
        linearSolverIterations_ = 0;
        maxNewtonIterations_ = 0;
        maxLinearSolverIterations_ = 0;
      }
    };

  public:
    //! monitor type 
    typedef Monitor MonitorType;

    //! type of destination 
    typedef DestinationImp DestinationType;

    //! destructor 
    virtual ~OdeSolverInterface () {}
    
    /** \brief initialize solver 
        \param[in] arg argument to apply internal operator once for intial time step estimate
    */
    virtual void initialize(const DestinationType& arg) = 0;
    
    /** \brief solve \f$\partial_t u = L(u)\f$ where \f$L\f$ is the internal operator.   
        \param[in] u unknown to solve for 
    */
    virtual void solve(DestinationType& u)
    {
      MonitorType monitor; 
      solve( u, monitor );
    }

    /** \brief solve \f$\partial_t u = L(u)\f$ where \f$L\f$ is the internal operator.   
        \param[in] u unknown to solve for 
        \param[in] monitor Monitor to get some inside information 
    */
    virtual void solve ( DestinationType &u, MonitorType &monitor ) = 0;

    /** \brief print description of ODE solver to out stream */
    virtual void description(std::ostream&) const = 0;
  };


} // namespace DuneODE

#endif // #ifndef DUNE_FEM_SOLVER_ODESOLVERINTERFACE_HH
