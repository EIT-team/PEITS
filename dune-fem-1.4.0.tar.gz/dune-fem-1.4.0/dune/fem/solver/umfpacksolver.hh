/**************************************************************************
 
  The dune-fem module is a module of DUNE (see www.dune-project.org).
  It is based on the dune-grid interface library 
  extending the grid interface by a number of discretization algorithms
  for solving non-linear systems of partial differential equations.

  Copyright (C) 2003 - 2013 Robert Kloefkorn
  Copyright (C) 2003 - 2010 Mario Ohlberger 
  Copyright (C) 2004 - 2013 Andreas Dedner
  Copyright (C) 2005        Adrian Burri
  Copyright (C) 2005 - 2012 Mirko Kraenkel
  Copyright (C) 2006 - 2013 Christoph Gersbacher
  Copyright (C) 2006 - 2013 Martin Nolte
  Copyright (C) 2011 - 2013 Tobias Malkmus

  The dune-fem module is free software; you can redistribute it and/or 
  modify it under the terms of the GNU General Public License as 
  published by the Free Software Foundation; either version 2 of 
  the License, or (at your option) any later version.

  The dune-fem module is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along
  with this program; if not, write to the Free Software Foundation, Inc.,
  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 
**************************************************************************/
#ifndef DUNE_FEM_UMFPACKSOLVER_HH
#define DUNE_FEM_UMFPACKSOLVER_HH

#include <limits>

#include <dune/fem/operator/common/operator.hh>
#include <dune/fem/io/parameter.hh>

#ifdef ENABLE_UMFPACK 
#include <umfpack.h>
#endif

namespace Dune
{

  namespace Fem 
  {

    /** @addtogroup DirectSolver  
        
        In this section implementations of direct solvers 
        for solving linear systems of the from 
        \f$A x = b\f$, where \f$A\f$ is a Mapping or
        Operator and \f$x\f$ and \f$b\f$ are discrete functions 
        (see DiscreteFunctionInterface) can be found. 
     **/


    /** \class UMFPACKOp
     *  \ingroup DirectSolver
     *  \brief UMFPACK direct solver
     */
    template< class DF, class Op, bool symmetric=false >
    struct UMFPACKOp
    : public Operator< DF, DF >
    {
      typedef DF DiscreteFunctionType;
      typedef Op OperatorType;

      /** \brief constructor of UMFPACKOp
          \param[in] op Operator to invert 
          \param[in] redEps realative tolerance for residual (not used here)
          \param[in] absLimit absolut solving tolerance for residual (not used here)
          \param[in] maxIter maximal number of iterations performed (not used here)
          \param[in] verbose verbosity 
      */
      UMFPACKOp ( const OperatorType &op, 
                  double redEps,
                  double absLimit,
                  int maxIter,
                  bool verbose )
      : op_( op ),
        epsilon_( absLimit ),
        maxIter_( maxIter ),
        verbose_( verbose )
      {}

      UMFPACKOp ( const OperatorType &op,
                  double redEps,
                  double absLimit,
                  int maxIter = std::numeric_limits< int >::max() )
      : op_( op ),
        epsilon_( absLimit ),
        maxIter_( maxIter ),
        verbose_( Parameter::getValue< bool >( "fem.solver.verbose", false ) )
      {}
                  

      void prepare ( const DiscreteFunctionType &, DiscreteFunctionType & ) const
      {}

      void finalize () const
      {}

      /** \brief solve the system 
          \param[in] arg right hand side 
          \param[out] dest solution 
      */
      void apply ( const DiscreteFunctionType &arg, DiscreteFunctionType &dest ) const
      {
        // prepare operator 
        prepare( arg, dest );

#ifdef ENABLE_UMFPACK 
        // call UMF solve method on SparseRowMatrix
        if (symmetric)
          op_.systemMatrix().solveUMF( arg, dest );
        else
          op_.systemMatrix().solveUMFNonSymmetric( arg, dest );
#else 
        DUNE_THROW( InvalidStateException, "UMFPACK was not found, reconfigure or use other solver!" );
#endif

        // finalize operator  
        finalize ();
      }

      /** \brief solve the system 
          \param[in] arg right hand side 
          \param[out] dest solution 
      */
      void operator() ( const DiscreteFunctionType &arg, DiscreteFunctionType &dest ) const
      {
        apply( arg, dest );
      }

      void printTexInfo(std::ostream& out) const
      {
        out << "Solver: UMFPACK direct solver ";
        out  << "\\\\ \n";
      }

      double averageCommTime() const 
      {
        return 0.0;
      }

      int iterations() const 
      {
        return 0;
      }

    private:
      // note: the matrix is changed by this operator!
      const OperatorType &op_;
      typename DiscreteFunctionType::RangeFieldType epsilon_;
      int maxIter_;
      bool verbose_ ;
    };

  } // namespace Fem 

#if DUNE_FEM_COMPATIBILITY  
  // put this in next version 1.4 

  using Fem :: UMFPACKOp ;
#endif // DUNE_FEM_COMPATIBILITY

} // namespace Dune 

#endif // #ifndef DUNE_FEM_UMFPACKSOLVER_HH
