/**************************************************************************
 
  The dune-fem module is a module of DUNE (see www.dune-project.org).
  It is based on the dune-grid interface library 
  extending the grid interface by a number of discretization algorithms
  for solving non-linear systems of partial differential equations.

  Copyright (C) 2003 - 2013 Robert Kloefkorn
  Copyright (C) 2003 - 2010 Mario Ohlberger 
  Copyright (C) 2004 - 2013 Andreas Dedner
  Copyright (C) 2005        Adrian Burri
  Copyright (C) 2005 - 2012 Mirko Kraenkel
  Copyright (C) 2006 - 2013 Christoph Gersbacher
  Copyright (C) 2006 - 2013 Martin Nolte
  Copyright (C) 2011 - 2013 Tobias Malkmus

  The dune-fem module is free software; you can redistribute it and/or 
  modify it under the terms of the GNU General Public License as 
  published by the Free Software Foundation; either version 2 of 
  the License, or (at your option) any later version.

  The dune-fem module is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along
  with this program; if not, write to the Free Software Foundation, Inc.,
  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 
**************************************************************************/
#ifndef DUNE_FEM_SOLVER_RUNGEKUTTA_IMPLICIT_HH
#define DUNE_FEM_SOLVER_RUNGEKUTTA_IMPLICIT_HH

//- system includes 
#include <sstream>
#include <vector>

//- dune-common includes
#include <dune/common/exceptions.hh>

//- dune-fem includes
#include <dune/fem/solver/rungekutta/basicimplicit.hh>
#include <dune/fem/solver/rungekutta/butchertable.hh>
#include <dune/fem/solver/rungekutta/timestepcontrol.hh>

namespace DuneODE 
{

  // SemiImplicitRungeKuttaSourceTerm
  // --------------------------------

  template< class ExplicitOperator >
  class SemiImplicitRungeKuttaSourceTerm
  {
    typedef SemiImplicitRungeKuttaSourceTerm< ExplicitOperator > ThisType;

  public:
    typedef ExplicitOperator ExplicitOperatorType;

    typedef typename ExplicitOperatorType::DestinationType DestinationType;

    template< class ButcherTable >
    SemiImplicitRungeKuttaSourceTerm ( ExplicitOperatorType &explicitOp,
                                       const ButcherTable &butcherTable,
                                       const Dune::DynamicMatrix< double > &implicitA )
    : explicitOp_( explicitOp ),
      alpha_( butcherTable.A() ),
      gamma_( butcherTable.stages() ),
      c_( butcherTable.c() ),
      uex_( "SIRK u-explicit", explicitOp_.space() ),
      limiter_( explicitOp_.hasLimiter() )
    {
      Dune::DynamicMatrix< double > Ainv( implicitA );
      Ainv.invert();
      alpha_.rightmultiply( Ainv );

      for( int i = 0; i < butcherTable.stages(); ++i )
      {
        gamma_[ i ] = 1.0;
        for( int j = 0; j < i; ++j )
          gamma_[ i ] -= alpha_[ i ][ j ];
      }
    }

    bool operator() ( double time, double timeStepSize, int stage,
                      const DestinationType &u, const std::vector< DestinationType * > &update,
                      DestinationType &source )
    {
      uex_.assign( u );
      uex_ *= gamma_[ stage ];
      for( int k = 0; k < stage; ++k )
        uex_.axpy( alpha_[ stage ][ k ], *update[ k ] );
      explicitOp_.setTime( time + c_[ stage ]*timeStepSize );
      explicitOp_( uex_, source );

      return true;
    }

    void limit( DestinationType& update, const double time ) 
    {
      if( limiter_ ) 
      {
        // set correct time 
        explicitOp_.setTime( time );
        // copy given function 
        uex_.assign( update );
        // apply limiter 
        explicitOp_.limit( uex_, update );
      }
    }

    double initialTimeStepEstimate ( double time, const DestinationType &u ) const
    {
      explicitOp_.setTime( time );
      explicitOp_.initializeTimeStepSize( u );
      return explicitOp_.timeStepEstimate();
    }

    double timeStepEstimate () const
    {
      return explicitOp_.timeStepEstimate();
    }

  private:
    ExplicitOperatorType &explicitOp_;
    Dune::DynamicMatrix< double > alpha_;
    Dune::DynamicVector< double > gamma_, c_;
    DestinationType uex_;
    const bool limiter_ ;
  };



  // SemiImplicitRungeKuttaSolver
  // ----------------------------

  /** \brief Implicit RungeKutta ODE solver. */
  template< class ExplicitOperator, class HelmholtzOperator, class NonlinearSolver >
  class SemiImplicitRungeKuttaSolver
  : public BasicImplicitRungeKuttaSolver< HelmholtzOperator, NonlinearSolver, ImplicitRungeKuttaTimeStepControl, SemiImplicitRungeKuttaSourceTerm< ExplicitOperator > >
  {
    typedef SemiImplicitRungeKuttaSolver< ExplicitOperator, HelmholtzOperator, NonlinearSolver > ThisType;
    typedef BasicImplicitRungeKuttaSolver< HelmholtzOperator, NonlinearSolver, ImplicitRungeKuttaTimeStepControl, SemiImplicitRungeKuttaSourceTerm< ExplicitOperator > > BaseType;

  public:
    typedef ExplicitOperator ExplicitOperatorType;
    typedef HelmholtzOperator HelmholtzOperatorType;
    typedef typename BaseType::TimeStepControlType TimeStepControlType;
    typedef typename BaseType::SourceTermType SourceTermType;

    typedef typename TimeStepControlType::TimeProviderType TimeProviderType;
    typedef typename TimeStepControlType::ParametersType ParametersType;

    /** \brief constructor 
     *
     *  \param[in]  explicitOp    explicit operator
     *  \param[in]  helmholtzOp   Helmholtz operator \f$L\f$
     *  \param[in]  timeProvider  time provider
     *  \param[in]  butcherTable  butcher table to use
     *  \param[in]  traits        additional traits
     */
    SemiImplicitRungeKuttaSolver ( ExplicitOperatorType &explicitOp,
                                   HelmholtzOperatorType &helmholtzOp,
                                   TimeProviderType &timeProvider,
                                   int order = 1,
                                   const ParametersType &parameters = ParametersType() )
    : BaseType( helmholtzOp, butcherTable( order, false ), TimeStepControlType( timeProvider, parameters ), SourceTermType( explicitOp, butcherTable( order, true ), butcherTable( order, false ).A() ) )
    {}

  protected:
    static SimpleButcherTable< double > butcherTable ( int order, bool expl )
    {
      switch( order )
      {
      case 1:
        return semiImplicitEulerButcherTable( expl );
      case 2:
        return semiImplicitSSP222ButcherTable( expl );
      case 3:
        return semiImplicit33ButcherTable( expl );
      case 4:
        return semiImplicitIERK45ButcherTable( expl );
      default:
        DUNE_THROW( NotImplemented, "Semi-implicit Runge-Kutta method of order " << order << " not implemented." );
      }
    }
  };

} // namespace DuneODE

#endif // #ifndef DUNE_FEM_SOLVER_RUNGEKUTTA_IMPLICIT_HH
