#include "vector.hpp"

double Vector::output_epsilon = 1.0e-7;

