/**************************************************************************
 
  The dune-fem module is a module of DUNE (see www.dune-project.org).
  It is based on the dune-grid interface library 
  extending the grid interface by a number of discretization algorithms
  for solving non-linear systems of partial differential equations.

  Copyright (C) 2003 - 2013 Robert Kloefkorn
  Copyright (C) 2003 - 2010 Mario Ohlberger 
  Copyright (C) 2004 - 2013 Andreas Dedner
  Copyright (C) 2005        Adrian Burri
  Copyright (C) 2005 - 2012 Mirko Kraenkel
  Copyright (C) 2006 - 2013 Christoph Gersbacher
  Copyright (C) 2006 - 2013 Martin Nolte
  Copyright (C) 2011 - 2013 Tobias Malkmus

  The dune-fem module is free software; you can redistribute it and/or 
  modify it under the terms of the GNU General Public License as 
  published by the Free Software Foundation; either version 2 of 
  the License, or (at your option) any later version.

  The dune-fem module is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along
  with this program; if not, write to the Free Software Foundation, Inc.,
  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 
**************************************************************************/
#ifndef DUNE_FEM_THREADSAFEVALUES_HH
#define DUNE_FEM_THREADSAFEVALUES_HH

#include <vector>
#include <dune/fem/misc/threads/threadmanager.hh>

namespace Dune {

  namespace Fem {


    /** \brief ThreadSafeValue realizes thread safety for a given variable by 
               creating an instance of this variable for each thread. 
    */ 
    template <class T>
    class ThreadSafeValue
    {
#ifdef USE_SMP_PARALLEL
      std::vector< T > value_;
#else 
      T value_;
#endif
    public:
      //! type of value to be thread safe
      typedef T ValueType ;

      //! \brief constructor initializing values for all threads given a init value
      ThreadSafeValue( const ValueType& init ) 
        : value_( 
#ifdef USE_SMP_PARALLEL
            ThreadManager::maxThreads(), 
#endif
            init )
      {}

      //! \brief default constructor 
      ThreadSafeValue() 
        : value_( 
#ifdef USE_SMP_PARALLEL
            ThreadManager::maxThreads()
#endif
             )
      {}

      //! \brief return number of threads 
      size_t size() const { return ThreadManager::maxThreads(); }

      //! \brief return reference to thread private value 
      ValueType& operator * () { return this->operator[]( ThreadManager::thread() ); }
      //! \brief return reference to thread private value 
      const ValueType& operator * () const { return this->operator[]( ThreadManager::thread() ); }

      //! \brief return reference to private value for given thread number 
      ValueType& operator [] ( const unsigned int thread ) { 
        assert( thread < size() );
        return value_
#ifdef USE_SMP_PARALLEL
          [ thread ]
#endif    
          ;
      }

      //! \brief return reference to private value for given thread number 
      const ValueType& operator [] ( const unsigned int thread ) const { 
        assert( thread < size() );
        return value_
#ifdef USE_SMP_PARALLEL
          [ thread ]
#endif    
          ;
      }
    };

  } // end namespace Fem

} // end namespace Dune 


#endif
