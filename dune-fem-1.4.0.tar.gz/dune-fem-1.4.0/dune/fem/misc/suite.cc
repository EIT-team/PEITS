/**************************************************************************
 
  The dune-fem module is a module of DUNE (see www.dune-project.org).
  It is based on the dune-grid interface library 
  extending the grid interface by a number of discretization algorithms
  for solving non-linear systems of partial differential equations.

  Copyright (C) 2003 - 2013 Robert Kloefkorn
  Copyright (C) 2003 - 2010 Mario Ohlberger 
  Copyright (C) 2004 - 2013 Andreas Dedner
  Copyright (C) 2005        Adrian Burri
  Copyright (C) 2005 - 2012 Mirko Kraenkel
  Copyright (C) 2006 - 2013 Christoph Gersbacher
  Copyright (C) 2006 - 2013 Martin Nolte
  Copyright (C) 2011 - 2013 Tobias Malkmus

  The dune-fem module is free software; you can redistribute it and/or 
  modify it under the terms of the GNU General Public License as 
  published by the Free Software Foundation; either version 2 of 
  the License, or (at your option) any later version.

  The dune-fem module is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along
  with this program; if not, write to the Free Software Foundation, Inc.,
  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 
**************************************************************************/
// Test suite from Chuck Allison in C/C++ Users Journal, September 2000:
// "The Simplest Automated Unit Test Framework That Could Possibly Work"

#include "suite.hh"
#include <iostream>
#include <cassert>

using namespace std;

namespace Dune 
{
  
  namespace Fem
  {

    void Suite::addTest(Test* t) throw(TestSuiteError)
    {
      // Make sure test has a stream:
      if (t == 0)
          throw TestSuiteError("Null test in Suite::addTest");
      else if (m_osptr != 0 && t->getStream() == 0)
          t->setStream(m_osptr);

      m_tests.push_back(t);
      t->reset();
    }

    void Suite::addSuite(const Suite& s) throw(TestSuiteError)
    {
      for (size_t i = 0; i < s.m_tests.size(); ++i)
        addTest(s.m_tests[i]);
    }

    void Suite::free()
    {
      // This is not a destructor because tests
      // don't have to be on the heap.
      for (size_t i = 0; i < m_tests.size(); ++i)
      {
        delete m_tests[i];
        m_tests[i] = 0;
      }
    }

    void Suite::run()
    {
      reset();
      for (size_t i = 0; i < m_tests.size(); ++i)
      {
        assert(m_tests[i]);
        m_tests[i]->run();
      }
    }


    long Suite::report() const
    {
      if (m_osptr)
      {
        long totFail = 0;
        *m_osptr << "Suite \"" << m_name << "\"\n=======";
        size_t i;
        for (i = 0; i < m_name.size(); ++i)
            *m_osptr << '=';
        *m_osptr << "=\n";

        for (i = 0; i < m_tests.size(); ++i)
        {
          assert(m_tests[i]);
          totFail += m_tests[i]->report();
        }

        *m_osptr << "=======";
        for (i = 0; i < m_name.size(); ++i)
          *m_osptr << '=';
        *m_osptr << "=\n";
        return totFail;
      }
      else
        return getNumFailed();
    }

    long Suite::getNumPassed() const
    {
      long totPass = 0;
      for (size_t i = 0; i < m_tests.size(); ++i)
      {
        assert(m_tests[i]);
        totPass += m_tests[i]->getNumPassed();
      }
      return totPass;
    }

    long Suite::getNumFailed() const
    {
      long totFail = 0;
      for (size_t i = 0; i < m_tests.size(); ++i)
      {
        assert(m_tests[i]);
        totFail += m_tests[i]->getNumFailed();
      }
      return totFail;
    }

    void Suite::reset()
    {
      for (size_t i = 0; i < m_tests.size(); ++i)
      {
        assert(m_tests[i]);
        m_tests[i]->reset();
      }
    }

  } // namespace Fem

} // namespace Dune
