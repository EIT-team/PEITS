/**************************************************************************
 
  The dune-fem module is a module of DUNE (see www.dune-project.org).
  It is based on the dune-grid interface library 
  extending the grid interface by a number of discretization algorithms
  for solving non-linear systems of partial differential equations.

  Copyright (C) 2003 - 2013 Robert Kloefkorn
  Copyright (C) 2003 - 2010 Mario Ohlberger 
  Copyright (C) 2004 - 2013 Andreas Dedner
  Copyright (C) 2005        Adrian Burri
  Copyright (C) 2005 - 2012 Mirko Kraenkel
  Copyright (C) 2006 - 2013 Christoph Gersbacher
  Copyright (C) 2006 - 2013 Martin Nolte
  Copyright (C) 2011 - 2013 Tobias Malkmus

  The dune-fem module is free software; you can redistribute it and/or 
  modify it under the terms of the GNU General Public License as 
  published by the Free Software Foundation; either version 2 of 
  the License, or (at your option) any later version.

  The dune-fem module is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along
  with this program; if not, write to the Free Software Foundation, Inc.,
  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 
**************************************************************************/
#ifndef DUNE_FEM_SUBOBJECTS_HH
#define DUNE_FEM_SUBOBJECTS_HH

#include <dune/common/fvector.hh>
#include <dune/common/fmatrix.hh>


/**************************************/

namespace Dune
{

  namespace Fem
  {

    template< class DofVector, class Dof > 
    class SubDofVector 
    {
      typedef DofVector DofVectorType;
      typedef Dof DofType;

      public:
        SubDofVector( DofVectorType &dofs, int size, int offset ) :
          dofs_( dofs ),
          offset_ ( offset ),
          size_( size )
        {}

        const DofType  &operator[] ( const int i ) const
        {
          assert( (i < size_ )&& (i >= 0 ) );
          return dofs_[ i + offset_ ];
        }

        DofType &operator[] ( const int i ) 
        {
          assert( (i < size_ )&& (i >= 0 ) );
          return dofs_[ i + offset_ ];
        }

        int size() const
        {
          return size_;
        }


      private:
        DofVectorType &dofs_;
        const int offset_;
        const int size_;
    };


    template< class T >
    struct RowType;

    template< class T >
    struct RowType< const T>
    {
      typedef const typename RowType<T> :: Type Type;
      static const int size = RowType<T> :: size;
    };

    template< class K, int SIZE >
    struct RowType< FieldVector< K, SIZE > >
    {
      typedef K Type;
      static const int size = SIZE;
    };

    template< class K, int ROWS, int COLS >
    struct RowType< FieldMatrix< K, ROWS, COLS > >
    {
      typedef FieldVector<K, COLS> Type;
      static const int size = ROWS;
    };



    template <class DomainObject, class RangeObject, int offset >
    class SubObject 
    {
      typedef DomainObject DomainObjectType;
      typedef RangeObject RangeObjectType;

      typedef typename RowType< RangeObject > :: Type RowType;

    public:
      SubObject( DomainObjectType &host )
      : host_( host )
      {}

      const RowType &operator[] ( const int i ) const
      {
        assert( (i >=0 ) && (i < size()) );
        return host_[ i + offset ];
      }

      RowType& operator[] ( const int i )
      {
        assert( (i >=0 ) && (i < size()) );
        return host_[ i + offset ];
      }

      int size () const
      {
        return Dune::Fem::RowType< RangeObject > :: size;
      }

      operator typename remove_const< RangeObjectType >::type () const
      {
        typename remove_const< RangeObjectType >::type y;
        for( int i = 0; i < size(); ++i )
          y[ i ] = (*this)[ i ];
        return y;
      }

    private:
      DomainObjectType &host_;
    };

  } // namespace Fem


  // cast into fieldMatrix
  template<class DomainObj, class RangeObj, int offset>
  void istl_assign_to_fmatrix( DenseMatrix< typename remove_const< RangeObj > :: type >& fm, 
                               const Fem::SubObject<DomainObj, RangeObj, offset>& s)
  {
    for( int i = 0; i < s.size(); ++i )
      fm[ i ] = s[ i ];
  }

} //  namespace Dune

#endif // #ifndef DUNE_FEM_SUBOBJECTS_HH
