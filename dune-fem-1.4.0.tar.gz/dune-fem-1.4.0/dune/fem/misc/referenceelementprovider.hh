/**************************************************************************
 
  The dune-fem module is a module of DUNE (see www.dune-project.org).
  It is based on the dune-grid interface library 
  extending the grid interface by a number of discretization algorithms
  for solving non-linear systems of partial differential equations.

  Copyright (C) 2003 - 2013 Robert Kloefkorn
  Copyright (C) 2003 - 2010 Mario Ohlberger 
  Copyright (C) 2004 - 2013 Andreas Dedner
  Copyright (C) 2005        Adrian Burri
  Copyright (C) 2005 - 2012 Mirko Kraenkel
  Copyright (C) 2006 - 2013 Christoph Gersbacher
  Copyright (C) 2006 - 2013 Martin Nolte
  Copyright (C) 2011 - 2013 Tobias Malkmus

  The dune-fem module is free software; you can redistribute it and/or 
  modify it under the terms of the GNU General Public License as 
  published by the Free Software Foundation; either version 2 of 
  the License, or (at your option) any later version.

  The dune-fem module is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along
  with this program; if not, write to the Free Software Foundation, Inc.,
  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 
**************************************************************************/
#ifndef DUNE_FEM_REFERENCEELEMENTPROVIDER_HH
#define DUNE_FEM_REFERENCEELEMENTPROVIDER_HH

#include <dune/geometry/referenceelements.hh>

namespace Dune
{

  namespace Fem
  {

    // ReferenceElementProviderBase
    // ----------------------------

    template< class Grid, int codim >
    struct ReferenceElementProviderBase
    {
      typedef Grid GridType;

      typedef typename GridType::ctype FieldType;
      static const int dimension = GridType::dimension;
      static const int codimension = codim;

      typedef Dune::ReferenceElement< FieldType, dimension-codimension >
        ReferenceElementType;

    protected:
      typedef Dune::ReferenceElementContainer< FieldType, dimension-codimension >
        ContainerType;

      ReferenceElementProviderBase ()
      : container_( ContainerType::instance() )
      {}

      const ContainerType &container () const
      {
        return container_;
      }

    private:
      const ContainerType &container_;
    };



    // ReferenceElementProvider
    // ------------------------

    template< class Grid, int codim = 0 >
    class ReferenceElementProvider
    : public ReferenceElementProviderBase< Grid, codim >
    {
      typedef ReferenceElementProviderBase< Grid, codim > BaseType;

    public:
      typedef typename BaseType::ReferenceElementType ReferenceElementType;

      template< class Object >
      const ReferenceElementType &operator() ( const Object &object ) const
      {
        return BaseType::container() ( object.type() );
      }
    };


    template< class Grid, int codim >
    class ReferenceElementProvider< const Grid, codim >
    : public ReferenceElementProvider< Grid, codim >
    {};



    // ReferenceElementProvider for AlbertaGrid
    // ----------------------------------------

#if HAVE_ALBERTA
    template< int dim, int dimworld >
    class AlbertaGrid;

    template< int dim, int dimworld, int codim >
    class ReferenceElementProvider< AlbertaGrid< dim, dimworld >, codim >
    : public ReferenceElementProviderBase< AlbertaGrid< dim, dimworld >, codim >
    {
      typedef ReferenceElementProviderBase< AlbertaGrid< dim, dimworld >, codim > BaseType;

    public:
      typedef typename BaseType::ReferenceElementType ReferenceElementType;

      template< class Object >
      const ReferenceElementType &operator() ( const Object &object ) const
      {
        return BaseType::container().simplex();
      }
    };
#endif // #if HAVE_ALBERTA



    // ReferenceElementProvider for AluConformGrid
    // -------------------------------------------

#if HAVE_ALUGRID
    template< int dim, int dimworld >
    class AluConformGrid;

    template< int dim, int dimworld, int codim >
    class ReferenceElementProvider< AluConformGrid< dim, dimworld >, codim >
    : public ReferenceElementProviderBase< AluConformGrid< dim, dimworld >, codim >
    {
      typedef ReferenceElementProviderBase< AluConformGrid< dim, dimworld >, codim > BaseType;

    public:
      typedef typename BaseType::ReferenceElementType ReferenceElementType;

      template< class Object >
      const ReferenceElementType &operator() ( const Object &object ) const
      {
        return BaseType::container().simplex();
      }
    };
#endif // #if HAVE_ALUGRID



    // ReferenceElementProvider for AluSimplexGrid
    // -------------------------------------------

#if HAVE_ALUGRID
    template< int dim, int dimworld >
    class AluSimplexGrid;

    template< int dim, int dimworld, int codim >
    class ReferenceElementProvider< AluSimplexGrid< dim, dimworld >, codim >
    : public ReferenceElementProviderBase< AluSimplexGrid< dim, dimworld >, codim >
    {
      typedef ReferenceElementProviderBase< AluSimplexGrid< dim, dimworld >, codim > BaseType;

    public:
      typedef typename BaseType::ReferenceElementType ReferenceElementType;

      template< class Object >
      const ReferenceElementType &operator() ( const Object &object ) const
      {
        return BaseType::container().simplex();
      }
    };
#endif // #if HAVE_ALUGRID



    // ReferenceElementProvider for AluCubeGrid
    // ----------------------------------------

#if HAVE_ALUGRID
    template< int dim, int dimworld >
    class AluCubeGrid;

    template< int dim, int dimworld, int codim >
    class ReferenceElementProvider< AluCubeGrid< dim, dimworld >, codim >
    : public ReferenceElementProviderBase< AluCubeGrid< dim, dimworld >, codim >
    {
      typedef ReferenceElementProviderBase< AluCubeGrid< dim, dimworld >, codim > BaseType;

    public:
      typedef typename BaseType::ReferenceElementType ReferenceElementType;

      template< class Object >
      const ReferenceElementType &operator() ( const Object &object ) const
      {
        return BaseType::container().cube();
      }
    };
#endif // #if HAVE_ALUGRID


    // ReferenceElementProvider for ALUGrid
    // -------------------------------------
    // TODO: add specialization for ALUGrid 


    // ReferenceElementProvider for OneDGrid
    // -------------------------------------

    class OneDGrid;

    template< int codim >
    class ReferenceElementProvider< OneDGrid, codim >
    : public ReferenceElementProviderBase< OneDGrid, codim >
    {
      typedef ReferenceElementProviderBase< OneDGrid, codim > BaseType;

    public:
      typedef typename BaseType::ReferenceElementType ReferenceElementType;

      template< class Object >
      const ReferenceElementType &operator() ( const Object &object ) const
      {
        return BaseType::container().cube();
      }
    };



    // ReferenceElementProvider for SGrid
    // ----------------------------------

    template< int dim, int dimworld, class ctype >
    class SGrid;

    template< int dim, int dimworld, class ctype, int codim >
    class ReferenceElementProvider< SGrid< dim, dimworld, ctype >, codim >
    : public ReferenceElementProviderBase< SGrid< dim, dimworld, ctype >, codim >
    {
      typedef ReferenceElementProviderBase< SGrid< dim, dimworld, ctype >, codim > BaseType;

    public:
      typedef typename BaseType::ReferenceElementType ReferenceElementType;

      template< class Object >
      const ReferenceElementType &operator() ( const Object &object ) const
      {
        return BaseType::container().cube();
      }
    };


    // ReferenceElementProvider for YaspGrid
    // -------------------------------------

    template< int dim >
    class YaspGrid;

    template< int dim, int codim >
    class ReferenceElementProvider< YaspGrid< dim >, codim >
    : public ReferenceElementProviderBase< YaspGrid< dim >, codim >
    {
      typedef ReferenceElementProviderBase< YaspGrid< dim >, codim > BaseType;

    public:
      typedef typename BaseType::ReferenceElementType ReferenceElementType;

      template< class Object >
      const ReferenceElementType &operator() ( const Object &object ) const
      {
        return BaseType::container().cube();
      }
    };

  } // namespace Fem

} // namespace Dune

#endif  // #ifndef DUNE_FEM_REFERENCEELEMENTPROVIDER_HH
