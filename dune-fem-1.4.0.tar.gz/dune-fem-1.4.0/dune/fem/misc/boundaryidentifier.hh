/**************************************************************************
 
  The dune-fem module is a module of DUNE (see www.dune-project.org).
  It is based on the dune-grid interface library 
  extending the grid interface by a number of discretization algorithms
  for solving non-linear systems of partial differential equations.

  Copyright (C) 2003 - 2013 Robert Kloefkorn
  Copyright (C) 2003 - 2010 Mario Ohlberger 
  Copyright (C) 2004 - 2013 Andreas Dedner
  Copyright (C) 2005        Adrian Burri
  Copyright (C) 2005 - 2012 Mirko Kraenkel
  Copyright (C) 2006 - 2013 Christoph Gersbacher
  Copyright (C) 2006 - 2013 Martin Nolte
  Copyright (C) 2011 - 2013 Tobias Malkmus

  The dune-fem module is free software; you can redistribute it and/or 
  modify it under the terms of the GNU General Public License as 
  published by the Free Software Foundation; either version 2 of 
  the License, or (at your option) any later version.

  The dune-fem module is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along
  with this program; if not, write to the Free Software Foundation, Inc.,
  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 
**************************************************************************/
#ifndef DUNE_FEM_BOUNDARYIDENTIFIER_HH 
#define DUNE_FEM_BOUNDARYIDENTIFIER_HH 

namespace Dune 
{ 
  
  namespace Fem
  {

    /** \brief Simple class for boundary identifiers 
      use in numerical problems.
    */
    class BoundaryIdentifier 
    {
      public:
        //! \brief tpyes of boundary 
        enum BoundaryType 
        { 
          //! Dirichlet boundary with non-zero boundary values 
          DirichletNonZero , 
          //! Dirichlet boundary with zero boundary values 
          DirichletZero , 
          //! Neumann boundary with non-zero boundary fluxes 
          NeumannNonZero, 
          //! Neuman boundary with zero boundary fluxes 
          NeumannZero , 
          //! mixed boundary type 
          Robin ,
          //! undefined boundary type 
          undefined };

        BoundaryType bnd_;  
      public:
        // create undefined bnd 
        BoundaryIdentifier() : bnd_(undefined) {}
        // create bnd with given id 
        BoundaryIdentifier(const BoundaryType bnd) : bnd_(bnd) {} 
        // copy bnd 
        BoundaryIdentifier(const  BoundaryIdentifier & org) : bnd_(org.bnd_) {} 

        //! returns true if bnd is either Dirichlet or DirichletZero
        bool isDirichletType() const 
        { 
          return (bnd_ == DirichletNonZero) || 
                 (bnd_ == DirichletZero); 
        }
        
        //! returns true if bnd is DirichletZero
        bool isDirichletZero() const 
        { 
          return (bnd_ == DirichletZero);
        }

        //! returns true if bnd is DirichletNonZero
        bool isDirichletNonZero() const 
        { 
          return (bnd_ == DirichletNonZero);
        }

        //! returns true, if bnd is either NeumannNonZero or NeumannZero type
        bool isNeumannType() const 
        { 
          return (bnd_ == NeumannNonZero) || 
                 (bnd_ == NeumannZero); 
        }
        
        //! returns true, if bnd is NeumannZero type
        bool isNeumannZero() const 
        { 
          return (bnd_ == NeumannZero); 
        }
       
        //! returns true, if bnd is Neumann type
        bool isNeumannNonZero() const 
        { 
          return (bnd_ == NeumannNonZero); 
        }
    };

  } // namespace Fem

}// namespace Dune 

#endif // #ifndef DUNE_FEM_BOUNDARYIDENTIFIER_HH 
