/**************************************************************************
 
  The dune-fem module is a module of DUNE (see www.dune-project.org).
  It is based on the dune-grid interface library 
  extending the grid interface by a number of discretization algorithms
  for solving non-linear systems of partial differential equations.

  Copyright (C) 2003 - 2013 Robert Kloefkorn
  Copyright (C) 2003 - 2010 Mario Ohlberger 
  Copyright (C) 2004 - 2013 Andreas Dedner
  Copyright (C) 2005        Adrian Burri
  Copyright (C) 2005 - 2012 Mirko Kraenkel
  Copyright (C) 2006 - 2013 Christoph Gersbacher
  Copyright (C) 2006 - 2013 Martin Nolte
  Copyright (C) 2011 - 2013 Tobias Malkmus

  The dune-fem module is free software; you can redistribute it and/or 
  modify it under the terms of the GNU General Public License as 
  published by the Free Software Foundation; either version 2 of 
  the License, or (at your option) any later version.

  The dune-fem module is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along
  with this program; if not, write to the Free Software Foundation, Inc.,
  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 
**************************************************************************/
#ifndef DUNE_FEM_VALIDATOR_HH
#define DUNE_FEM_VALIDATOR_HH

#include <iostream>

namespace Dune
{

  namespace Fem
  {

    // Internal Forward Declarations
    // -----------------------------

    template< class T, class Impl >
    class ValidatorDefault;



    // ValidatorInterface
    // ------------------

    template< class T, class Impl >
    class ValidatorInterface
    {
      typedef ValidatorInterface< T, Impl > ThisType;

      friend class ValidatorDefault< T, Impl >;

    private:
      ValidatorInterface () {}

      ValidatorInterface ( const ThisType & );
      ThisType &operator= ( const ThisType & );

    public:
      bool operator () ( const T &value ) const
      {
        return asImp()( value );
      }

      void print(std::ostream& s) const
      {
        asImp().print( s );
      }
      
    protected:
      const Impl &asImp () const
      {
        return static_cast< const Impl & >( *this );
      }

      Impl &asImp ()
      {
        return static_cast< Impl & >( *this );
      }
    };



    // ValidatorDefault
    // ----------------

    template< class T, class Impl >
    class ValidatorDefault
    {
      typedef ValidatorDefault< T, Impl > ThisType;
      typedef ValidatorInterface< T, Impl > BaseType;

    protected:
      ValidatorDefault () {}

    private:
      ValidatorDefault ( const ThisType & );
      ThisType &operator= ( const ThisType & );

    private:
      bool operator () ( const T &value ) const;
      void print ( std::ostream &s ) const;
    };


    
    template< class T >
    class ValidateGreater
    : public ValidatorDefault< T, ValidateGreater< T > >
    {
      typedef ValidateGreater< T > ThisType;
      typedef ValidatorDefault< T, ThisType > BaseType;

    public:
      ValidateGreater ( const T &threshold )
      : threshold_( threshold )
      {}

      ValidateGreater ( const ThisType &other )
      : threshold_( other.threshold_ )
      {}

    public:
      bool operator() ( const T &value ) const
      {
        return value > threshold_;
      }

      void print(std::ostream& s) const
      {
        s << "ValidateLess: valid values are: > " << threshold_ << std::endl << std::endl;
      }

    protected:
      const T threshold_;
    };



    template< class T >
    class ValidateLess
    : public ValidatorDefault< T, ValidateLess< T > >
    {
      typedef ValidateLess< T > ThisType;
      typedef ValidatorDefault< T, ThisType > BaseType;

    public:
      ValidateLess ( const T &threshold )
      : threshold_( threshold )
      {}

      ValidateLess ( const ThisType &other )
      : threshold_( other.threshold_ )
      {}

      bool operator() ( const T &value ) const
      {
        return value < threshold_;
      }

      void print(std::ostream& s) const
      {
        s << "ValidateLess: valid values are: < " << threshold_ << std::endl << std::endl;
      }

    protected:
      const T threshold_;
    };



    template< class T >
    class ValidateNotGreater
    : public ValidatorDefault< T, ValidateNotGreater< T > >
    {
      typedef ValidateNotGreater< T > ThisType;
      typedef ValidatorDefault< T, ThisType > BaseType;

    public:
      ValidateNotGreater ( const T &threshold )
      : threshold_( threshold )
      {}

      ValidateNotGreater ( const ThisType &other )
      : threshold_( other.threshold_ )
      {}

      bool operator() ( const T &value ) const
      {
        return value <= threshold_;
      }

      void print(std::ostream& s) const
      {
        s << "ValidateNotGreater: valid values are: <= " << threshold_ << std::endl << std::endl;
      }

    protected:
      const T threshold_;
    };



    template< class T >
    class ValidateNotLess
    : public ValidatorDefault< T, ValidateNotLess< T > >
    {
      typedef ValidateNotLess< T > ThisType;
      typedef ValidatorDefault< T, ThisType > BaseType;

    public:
      ValidateNotLess ( const T &threshold )
      : threshold_( threshold )
      {}

      ValidateNotLess ( const ThisType &other )
      : threshold_( other.threshold_ )
      {}

      bool operator() ( const T &value ) const
      {
        return value >= threshold_;
      }

      void print(std::ostream& s) const
      {
        s << "ValidateNotLess: valid values are: >= " << threshold_ << std::endl << std::endl;
      }

    protected:
      const T threshold_;
    };



    template< class T, bool leftClosed, bool rightClosed >
    class ValidateInterval
    : public ValidatorDefault< T, ValidateInterval< T, leftClosed, rightClosed > >
    {
      typedef ValidateInterval< T, leftClosed, rightClosed > ThisType;
      typedef ValidatorDefault< T, ThisType > BaseType;

    public:
      ValidateInterval ( const T &lThreshold, const T &rThreshold )
      : lThreshold_( lThreshold ),
        rThreshold_( rThreshold )
      {}

      ValidateInterval ( const ThisType &other )
      : lThreshold_( other.lThreshold_ ),
        rThreshold_( other.rThreshold_ )
      {}

      bool operator() ( const T &value ) const
      {
        bool ret = true;
        ret &= (leftClosed  ? value >= lThreshold_ : value > lThreshold_);
        ret &= (rightClosed ? value <= rThreshold_ : value < rThreshold_);
        return ret;
      }

      void print(std::ostream& s) const
      {
        const char* left  = (leftClosed)  ? "[" : "(";
        const char* right = (rightClosed) ? "]" : ")";
        s << "ValidateInterval: valid values are " << left << lThreshold_ << "," <<
                rThreshold_ << right << std::endl << std::endl;
      }

    protected:
      const T lThreshold_, rThreshold_;
    };



    // NoWhiteSpaceValidator
    // ---------------------

    class NoWhiteSpaceValidator
    : public ValidatorDefault< std::string, NoWhiteSpaceValidator >
    {
      typedef NoWhiteSpaceValidator ThisType;
      typedef ValidatorDefault< std::string, ThisType > BaseType;

    public:
      NoWhiteSpaceValidator ()
      {}

      NoWhiteSpaceValidator ( const ThisType &other )
      {}

      bool operator() ( const std::string &value ) const
      {
        return (value.find_first_of( " \t" ) == std::string::npos);
      }

      void print ( std::ostream &s ) const
      {
        s << "NoWhiteSpaceValidator" << std::endl;
      }
    };

  } // namespace Fem

} // namespace Dune 

#endif // #ifndef DUNE_FEM_VALIDATOR_HH
