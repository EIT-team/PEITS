/**************************************************************************
 
  The dune-fem module is a module of DUNE (see www.dune-project.org).
  It is based on the dune-grid interface library 
  extending the grid interface by a number of discretization algorithms
  for solving non-linear systems of partial differential equations.

  Copyright (C) 2003 - 2013 Robert Kloefkorn
  Copyright (C) 2003 - 2010 Mario Ohlberger 
  Copyright (C) 2004 - 2013 Andreas Dedner
  Copyright (C) 2005        Adrian Burri
  Copyright (C) 2005 - 2012 Mirko Kraenkel
  Copyright (C) 2006 - 2013 Christoph Gersbacher
  Copyright (C) 2006 - 2013 Martin Nolte
  Copyright (C) 2011 - 2013 Tobias Malkmus

  The dune-fem module is free software; you can redistribute it and/or 
  modify it under the terms of the GNU General Public License as 
  published by the Free Software Foundation; either version 2 of 
  the License, or (at your option) any later version.

  The dune-fem module is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along
  with this program; if not, write to the Free Software Foundation, Inc.,
  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 
**************************************************************************/
#ifndef DUNE_FEM_PASS_LOCAL_HH
#define DUNE_FEM_PASS_LOCAL_HH

#include <sstream>
#include <string>

#include <dune/fem/pass/common/pass.hh>

namespace Dune 
{

  namespace Fem
  {

    // External forward declaration
    // ----------------------------

    template <class DiscreteModelImp, class PreviousPassImp , int passIdImp >
    class Pass;

    // LocalPass
    // ---------

    /** \brief Specialisation of Pass which provides a grid walk-through,
     *         but leaves open what needs to be done on each elements.
     *
     *  \tparam  DiscreteModelImp  discrete model
     *  \tparam  PreviousPassImp   previous pass
     *  \tparam  passIdImp         id for this pass
     */
    template< class DiscreteModelImp, class PreviousPassImp , int passIdImp >
    class LocalPass
    : public Pass< DiscreteModelImp , PreviousPassImp , passIdImp>
    {
    public:
      //! \brief type of the preceding pass
      typedef PreviousPassImp PreviousPassType;

      //! \brief base class
      typedef Pass< DiscreteModelImp , PreviousPassImp , passIdImp > BaseType;

      /** \brief The type of the argument (and destination) type of
       *         the overall operator
       */
      typedef typename BaseType::TotalArgumentType ArgumentType;

      //! \brief the discrete function representing the return value of this pass
      typedef typename DiscreteModelImp::Traits::DestinationType DestinationType;
      //! \brief the discrete function space belonging to destinationtype
      typedef typename DiscreteModelImp::Traits::DiscreteFunctionSpaceType DiscreteFunctionSpaceType;
      //! \brief iterator over the space
      typedef typename DiscreteFunctionSpaceType::IteratorType IteratorType;
      //! \brief the codim 0 entity
      typedef typename DiscreteFunctionSpaceType::EntityType EntityType;

      // deprecated type
      typedef EntityType  Entity;

    public:
      /** \brief constructor
       *  \param pass Previous pass
       *  \param spc Space belonging to the discrete function of this pass.
       *  \param passName an identifier for this pass
       */
      LocalPass (PreviousPassImp &pass,
                 const DiscreteFunctionSpaceType &spc,
                 std::string passName = "LocalPass")
      : BaseType(pass),
        spc_(spc),
        passName_(passName),
        computeTime_(0.0),
        numberOfElements_( 0 ),
        passIsActive_( true )
      {}

      //! \brief destructor
      virtual ~LocalPass () {}

      //! \brief build up local memory
      virtual void allocateLocalMemory ()
      {
        if (!this->destination_)
        {
          std::ostringstream funcName;
          funcName << passName_ << "_" << this->passNumber();
          this->destination_ = new DestinationType(funcName.str(), spc_);

          // set mem handle for deleting destination_
          this->deleteHandler_ = &(BaseType::DeleteHandlerType::instance());
        }
      }

      //! \brief return reference to space
      const DiscreteFunctionSpaceType &space () const { return spc_; }

      /** \brief return accumulated time needed by pass's operator () this method
       *         also resets the compute time to zero
       */
      virtual double computeTime () const
      {
        double ct = computeTime_;
        computeTime_ = 0.0;
        return ct;
      }

      /** \brief return number of elements visited during operator computation */
      virtual size_t numberOfElements() const { return numberOfElements_; }

      /** \brief return true if pass is active */
      bool active () const { return passIsActive_; }

      /** \brief set pass status to active */
      void enable () const { passIsActive_ = true ; }

      /** \brief set pass status to inactive */
      void disable() const { passIsActive_ = false ; }

    protected:
      //! Actions to be carried out before a global grid walkthrough.
      //! To be overridden in a derived class.
      virtual void prepare (const ArgumentType &arg, DestinationType &dest) const = 0;
      //! Actions to be carried out after a global grid walkthrough.
      //! To be overridden in a derived class.
      virtual void finalize (const ArgumentType &arg, DestinationType &dest) const = 0;
      //! Actions to be taken on every element. To be overridden in a derived 
      //! class.
      virtual void applyLocal (const EntityType &en ) const = 0;

    public:
      //! The actual computations are performed as follows. First, prepare
      //! the grid walkthrough, then call applyLocal on each entity and then
      //! call finalize.
      void compute (const ArgumentType &arg, DestinationType &dest) const
      {
        // if pass was disable, don't do computation 
        if( ! active() ) return ;

        // get stopwatch
        Dune::Timer timer;

        prepare(arg, dest);

        numberOfElements_ = 0 ;
        const IteratorType endit = spc_.end();
        for (IteratorType it = spc_.begin(); it != endit; ++it, ++ numberOfElements_ )
        {
          applyLocal(*it);
        }

        finalize(arg, dest);

        // accumulate time
        computeTime_ += timer.elapsed();
      }

    protected:
      const DiscreteFunctionSpaceType &spc_;
      const std::string passName_;
      mutable double computeTime_;
      mutable size_t numberOfElements_; 
      mutable bool passIsActive_;
    };

  } // namespace Fem

#if DUNE_FEM_COMPATIBILITY
  // put this in next version 1.4
  using Fem::LocalPass;
#endif // DUNE_FEM_COMPATIBILITY

} // namespace Dune

#endif // #ifndef DUNE_FEM_PASS_LOCAL_HH
