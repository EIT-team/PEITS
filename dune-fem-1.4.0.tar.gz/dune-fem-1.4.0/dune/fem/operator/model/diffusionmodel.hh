/**************************************************************************
 
  The dune-fem module is a module of DUNE (see www.dune-project.org).
  It is based on the dune-grid interface library 
  extending the grid interface by a number of discretization algorithms
  for solving non-linear systems of partial differential equations.

  Copyright (C) 2003 - 2013 Robert Kloefkorn
  Copyright (C) 2003 - 2010 Mario Ohlberger 
  Copyright (C) 2004 - 2013 Andreas Dedner
  Copyright (C) 2005        Adrian Burri
  Copyright (C) 2005 - 2012 Mirko Kraenkel
  Copyright (C) 2006 - 2013 Christoph Gersbacher
  Copyright (C) 2006 - 2013 Martin Nolte
  Copyright (C) 2011 - 2013 Tobias Malkmus

  The dune-fem module is free software; you can redistribute it and/or 
  modify it under the terms of the GNU General Public License as 
  published by the Free Software Foundation; either version 2 of 
  the License, or (at your option) any later version.

  The dune-fem module is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along
  with this program; if not, write to the Free Software Foundation, Inc.,
  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 
**************************************************************************/
#ifndef DUNE_FEM_DIFFUSIONMODEL_HH
#define DUNE_FEM_DIFFUSIONMODEL_HH

#include <dune/common/fvector.hh>

#include <dune/fem/misc/bartonnackmaninterface.hh>

namespace Dune
{

  namespace Fem 
  {

    /*! \ingroup EllipticOperator
     *  \class DiffusionModelInterface
     *  \brief Interface for a mathematical model of a DiffusionOperator
     *
     *  The DiffusionModelInterface specifies the way mathematical data can
     *  be incorporated into a DiffusionOperator, i.e. a linear operator
     *  performing
     *  \f[
     *  -\nabla \cdot \bigl( a( x ) \nabla u \bigr).
     *  \f]
     *  Here the mathematical data is exactly the function \f$a\f$, which we call
     *  diffusive flux.
     *
     *  \param  FunctionSpace   function space to work in
     *  \param  DiffusionModel  actual implementation (Barton-Nackman)
     */
    template< class FunctionSpace, class DiffusionModel >
    class DiffusionModelInterface
    : public BartonNackmanInterface
      < DiffusionModelInterface< FunctionSpace, DiffusionModel >,
        DiffusionModel >
    {
    public:
      //! type of the function space we are using
      typedef FunctionSpace FunctionSpaceType;

      //! type of the implementation (Barton-Nackman)
      typedef DiffusionModel DiffusionModelType;

    private:
      typedef DiffusionModelInterface< FunctionSpaceType, DiffusionModelType >
        ThisType;
      typedef BartonNackmanInterface< ThisType, DiffusionModelType > BaseType;

    public:
      //! type of the interface
      typedef ThisType DiffusionModelInterfaceType;

      //! type of points within the domain
      typedef typename FunctionSpaceType :: DomainType DomainType;
      //! type of points within the range
      typedef typename FunctionSpaceType :: RangeType RangeType;
      //! type of the Jacobian (evaluated in some point)
      typedef typename FunctionSpaceType :: JacobianRangeType JacobianRangeType;

      //! field type of the domain
      typedef typename FunctionSpaceType :: DomainFieldType DomainFieldType;
      //! field type of the range
      typedef typename FunctionSpaceType :: RangeFieldType RangeFieldType;

    protected:
      using BaseType :: asImp;

    public:
      /** \brief calculate the diffusive flux \f$a( x ) \nabla u\f$ in a point
       *
       *  \param[in]  diffVariable  vector describin the partial derivative to
       *                            evaluate
       *  \param[in]  entity        entity to evaluate the flux on
       *  \param[in]  x             evaluation point (in local coordinates)
       *  \param[in]  gradient      \f$\nabla u\f$ in the evaluation point
       *  \param[out] flux          variable to receive the evaluated flux
       */
      template< int diffOrder, class EntityType, class PointType >
      inline void diffusiveFlux ( const FieldVector< int, diffOrder > &diffVariable,
                                  const EntityType &entity,
                                  const PointType &x,
                                  const JacobianRangeType &gradient,
                                  JacobianRangeType &flux ) const
      {
        CHECK_AND_CALL_INTERFACE_IMPLEMENTATION
          ( asImp().diffusiveFlux( diffVariable, entity, x, gradient, flux ) );
      }

      /** \brief calculate the diffusive flux \f$a( x ) \nabla u\f$ in a point
       *
       *  \param[in]  entity      entity to evaluate the flux on
       *  \param[in]  x           evaluation point (in local coordinates)
       *  \param[in]  gradient    \f$\nabla u\f$ in the evaluation point
       *  \param[out] flux        variable to receive the evaluated flux
       */
      template< class EntityType, class PointType >
      inline void diffusiveFlux ( const EntityType &entity,
                                  const PointType &x,
                                  const JacobianRangeType &gradient,
                                  JacobianRangeType &flux ) const
      {
        CHECK_AND_CALL_INTERFACE_IMPLEMENTATION
          ( asImp().diffusiveFlux( entity, x, gradient, flux ) );
      }
    };


    
    template< class FunctionSpaceImp, class DiffusionModelImp >
    class DiffusionModelDefault
    : public DiffusionModelInterface< FunctionSpaceImp, DiffusionModelImp >
    {
    public:
      //! type of the function space we are using
      typedef FunctionSpaceImp FunctionSpaceType;

      //! type of the implementation (Barton-Nackman)
      typedef DiffusionModelImp DiffusionModelType;

    private:
      typedef DiffusionModelDefault< FunctionSpaceType, DiffusionModelType >
        ThisType;
      typedef DiffusionModelInterface< FunctionSpaceType, DiffusionModelType >
        BaseType;

    public:
      //! type of points within the domain
      typedef typename FunctionSpaceType :: DomainType DomainType;
      //! type of points within the range
      typedef typename FunctionSpaceType :: RangeType RangeType;
      //! type of the Jacobian (evaluated in some point)
      typedef typename FunctionSpaceType :: JacobianRangeType JacobianRangeType;

      //! field type of the domain
      typedef typename FunctionSpaceType :: DomainFieldType DomainFieldType;
      //! field type of the range
      typedef typename FunctionSpaceType :: RangeFieldType RangeFieldType;

    public:
      using BaseType :: diffusiveFlux;

    protected:
      using BaseType :: asImp;

    public:
      /** \copydoc Dune::Fem::DiffusionModelInterface::diffusiveFlux(const EntityType &entity,const PointType &x,const JacobianRangeType &gradient,JacobianRangeType &flux) const
       *
       *  The default implementation calls
       *  \code
       *  FieldVector< int, 0 > diffVar;
       *  diffusiveFlux( diffVar, entity, x, gradient, flux );
       *  \endcode
       */
      template< class EntityType, class PointType >
      inline void diffusiveFlux ( const EntityType &entity,
                                  const PointType &x,
                                  const JacobianRangeType &gradient,
                                  JacobianRangeType &flux ) const
      {
        FieldVector< int, 0 > diffVar;
        asImp().diffusiveFlux( diffVar, entity, x, gradient, flux );
      }
    };

  } // namespace Fem

#if DUNE_FEM_COMPATIBILITY  
  // put this in next version 1.4 

  using Fem :: DiffusionModelDefault ;

#endif // DUNE_FEM_COMPATIBILITY
  
} // namespace Dune

#endif // #ifndef DUNE_FEM_DIFFUSIONMODEL_HH
