/**************************************************************************
 
  The dune-fem module is a module of DUNE (see www.dune-project.org).
  It is based on the dune-grid interface library 
  extending the grid interface by a number of discretization algorithms
  for solving non-linear systems of partial differential equations.

  Copyright (C) 2003 - 2013 Robert Kloefkorn
  Copyright (C) 2003 - 2010 Mario Ohlberger 
  Copyright (C) 2004 - 2013 Andreas Dedner
  Copyright (C) 2005        Adrian Burri
  Copyright (C) 2005 - 2012 Mirko Kraenkel
  Copyright (C) 2006 - 2013 Christoph Gersbacher
  Copyright (C) 2006 - 2013 Martin Nolte
  Copyright (C) 2011 - 2013 Tobias Malkmus

  The dune-fem module is free software; you can redistribute it and/or 
  modify it under the terms of the GNU General Public License as 
  published by the Free Software Foundation; either version 2 of 
  the License, or (at your option) any later version.

  The dune-fem module is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along
  with this program; if not, write to the Free Software Foundation, Inc.,
  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 
**************************************************************************/
#ifndef DUNE_FEM_LINEARELLIPTICMODEL_HH
#define DUNE_FEM_LINEARELLIPTICMODEL_HH

#include <dune/common/bartonnackmanifcheck.hh>

#include <dune/fem/operator/model/diffusionmodel.hh>
#include <dune/fem/operator/model/boundarymodel.hh>

namespace Dune
{

  namespace Fem
  {

    /** \ingroup EllipticOperator
     */

    struct DefaultLinearEllipticModelProperties
    {
      static const bool hasDirichletValues = true;
      static const bool hasNeumannValues = true;
      static const bool hasRobinValues = true;
      static const bool hasGeneralizedNeumannValues = true;
      static const bool hasConvectiveFlux = true;
      static const bool hasMass = true;
      static const bool hasSource = true;
    };



    /** \class LinearEllipticModelInterface
     *  \brief interface for models of linear elliptic problems
     *
     *  This class models the data for equations of the following type:
     *  \f{displaymath}
     *    -\nabla \cdot (a(x) \nabla u) + \nabla \cdot (b( x ) u) + c( x ) u = f( x )
     *  \f}
     *  Here, the data functions are
     *  - \b a : the diffusive flux
     *  - \b b : the convective flux
     *  - \b c : the mass
     *  - \b f : the source
     *  .
     *  Additionally, boundary conditions are modelled by this class. For details,
     *  see BoundaryModelInterface.
     *
     *  Beside the properties of a BoundaryModelInterface, a LinearEllipticModel
     *  has the following properties:
     *  - \b hasConvectiveFlux : The convective flux is nontrivial
     *  - \b hasMass           : The mass in nontrivial
     *  - \b hasSource         : The source is nontrivial
     *  . 
     *  If one of these properties is \b false, the solver does not need to
     *  evaluate the corresponding terms. This may speed up the program.
     *
     *  \param  FunctionSpaceImp        function space to work in
     *  \param  LinearEllipticModelImp  actual implementation (Barton-Nackman)
     *  \param  PropertiesImp           properties of the implementation
     */
    template< class FunctionSpaceImp,
              class LinearEllipticModelImp,
              class PropertiesImp >
    class LinearEllipticModelInterface
    : public DiffusionModelInterface< FunctionSpaceImp, LinearEllipticModelImp >,
      public BoundaryModelInterface< FunctionSpaceImp, LinearEllipticModelImp, PropertiesImp >
    {
    public:
      //! type of the function space
      typedef FunctionSpaceImp FunctionSpaceType;

      //! type of the implementation (Barton-Nackman)
      typedef LinearEllipticModelImp LinearEllipticModelType;

      //! type properties the properties structure
      typedef PropertiesImp Properties;

    private:
      typedef LinearEllipticModelInterface
        < FunctionSpaceType, LinearEllipticModelType, Properties >
        ThisType;
      typedef DiffusionModelInterface< FunctionSpaceType, LinearEllipticModelType >
        BaseType;

    public:
      //! type of the interface
      typedef ThisType LinearEllipticModelInterfaceType;

      //! type of points within the domain
      typedef typename FunctionSpaceType :: DomainType DomainType;
      //! type of points within the range
      typedef typename FunctionSpaceType :: RangeType RangeType;
      //! type of the Jacobian (evaluated in some point)
      typedef typename FunctionSpaceType :: JacobianRangeType JacobianRangeType;

      //! field type of the domain
      typedef typename FunctionSpaceType :: DomainFieldType DomainFieldType;
      //! field type of the range
      typedef typename FunctionSpaceType :: RangeFieldType RangeFieldType;

    protected:
      using BaseType :: asImp;
      
    public:
      /** \brief evaluate the convective flux in a point
       *
       *  \param[in]   entity      entity to evaluate the flux on
       *  \param[in]   x           evaluaton point (in local coordinates)
       *  \param[in]   phi         value of the solution in the evaluation point
       *  \param[out]  flux        variable to receive the evaluated flux
       */
      template< class EntityType, class PointType >
      inline void convectiveFlux ( const EntityType &entity,
                                   const PointType &x,
                                   const RangeType &phi,
                                   JacobianRangeType &flux ) const
      {
        assert( Properties :: hasConvectiveFlux );
        CHECK_AND_CALL_INTERFACE_IMPLEMENTATION
          ( asImp().convectiveFlux( entity, x, phi, flux ) );
      }
     
      /** \brief evaluate the mass in a point
       *
       *  \param[in]   entity      entity to evaluate the mass on
       *  \param[in]   x           evaluaton point (in local coordinates)
       *  \param[out]  ret         variable to receive the evaluated mass
       */
      template< class EntityType, class PointType >
      inline void mass ( const EntityType &entity,
                         const PointType &x,
                         RangeType &ret ) const
      {
        assert( Properties :: hasMass );
        CHECK_AND_CALL_INTERFACE_IMPLEMENTATION
          ( asImp().mass( entity, x, ret ) );
      }

      /** \brief evaluate the source in a point
       *
       *  \param[in]   entity      entity to evaluate the source on
       *  \param[in]   x           evaluaton point (in local coordinates)
       *  \param[out]  ret         variable to receive the evaluated source
       */
      template< class EntityType, class PointType >
      inline void source ( const EntityType &entity,
                           const PointType &x,
                           RangeType &ret ) const
      {
        assert( Properties :: hasSource );
        CHECK_AND_CALL_INTERFACE_IMPLEMENTATION
          ( asImp().source( entity, x, ret ) );
      }
    };



    template< class FunctionSpaceImp,
              class LinearEllipticModelImp,
              class PropertiesImp
                = DefaultLinearEllipticModelProperties >
    class LinearEllipticModelDefault
    : public LinearEllipticModelInterface< FunctionSpaceImp, LinearEllipticModelImp, PropertiesImp >
    {
    public:
      typedef FunctionSpaceImp FunctionSpaceType;
      typedef PropertiesImp Properties;

    private:
      typedef LinearEllipticModelDefault
        < FunctionSpaceType, LinearEllipticModelImp, Properties >
        ThisType;
      typedef LinearEllipticModelInterface
        < FunctionSpaceType, LinearEllipticModelImp, Properties >
        BaseType;

      typedef BoundaryModelDefault< FunctionSpaceType, LinearEllipticModelImp, Properties >
        BoundaryModelDefaultType;

    public:
      using BaseType :: diffusiveFlux;
      using BaseType :: convectiveFlux;
      using BaseType :: mass;
      using BaseType :: source;

    protected:
      using BaseType :: asImp;

    private:
      const BoundaryModelDefaultType boundaryModelDefault_;

    public:
      typedef typename FunctionSpaceType :: DomainType DomainType;
      typedef typename FunctionSpaceType :: RangeType RangeType;
      typedef typename FunctionSpaceType :: JacobianRangeType JacobianRangeType;

      typedef typename FunctionSpaceType :: DomainFieldType DomainFieldType;
      typedef typename FunctionSpaceType :: RangeFieldType RangeFieldType;
      
    public:
      LinearEllipticModelDefault ()
      : boundaryModelDefault_()
      {}
      
      template< class IntersectionType, class QuadratureType >
      void dirichletValues ( const IntersectionType &intersection,
                             const QuadratureType &quadrature,
                             int point,
                             RangeType &phi ) const
      {
        boundaryModelDefault_.dirichletValues( intersection, quadrature, point, phi );
      }

      template< class IntersectionType, class QuadratureType >
      void neumannValues ( const IntersectionType &intersection,
                           const QuadratureType &quadrature,
                           int point,
                           RangeType &phi ) const
      {
        boundaryModelDefault_.neumannValues( intersection, quadrature, point, phi );
      }
      
      template< class IntersectionType, class QuadratureType >
      void robinValues ( const IntersectionType &intersection,
                         const QuadratureType &quadrature,
                         int point,
                         RangeType &phi ) const
      {
        boundaryModelDefault_.robinValues( intersection, quadrature, point, phi );
      }

      template< class IntersectionType, class QuadratureType >
      RangeFieldType robinAlpha ( IntersectionType &intersection,
                                  QuadratureType &quadrature,
                                  int point ) const
      {
        return boundaryModelDefault_.robinAlpha( intersection, quadrature, point );
      }
      
      /** \copydoc Dune::Fem::DiffusionModelInterface::diffusiveFlux(const EntityType &entity,const PointType &x,const JacobianRangeType &gradient,JacobianRangeType &flux) const
       *
       *  The default implementation calls
       *  \code
       *  FieldVector< int, 0 > diffVar;
       *  diffusiveFlux( diffVar, entity, x, gradient, flux );
       *  \endcode
       */
      template< class EntityType, class PointType >
      inline void diffusiveFlux ( const EntityType &entity,
                                  const PointType &x,
                                  const JacobianRangeType &gradient,
                                  JacobianRangeType &flux ) const
      {
        FieldVector< int, 0 > diffVar;
        asImp().diffusiveFlux( diffVar, entity, x, gradient, flux );
      }
     
      /** \copydoc Dune::Fem::LinearEllipticModelInterface::convectiveFlux(const EntityType &entity,const PointType &x,const RangeType &phi,JacobianRangeType &flux) const
       *
       *  The default implementation returns 0.
       */
      template< class EntityType, class PointType >
      inline void convectiveFlux ( const EntityType &entity,
                                   const PointType &x,
                                   const RangeType &phi,
                                   JacobianRangeType &flux ) const
      {
        assert( Properties :: hasConvectiveFlux );
        flux = 0;
      }

      /** \copydoc Dune::Fem::LinearEllipticModelInterface::mass(const EntityType &entity,const PointType &x,RangeType &ret) const
       *
       *  The default implementation returns 0.
       */
      template< class EntityType, class PointType >
      inline void mass ( const EntityType &entity,
                         const PointType &x,
                         RangeType &ret ) const
      {
        assert( Properties :: hasMass );
        ret = 0;
      }

      /** \copydoc Dune::Fem::LinearEllipticModelInterface::source(const EntityType &entity,const PointType &x,RangeType &ret) const
       *
       *  The default implementation returns 0.
       */
      template< class EntityType, class PointType >
      inline void source ( const EntityType &entity,
                           const PointType &x,
                           RangeType &ret ) const
      {
        assert( Properties :: hasSource );
        ret = 0;
      }
    };

  } // namespace Fem

#if DUNE_FEM_COMPATIBILITY  
  // put this in next version 1.4 

  using Fem :: LinearEllipticModelDefault ;

#endif // DUNE_FEM_COMPATIBILITY
 
} // namespace Dune

#endif // #ifndef DUNE_FEM_LINEARELLIPTICMODEL_HH
