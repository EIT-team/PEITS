/**************************************************************************
 
  The dune-fem module is a module of DUNE (see www.dune-project.org).
  It is based on the dune-grid interface library 
  extending the grid interface by a number of discretization algorithms
  for solving non-linear systems of partial differential equations.

  Copyright (C) 2003 - 2013 Robert Kloefkorn
  Copyright (C) 2003 - 2010 Mario Ohlberger 
  Copyright (C) 2004 - 2013 Andreas Dedner
  Copyright (C) 2005        Adrian Burri
  Copyright (C) 2005 - 2012 Mirko Kraenkel
  Copyright (C) 2006 - 2013 Christoph Gersbacher
  Copyright (C) 2006 - 2013 Martin Nolte
  Copyright (C) 2011 - 2013 Tobias Malkmus

  The dune-fem module is free software; you can redistribute it and/or 
  modify it under the terms of the GNU General Public License as 
  published by the Free Software Foundation; either version 2 of 
  the License, or (at your option) any later version.

  The dune-fem module is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along
  with this program; if not, write to the Free Software Foundation, Inc.,
  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 
**************************************************************************/
#ifndef DUNE_FEM_L2PROJECTION_HH
#define DUNE_FEM_L2PROJECTION_HH

#include <dune/fem/quadrature/cachingquadrature.hh>
#include <dune/fem/operator/common/operator.hh>
#include <dune/fem/function/common/discretefunction.hh>
#include <dune/fem/function/common/gridfunctionadapter.hh>
#include <dune/fem/operator/1order/localmassmatrix.hh>

#include "dgl2projection.hh"

namespace Dune 
{

  // deprecated class (use DGL2Projection instead)
  struct L2ProjectionImpl : public Fem::DGL2ProjectionImpl
  {
    //! project function onto discrete function space  
    template <class FunctionImp, class DiscreteFunctionImp>
    DUNE_VERSION_DEPRECATED( 1, 4, remove )
    static void project(const FunctionImp& f, DiscreteFunctionImp& discFunc, int polOrd = -1)
    {
      DGL2ProjectionImpl :: project( f, discFunc, polOrd );
    }
  };

  /*======================================================================*/
  /*! @ingroup L2ProjectionOperator
   *  \class L2Projection
   *  \brief The L2Projection class provides methods for projecting a function
   *         unto a given discrete function space. Note that this implementation
   *         assumes orthorgonal base functions!
   */
  /*======================================================================*/
  template <typename DFieldType, typename RFieldType,
            typename DType , typename RType>
  class L2Projection : public Operator<DFieldType, RFieldType,DType , RType> {
   public:
    typedef DType DomainType;
    typedef RType  RangeType;
    typedef DFieldType DomainFieldType;
    typedef RFieldType RangeFieldType;

    //! Constructor taking degree for quadrature rule
    //! if no argument given a default value is chosen depending on the order
    //! in the discrete function space
    DUNE_VERSION_DEPRECATED(1,4,remove)
    L2Projection(int polOrd = -1) : polOrd_(polOrd) {}

    //! apply L2 projection
    virtual void operator() (const DomainType& f, RangeType& discFunc) const 
    {
      if( discFunc.space().continuous() )
        DUNE_THROW(NotImplemented,"L2-Projection not implemented for contiuous spaces!"); 
      else 
        Fem::DGL2ProjectionImpl::project(f,discFunc,polOrd_);
    }

  protected:
    const int polOrd_;
  };

  namespace Fem 
  { 

    /*! @ingroup L2ProjectionOperator
     *  \class L2Projection
     *  \brief The L2Projection class provides methods for projecting a function
     *         unto a given discrete function space. Note that this implementation
     *         assumes orthorgonal base functions!
     */
    template < class DType, class RType>
    class L2Projection : public Operator<DType , RType> 
    {
    public:
      //! domain function type 
      typedef DType  DomainType;
      //! range function type 
      typedef RType  RangeType;

      /** \brief Constructor 
       *    \param  quadOrder      degree for quadrature rule (default = 2*space.order())
       *    \param  doCommunicate  apply communication for the result (default = true)
       */    
      explicit L2Projection( const int quadOrder = -1, 
                             const bool doCommunicate = true ) 
        : quadOrder_( quadOrder ), doCommunicate_( doCommunicate ) 
      {}

      /** \brief  calculates the L2 projection of a function onto the 
       *          discrete space discreteFunction belongs to.
       *  \param  function          function to be projected 
       *  \param  discreteFunction  discrete result of projection  */
      virtual void operator() ( const DomainType& function, RangeType& discreteFunction ) const 
      {
        if( discreteFunction.space().continuous() )
          DUNE_THROW(NotImplemented,"L2-Projection not implemented for contiuous spaces!"); 
        else 
          DGL2ProjectionImpl::project( function, discreteFunction, quadOrder_, doCommunicate_ );
      }

    protected:
      const int quadOrder_;          // order of quadrature  
      const bool doCommunicate_ ; // true if communication is applied for the result 
    };

  } // namespace Fem 

} // namespace Dune

#endif // #ifndef DUNE_FEM_L2PROJECTION_HH
