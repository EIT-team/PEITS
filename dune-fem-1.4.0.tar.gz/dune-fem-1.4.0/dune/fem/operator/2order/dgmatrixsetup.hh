/**************************************************************************
 
  The dune-fem module is a module of DUNE (see www.dune-project.org).
  It is based on the dune-grid interface library 
  extending the grid interface by a number of discretization algorithms
  for solving non-linear systems of partial differential equations.

  Copyright (C) 2003 - 2013 Robert Kloefkorn
  Copyright (C) 2003 - 2010 Mario Ohlberger 
  Copyright (C) 2004 - 2013 Andreas Dedner
  Copyright (C) 2005        Adrian Burri
  Copyright (C) 2005 - 2012 Mirko Kraenkel
  Copyright (C) 2006 - 2013 Christoph Gersbacher
  Copyright (C) 2006 - 2013 Martin Nolte
  Copyright (C) 2011 - 2013 Tobias Malkmus

  The dune-fem module is free software; you can redistribute it and/or 
  modify it under the terms of the GNU General Public License as 
  published by the Free Software Foundation; either version 2 of 
  the License, or (at your option) any later version.

  The dune-fem module is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along
  with this program; if not, write to the Free Software Foundation, Inc.,
  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 
**************************************************************************/
#ifndef DUNE_DGMATRIXSETUP_HH
#define DUNE_DGMATRIXSETUP_HH

#include <dune/common/timer.hh>

#include <dune/fem/function/common/scalarproducts.hh>
#include <dune/fem/space/common/commoperations.hh>
#include <dune/fem/misc/functor.hh>

#if HAVE_DUNE_ISTL
#include <dune/istl/operators.hh>
#include <dune/fem/operator/matrix/istlmatrix.hh>
#include <dune/fem/operator/matrix/preconditionerwrapper.hh>
#endif

namespace Dune 
{

  ////////////////////////////////////////////////////////////
  //
  //  Setup of matrix structure 
  //
  ////////////////////////////////////////////////////////////
  /**  \brief Setup Matrix structure for DG operators by including
   * elements and it's neighbors. 
  */
  class ElementAndNeighbors
  {
  public:
    //! get number of entries per row for a block matrix, 
    //! i.e. here number of (neighbors + 1) * maxNumDofs 
    template <class Space> 
    static inline int nonZerosEstimate(const Space& space) 
    {
      return ((Space :: GridType :: dimension * 2) + 1) 
        * space.blockMapper().maxNumDofs() * Space :: localBlockSize ; 
    }

    //! create entries for element and neighbors 
    template <class SpaceImp,    
              class RowMapperType,
              class ColMapperType,
              class MatrixStructureMapImp > 
    static inline void setup(const SpaceImp& space,    
                             const RowMapperType& rowMapper,
                             const ColMapperType& colMapper,
                             MatrixStructureMapImp& indices )
    {
      typedef typename SpaceImp :: GridPartType GridPartType;
      const GridPartType& gridPart = space.gridPart();

      // define used types 
      typedef typename GridPartType :: GridType GridType;
      typedef typename GridPartType :: template Codim<0> :: EntityType    EntityType;
      typedef typename GridPartType :: template Codim<0> :: IteratorType  IteratorType;

      // clear map 
      indices.clear();

      // we need All_Partition here to insert overlap entities 
      // only for diagonal 
      IteratorType endit = gridPart.template end<0>(); 
      for(IteratorType it = gridPart.template begin<0>(); it != endit; ++it)
      {
        const EntityType & en = *it;
        // add all column entities to row  
        fill( gridPart, en, rowMapper, colMapper, indices );
      }
    }

  protected:
    template <class GK>
    struct FillFunctor
    {
      typedef std :: set< int >  LocalIndicesType;
      typedef GK GlobalKey;

      FillFunctor ( std::map<int,LocalIndicesType> &indices )
      : indices_(indices),
        localIndices_(0)
      {}

      void set ( const std::size_t rowLocal, const GlobalKey &rowGlobal )
      {
        localIndices_ = &(indices_[ rowGlobal ]);
      }

      template < class ColGlobal >
      void operator() ( const std::size_t colLocal, const ColGlobal &colGlobal )
      {
        localIndices_->insert( colGlobal );
      }

    private:
      std::map<int,LocalIndicesType> &indices_;
      LocalIndicesType *localIndices_;
    };

    //! create entries for element and neighbors 
    template <class GridPartImp,
              class EntityImp,
              class RowMapperImp,
              class ColMapperImp >
    static inline void fill(const GridPartImp& gridPart,
                     const EntityImp& en,
                     const RowMapperImp& rowMapper,
                     const ColMapperImp& colMapper,
                     std::map< int , std::set<int> >& indices )
    {
      typedef FillFunctor<typename RowMapperImp::GlobalKeyType> Functor;
      typedef Fem::MatrixFunctor<ColMapperImp,EntityImp,Functor > MFunctor;

      rowMapper.mapEach( en, MFunctor( colMapper, en, Functor( indices ) ) );

      // insert neighbors 
      typedef typename GridPartImp::template Codim<0>::EntityPointerType EntityPointerType; 
      typedef typename GridPartImp:: IntersectionIteratorType IntersectionIteratorType;
      typedef typename IntersectionIteratorType :: Intersection IntersectionType;
      IntersectionIteratorType endnit = gridPart.iend(en);
      for(IntersectionIteratorType nit = gridPart.ibegin(en);
          nit != endnit; ++nit)
      {
        // get intersection 
        const IntersectionType& inter = *nit;

        if( inter.neighbor() )
        {
          // get neighbor 
          EntityPointerType ep = inter.outside();
          const EntityImp& nb = *ep;

          // insert (en,nb) matrix
          rowMapper.mapEach( nb, MFunctor( colMapper, en, Functor( indices ) ) );

#if HAVE_MPI 
          // overlap element, we insert the (nb, en) matrix
          if( nb.partitionType() == OverlapEntity )
            rowMapper.mapEach( en, MFunctor( colMapper, nb, Functor( indices ) ) );
#endif
        }
      }
    }
  };


  template <class TraitsImp>
  struct DGMatrixTraits
  {
    typedef typename TraitsImp :: RowSpaceType RowSpaceType;
    typedef typename TraitsImp :: ColumnSpaceType ColumnSpaceType;

    typedef ElementAndNeighbors StencilType; 
    
    typedef Fem::ParallelScalarProduct < ColumnSpaceType > ParallelScalarProductType;
  };
  
#if HAVE_DUNE_ISTL
  // forward 
  template <class MatrixImp>
  class DGParallelMatrixAdapter;

  // specialization for ISTL matrices 
  template <class RowSpaceImp, class ColSpaceImp>
  struct DGMatrixTraits<Fem::ISTLMatrixTraits<RowSpaceImp,ColSpaceImp> >
  {
    typedef RowSpaceImp RowSpaceType;
    typedef ColSpaceImp ColumnSpaceType;

    typedef ElementAndNeighbors StencilType; 
    
    typedef Fem::ParallelScalarProduct < ColumnSpaceType > ParallelScalarProductType;

    template <class MatrixImp>
    struct Adapter
    {   
      // type of matrix adapter 
      typedef DGParallelMatrixAdapter<MatrixImp> MatrixAdapterType;
    };
  };
  
  /*! 
    \brief Adapter to turn a matrix into a linear operator.
    Adapts a matrix to the assembled linear operator interface
  */
  template <class MatrixImp>
  class DGParallelMatrixAdapter
    : public AssembledLinearOperator< MatrixImp,
               typename MatrixImp :: RowBlockVectorType,
               typename MatrixImp :: ColBlockVectorType>
  {
    typedef DGParallelMatrixAdapter< MatrixImp > ThisType ;
  public:
    typedef MatrixImp MatrixType;
    typedef Fem::PreconditionerWrapper<MatrixType> PreconditionAdapterType;
    
    typedef typename MatrixType :: RowDiscreteFunctionType RowDiscreteFunctionType;
    typedef typename MatrixType :: ColDiscreteFunctionType ColumnDiscreteFunctionType;

    typedef typename RowDiscreteFunctionType :: DiscreteFunctionSpaceType RowSpaceType;

    typedef typename ColumnDiscreteFunctionType :: DiscreteFunctionSpaceType ColSpaceType;
    typedef Fem::ParallelScalarProduct<ColumnDiscreteFunctionType> ParallelScalarProductType;
    
    typedef typename RowDiscreteFunctionType :: DofStorageType     X;
    typedef typename ColumnDiscreteFunctionType :: DofStorageType  Y;
  
    //! export types
    typedef MatrixType  matrix_type;
    typedef X domain_type;
    typedef Y range_type;
    typedef typename X::field_type field_type;

    //! define the category
    enum { category=SolverCategory::sequential };

  protected:  
    MatrixType& matrix_;
    const RowSpaceType& rowSpace_;
    const ColSpaceType& colSpace_;

    ParallelScalarProductType scp_;

    PreconditionAdapterType preconditioner_;
    mutable double averageCommTime_;

  public:  
    //! constructor: just store a reference to a matrix
    DGParallelMatrixAdapter (const DGParallelMatrixAdapter& org)
      : matrix_(org.matrix_) 
      , rowSpace_(org.rowSpace_)
      , colSpace_(org.colSpace_)
      , scp_(colSpace_)
      , preconditioner_(org.preconditioner_)
      , averageCommTime_( org.averageCommTime_ )
    {}

    //! constructor: just store a reference to a matrix
    DGParallelMatrixAdapter (MatrixType& A,
                             const RowSpaceType& rowSpace, 
                             const ColSpaceType& colSpace,
                             const PreconditionAdapterType& precon )
      : matrix_(A) 
      , rowSpace_(rowSpace)
      , colSpace_(colSpace)
      , scp_(colSpace_)
      , preconditioner_( precon ) 
      , averageCommTime_( 0.0 )
    {}

    //! return communication time 
    double averageCommTime() const 
    {
      return averageCommTime_ ;
    }

    //! return reference to preconditioner 
    PreconditionAdapterType& preconditionAdapter() { return preconditioner_; }

    //! return reference to preconditioner 
    ParallelScalarProductType& scp() { return scp_; }

    //! apply operator to x:  \f$ y = A(x) \f$
    virtual void apply (const X& x, Y& y) const
    {
      // exchange data first 
      communicate( x );

      // apply vector to matrix 
      matrix_.mv( x, y );

      // delete non-interior 
      scp_.deleteNonInterior( y );
    }

    //! apply operator to x, scale and add:  \f$ y = y + \alpha A(x) \f$
    virtual void applyscaleadd (field_type alpha, const X& x, Y& y) const
    {
      // exchange data first 
      communicate( x );
      
      // apply matrix 
      matrix_.usmv( alpha, x, y );

      // delete non-interior 
      scp_.deleteNonInterior( y );
    }

    virtual double residuum(const Y& rhs, X& x) const 
    {
      // exchange data  
      communicate( x );
      
      typedef typename ParallelScalarProductType :: SlaveDofsType SlaveDofsType;
      const SlaveDofsType& slaveDofs = scp_.slaveDofs();
      
      typedef typename Y :: block_type LittleBlockVectorType;
      LittleBlockVectorType tmp; 
      double res = 0.0;
      
      // counter for rows 
      int i = 0;
      const int slaveSize = slaveDofs.size();
      for(int slave = 0; slave<slaveSize; ++slave)
      {
        const int nextSlave = slaveDofs[slave];
        for(; i<nextSlave; ++i) 
        {
          tmp = 0;
          // get row 
          typedef typename MatrixType :: row_type row_type;

          const row_type& row = matrix_[i];
          // multiply with row  
          typedef typename MatrixType :: ConstColIterator ConstColIterator;
          ConstColIterator endj = row.end();
          for (ConstColIterator j = row.begin(); j!=endj; ++j)
          {
            (*j).umv(x[j.index()], tmp);
          } 
          
          // substract right hand side 
          tmp -= rhs[i];
          
          // add scalar product 
          res += tmp.two_norm2();
        } 
        ++i;
      }

      res = rowSpace_.gridPart().comm().sum( res );
      // return global sum of residuum 
      return std::sqrt( res );
    }

    //! get matrix via *
    virtual const MatrixType& getmat () const
    {
      return matrix_;
    }
  protected:
    void communicate( const X& x ) const
    {
      if( rowSpace_.gridPart().comm().size() <= 1 ) return ;

      Timer commTime;

      // create temporary discretet function object 
      RowDiscreteFunctionType tmp ("DGParallelMatrixAdapter::communicate",
                                    rowSpace_, x );

      // exchange data by copying 
      rowSpace_.communicate( tmp );

      // accumulate communication time 
      averageCommTime_ += commTime.elapsed();
    }
  };
#endif

} // end namespace Dune 
#endif
