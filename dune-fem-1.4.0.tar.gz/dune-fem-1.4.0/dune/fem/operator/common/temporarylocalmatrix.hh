/**************************************************************************
 
  The dune-fem module is a module of DUNE (see www.dune-project.org).
  It is based on the dune-grid interface library 
  extending the grid interface by a number of discretization algorithms
  for solving non-linear systems of partial differential equations.

  Copyright (C) 2003 - 2013 Robert Kloefkorn
  Copyright (C) 2003 - 2010 Mario Ohlberger 
  Copyright (C) 2004 - 2013 Andreas Dedner
  Copyright (C) 2005        Adrian Burri
  Copyright (C) 2005 - 2012 Mirko Kraenkel
  Copyright (C) 2006 - 2013 Christoph Gersbacher
  Copyright (C) 2006 - 2013 Martin Nolte
  Copyright (C) 2011 - 2013 Tobias Malkmus

  The dune-fem module is free software; you can redistribute it and/or 
  modify it under the terms of the GNU General Public License as 
  published by the Free Software Foundation; either version 2 of 
  the License, or (at your option) any later version.

  The dune-fem module is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along
  with this program; if not, write to the Free Software Foundation, Inc.,
  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 
**************************************************************************/
#ifndef DUNE_FEM_TEMPORARYLOCALMATRIX_HH
#define DUNE_FEM_TEMPORARYLOCALMATRIX_HH

#include <dune/fem/storage/array.hh>
#include <dune/fem/operator/common/localmatrix.hh>

namespace Dune
{

  namespace Fem 
  {

    /** \ingroup Matrix
     *  \class TemporaryLocalMatrix
     *  \brief A local matrix with a small array as storage
     *
     *  A TemporaryLocalMatrix is an implementation of the LocalMatrixInterface
     *  storing the matrix values in an array. It is useful when generating
     *  multiple local matrices that shall then be added together.
     *
     *  \note Due to the backing array, accesses to the matrix should be very fast.
     *
     *  \param DomainSpaceImp  DiscreteFunctionSpace modelling the domain
     *  \param RangeSpaceImp   DiscreteFunctionSpace modelling the range
     */
    template< class DomainSpaceImp, class RangeSpaceImp >
    class TemporaryLocalMatrix;


    
    template< class DomainSpaceImp, class RangeSpaceImp >
    struct TemporaryLocalMatrixTraits
    {
      typedef DomainSpaceImp DomainSpaceType;
      typedef RangeSpaceImp RangeSpaceType;
      
      typedef TemporaryLocalMatrix< DomainSpaceType, RangeSpaceType >
        LocalMatrixType;

      typedef typename DomainSpaceType :: RangeFieldType DomainFieldType;
      typedef typename RangeSpaceType :: RangeFieldType RangeFieldType;
      typedef RangeFieldType LittleBlockType;
    };


    
    template< class DomainSpaceImp, class RangeSpaceImp >
    class TemporaryLocalMatrix
    : public LocalMatrixDefault
      < TemporaryLocalMatrixTraits< DomainSpaceImp, RangeSpaceImp > >
    {
    public:
      typedef DomainSpaceImp DomainSpaceType;
      typedef RangeSpaceImp RangeSpaceType;

      typedef TemporaryLocalMatrixTraits< DomainSpaceType, RangeSpaceType >
        Traits;

    private:
      typedef TemporaryLocalMatrix< DomainSpaceType, RangeSpaceType >
        ThisType;
      typedef LocalMatrixDefault< Traits > BaseType;

    public:
      using BaseType :: rows;
      using BaseType :: columns;

    public:
      typedef typename Traits :: DomainFieldType DomainFieldType;
      typedef typename Traits :: RangeFieldType RangeFieldType;

    protected:
      Fem :: DynamicArray< RangeFieldType > fields_;

    public:
      inline TemporaryLocalMatrix ( const DomainSpaceType &domainSpace,
                                    const RangeSpaceType &rangeSpace )
      : BaseType( domainSpace, rangeSpace ),
        fields_()
      {
      }

      template< class DomainEntityType, class RangeEntityType >
      inline TemporaryLocalMatrix ( const DomainSpaceType &domainSpace,
                                    const RangeSpaceType &rangeSpace,
                                    const DomainEntityType &domainEntity,
                                    const RangeEntityType &rangeEntity )
      : BaseType( domainSpace, rangeSpace, domainEntity, rangeEntity ),
        fields_( rows() * columns() )
      {
      }

      
      /** \copydoc Dune::Fem::LocalMatrixInterface::init */
      template< class DomainEntityType, class RangeEntityType >
      inline void init ( const DomainEntityType &domainEntity,
                         const RangeEntityType &rangeEntity )
      {
        BaseType :: init( domainEntity, rangeEntity );
        fields_.resize( rows() * columns() );
      }

      /** \copydoc Dune::Fem::LocalMatrixInterface::add */
      inline void add ( const int localRow,
                        const int localCol,
                        const RangeFieldType &value )
      {
        assert( (localRow >= 0) && (localRow < rows()) );
        assert( (localCol >= 0) && (localCol < columns()) );
        fields_[ localRow * columns() + localCol ] += value;
      }

      /** \copydoc Dune::Fem::LocalMatrixInterface::set */
      inline void set ( const int localRow, 
                        const int localCol, 
                        const RangeFieldType &value )
      {
        assert( (localRow >= 0) && (localRow < rows()) );
        assert( (localCol >= 0) && (localCol < columns()) );
        fields_[ localRow * columns() + localCol ] = value;
      }

      inline const RangeFieldType get ( const int localRow, 
                                        const int localCol ) const
      {
        assert( (localRow >= 0) && (localRow < rows()) );
        assert( (localCol >= 0) && (localCol < columns()) );
        return fields_[ localRow * columns() + localCol ];
      }

      /** \copydoc Dune::Fem::LocalMatrixInterface::clear */
      inline void clear ()
      {
        fields_.assign( 0 );
      }
    };

  } // namespace Fem

#if DUNE_FEM_COMPATIBILITY  
  // put this in next version 1.4 

  using Fem :: TemporaryLocalMatrix ;

#endif // DUNE_FEM_COMPATIBILITY
  
} // namespace Dune

#endif // #ifndef DUNE_FEM_TEMPORARYLOCALMATRIX_HH
