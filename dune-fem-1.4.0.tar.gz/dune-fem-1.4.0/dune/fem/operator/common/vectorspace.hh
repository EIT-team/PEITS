/**************************************************************************
 
  The dune-fem module is a module of DUNE (see www.dune-project.org).
  It is based on the dune-grid interface library 
  extending the grid interface by a number of discretization algorithms
  for solving non-linear systems of partial differential equations.

  Copyright (C) 2003 - 2013 Robert Kloefkorn
  Copyright (C) 2003 - 2010 Mario Ohlberger 
  Copyright (C) 2004 - 2013 Andreas Dedner
  Copyright (C) 2005        Adrian Burri
  Copyright (C) 2005 - 2012 Mirko Kraenkel
  Copyright (C) 2006 - 2013 Christoph Gersbacher
  Copyright (C) 2006 - 2013 Martin Nolte
  Copyright (C) 2011 - 2013 Tobias Malkmus

  The dune-fem module is free software; you can redistribute it and/or 
  modify it under the terms of the GNU General Public License as 
  published by the Free Software Foundation; either version 2 of 
  the License, or (at your option) any later version.

  The dune-fem module is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along
  with this program; if not, write to the Free Software Foundation, Inc.,
  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 
**************************************************************************/
#ifndef DUNE_VECTORSPACE_HH
#define DUNE_VECTORSPACE_HH

// is this file still needed ???

namespace Dune{

 /** \ingroup Mapping 
  * \brief Vector class
  * This is the base class for all methods and operators.

   An instance of this class is an element of an vector space. 
   Elements of vector spaces can be added and multiplied by a 
   scalar.
 */
template <typename Field> 
class Vector 
{
public:

    virtual ~Vector() {};

  //virtual Vector<Field> operator + (const Vector<Field> &) const = 0;
  //virtual Vector<Field> operator - (const Vector<Field> &) const = 0;
  //virtual Vector<Field> operator * (const Field &) const = 0;
  //virtual Vector<Field> operator / (const Field &) const = 0;
  
  /** \brief Assignment operator
      \note Only returns itself...
  */
  virtual Vector<Field>& operator  = (const Vector<Field> &) { return *this;};

  //! Addition
  virtual Vector<Field>& operator += (const Vector<Field> &) = 0;
  //! Subtraction
  virtual Vector<Field>& operator -= (const Vector<Field> &) = 0;
  //! Multiplication
  virtual Vector<Field>& operator *= (const Field &) = 0;
  //! Division
  virtual Vector<Field>& operator /= (const Field &) = 0;
};

}


#endif
