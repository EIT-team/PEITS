/**************************************************************************
 
  The dune-fem module is a module of DUNE (see www.dune-project.org).
  It is based on the dune-grid interface library 
  extending the grid interface by a number of discretization algorithms
  for solving non-linear systems of partial differential equations.

  Copyright (C) 2003 - 2013 Robert Kloefkorn
  Copyright (C) 2003 - 2010 Mario Ohlberger 
  Copyright (C) 2004 - 2013 Andreas Dedner
  Copyright (C) 2005        Adrian Burri
  Copyright (C) 2005 - 2012 Mirko Kraenkel
  Copyright (C) 2006 - 2013 Christoph Gersbacher
  Copyright (C) 2006 - 2013 Martin Nolte
  Copyright (C) 2011 - 2013 Tobias Malkmus

  The dune-fem module is free software; you can redistribute it and/or 
  modify it under the terms of the GNU General Public License as 
  published by the Free Software Foundation; either version 2 of 
  the License, or (at your option) any later version.

  The dune-fem module is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along
  with this program; if not, write to the Free Software Foundation, Inc.,
  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 
**************************************************************************/
// vim: set expandtab ts=2 sw=2 sts=2:
#ifndef DUNE_FEM_AUTOMATICDIFFERENCEOPERATOR_HH
#define DUNE_FEM_AUTOMATICDIFFERENCEOPERATOR_HH

#include <limits>

#include <dune/common/nullptr.hh>

#include <dune/fem/io/parameter.hh>
#include <dune/fem/operator/common/differentiableoperator.hh>

namespace Dune
{

  namespace Fem
  {

    // Internal Forward Declarations
    // -----------------------------

    template< class DomainFunction, class RangeFunction, class LinearOperator >
    class AutomaticDifferenceOperator;



    // AutomaticDifferenceLinearOperator
    // ---------------------------------

    template< class DomainFunction, class RangeFunction = DomainFunction >
    class AutomaticDifferenceLinearOperator
    : public Dune::Fem::Operator< DomainFunction, RangeFunction >
    {
      typedef AutomaticDifferenceLinearOperator< DomainFunction, RangeFunction > ThisType;
      typedef Dune::Fem::Operator< DomainFunction, RangeFunction > BaseType;

      friend class AutomaticDifferenceOperator< DomainFunction, RangeFunction, ThisType >;

    public:
      typedef Dune::Fem::Operator< DomainFunction, RangeFunction > OperatorType;

      typedef typename BaseType::RangeFunctionType RangeFunctionType;
      typedef typename BaseType::DomainFunctionType DomainFunctionType;
      typedef typename BaseType::RangeFieldType RangeFieldType;
      typedef typename BaseType::DomainFieldType DomainFieldType;

      typedef typename RangeFunctionType::DiscreteFunctionSpaceType RangeSpaceType;
      typedef typename DomainFunctionType::DiscreteFunctionSpaceType DomainSpaceType;

      AutomaticDifferenceLinearOperator ( const std::string &name, const DomainSpaceType &dSpace, const RangeSpaceType &rSpace )
      : name_( name ),
        op_( 0 ), // initial value for op_ is 'undefined'
        u_( 0 ), // initial value for u_ is 'undefined'
        b_( "AutomaticDifferenceOperator::b_", dSpace ),
        op_u_( "AutomaticDifferenceOperator::op_u_", rSpace ),
        norm_u_( 0 )
      {}

      virtual void operator() ( const DomainFunctionType &arg, RangeFunctionType &dest ) const;

    private:
      void set ( const DomainFunctionType &u, const OperatorType &op, const RangeFieldType &eps );

      const std::string name_;
      const OperatorType *op_;
      const DomainFunctionType *u_;

      mutable DomainFunctionType b_;
      RangeFunctionType op_u_;

      RangeFieldType eps_;
      RangeFieldType norm_u_;
    };



    // AutomaticDifferenceOperator
    // ---------------------------

    /** \class AutomaticDifferenceOperator
     *  \brief operator providing a Jacobian through automatic differentiation
     *
     *  \note The Jacobian operator is an on-the-fly operator, i.e., it does
     *        not store a matrix but only implements the application.
     */
    template< class DomainFunction, class RangeFunction = DomainFunction,
              class LinearOperator = AutomaticDifferenceLinearOperator< DomainFunction, RangeFunction > >
    class AutomaticDifferenceOperator
    : public Dune::Fem::DifferentiableOperator< LinearOperator >
    {
      typedef Dune::Fem::DifferentiableOperator< LinearOperator > BaseType;

    public:
      typedef typename BaseType::RangeFunctionType RangeFunctionType;
      typedef typename BaseType::DomainFunctionType DomainFunctionType;
      typedef typename BaseType::RangeFieldType RangeFieldType;
      typedef typename BaseType::DomainFieldType DomainFieldType;

      typedef typename BaseType::JacobianOperatorType JacobianOperatorType;

      typedef typename RangeFunctionType::DiscreteFunctionSpaceType RangeSpaceType;
      typedef typename DomainFunctionType::DiscreteFunctionSpaceType DomainSpaceType;

      AutomaticDifferenceOperator ()
      : eps_( Parameter::getValue< RangeFieldType >( "fem.differenceoperator.eps", RangeFieldType( 0 ) ) )
      {}

      explicit AutomaticDifferenceOperator ( const RangeFieldType &eps )
      : eps_( eps )
      {}

      virtual void jacobian ( const DomainFunctionType &u, JacobianOperatorType &jOp ) const
      {
        jOp.set( u, *this, eps_ );
      }

    private:
      const RangeFieldType eps_;
    };



    // Implementation of AutomaticDifferenceLinearOperator
    // ---------------------------------------------------

    template< class DomainFunction, class RangeFunction >
    inline void AutomaticDifferenceLinearOperator< DomainFunction, RangeFunction >
      ::operator() ( const DomainFunctionType &arg, RangeFunctionType &dest ) const
    {
      assert( op_ && u_ );

      // 'Normal' difference-quotient, i.e.
      // dest = 1/eps (op_(*u +eps*arg) - op_(*u))
      //
      // eps is chosen dynamically, the same way as in
      // dune-fem/dune/fem/solver/ode/quasi_exact_newton.cpp, see also
      // http://www.freidok.uni-freiburg.de/volltexte/3762/pdf/diss.pdf, page 137
      RangeFieldType eps = eps_;
      if( eps <= RangeFieldType( 0 ) )
      {
        const RangeFieldType machine_eps = std::numeric_limits< RangeFieldType >::epsilon();
        const RangeFieldType norm_p_sq = arg.scalarProductDofs( arg );
        if( norm_p_sq > machine_eps )
          eps = std::sqrt( (RangeFieldType( 1 ) + norm_u_) * machine_eps / norm_p_sq );
        else
          eps = std::sqrt( machine_eps );
      }

      b_.assign( *u_ );
      b_.axpy( eps, arg );
      (*op_)( b_, dest );
      dest -= op_u_;
      dest *= RangeFieldType( 1 ) / eps;
    }


    template< class DomainFunction, class RangeFunction >
    inline void AutomaticDifferenceLinearOperator< DomainFunction, RangeFunction >
      ::set ( const DomainFunctionType &u, const OperatorType &op, const RangeFieldType &eps )
    {
      u_ = &u;
      op_ = &op;
      (*op_)( *u_, op_u_ );

      eps_ = eps;
      if( eps_ <= RangeFieldType( 0 ) )
        norm_u_ = std::sqrt( u_->scalarProductDofs( *u_ ) );
    }

  } // namespace Fem

} // namespace Dune

#endif // #ifndef DUNE_FEM_AUTOMATICDIFFERENCEOPERATOR_HH
