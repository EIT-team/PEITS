/**************************************************************************
 
  The dune-fem module is a module of DUNE (see www.dune-project.org).
  It is based on the dune-grid interface library 
  extending the grid interface by a number of discretization algorithms
  for solving non-linear systems of partial differential equations.

  Copyright (C) 2003 - 2013 Robert Kloefkorn
  Copyright (C) 2003 - 2010 Mario Ohlberger 
  Copyright (C) 2004 - 2013 Andreas Dedner
  Copyright (C) 2005        Adrian Burri
  Copyright (C) 2005 - 2012 Mirko Kraenkel
  Copyright (C) 2006 - 2013 Christoph Gersbacher
  Copyright (C) 2006 - 2013 Martin Nolte
  Copyright (C) 2011 - 2013 Tobias Malkmus

  The dune-fem module is free software; you can redistribute it and/or 
  modify it under the terms of the GNU General Public License as 
  published by the Free Software Foundation; either version 2 of 
  the License, or (at your option) any later version.

  The dune-fem module is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along
  with this program; if not, write to the Free Software Foundation, Inc.,
  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 
**************************************************************************/
#ifndef DUNE_FEM_DIFFERENTIABLEOPERATOR_HH
#define DUNE_FEM_DIFFERENTIABLEOPERATOR_HH

#include <dune/fem/operator/common/operator.hh>

namespace Dune
{

  namespace Fem
  {

    /** \class DifferentiableOperator
     *  \brief abstract differentiable operator
     *
     *  Differentiable operators are operators providing a linearization.
     *
     *  \tparam  JacobianOperator  type of linear operator describing the Jacobian
     *                             (linearization) of this operator
     *
     *  \note The types for the operator's domain and range function are derived
     *        from the JacobianOperator.
     *
     *  \interfaceclass
     */
    template< class JacobianOperator >
    class DifferentiableOperator
    : public virtual Dune::Fem::Operator< typename JacobianOperator::DomainFunctionType,
                                          typename JacobianOperator::RangeFunctionType >
    {
      typedef Dune::Fem::Operator< typename JacobianOperator::DomainFunctionType,
                                   typename JacobianOperator::RangeFunctionType > BaseType;

    public:
      /** \brief type of linear operator modelling the operator's Jacobian */
      typedef JacobianOperator JacobianOperatorType;

      /** \brief type of discrete function in the operator's domain */
      typedef typename BaseType::DomainFunctionType DomainFunctionType;
      /** \brief type of discrete function in the operator's range */
      typedef typename BaseType::RangeFunctionType RangeFunctionType;

      /** \brief field type of the operator's domain */
      typedef typename DomainFunctionType::RangeFieldType DomainFieldType;
      /** \brief field type of the operator's range */
      typedef typename RangeFunctionType::RangeFieldType RangeFieldType;

      /** \brief obtain linearization
       *
       *  \param[in]   u    argument discrete function
       *  \param[out]  jOp  destination Jacobian operator
       *
       *  \note This method has to be implemented by all derived classes.
       */
      virtual void jacobian ( const DomainFunctionType &u, JacobianOperatorType &jOp ) const = 0;
    };

  } // namespace Fem

} // namespace Dune

#endif // #ifndef DUNE_FEM_DIFFERENTIABLEOPERATOR_HH
