/**************************************************************************
 
  The dune-fem module is a module of DUNE (see www.dune-project.org).
  It is based on the dune-grid interface library 
  extending the grid interface by a number of discretization algorithms
  for solving non-linear systems of partial differential equations.

  Copyright (C) 2003 - 2013 Robert Kloefkorn
  Copyright (C) 2003 - 2010 Mario Ohlberger 
  Copyright (C) 2004 - 2013 Andreas Dedner
  Copyright (C) 2005        Adrian Burri
  Copyright (C) 2005 - 2012 Mirko Kraenkel
  Copyright (C) 2006 - 2013 Christoph Gersbacher
  Copyright (C) 2006 - 2013 Martin Nolte
  Copyright (C) 2011 - 2013 Tobias Malkmus

  The dune-fem module is free software; you can redistribute it and/or 
  modify it under the terms of the GNU General Public License as 
  published by the Free Software Foundation; either version 2 of 
  the License, or (at your option) any later version.

  The dune-fem module is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along
  with this program; if not, write to the Free Software Foundation, Inc.,
  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 
**************************************************************************/
#ifndef DUNE_FEM_LAGRANGEINTERPOLATION_HH
#define DUNE_FEM_LAGRANGEINTERPOLATION_HH

#include <dune/common/typetraits.hh>

#include <dune/fem/version.hh>
#include <dune/fem/function/common/gridfunctionadapter.hh>
#include <dune/fem/misc/iteratorprovider.hh>
#include <dune/fem/operator/common/operator.hh>


namespace Dune 
{

  namespace Fem 
  {

    /** \class LagrangeInterpolation
     *  \brief Generates the Lagrange Interpolation of an analytic function
     */
    template< class Function, class DiscreteFunction,
              class IteratorProvider = Fem::IteratorProvider< typename DiscreteFunction::DiscreteFunctionSpaceType > >
    class LagrangeInterpolation : public Operator< Function, DiscreteFunction >
    {
      typedef LagrangeInterpolation< Function, DiscreteFunction > ThisType;

    public:
      //! type of discrete functions
      typedef DiscreteFunction DiscreteFunctionType;

      //! type of discrete function space
      typedef typename DiscreteFunctionType::DiscreteFunctionSpaceType
        DiscreteFunctionSpaceType;
      //! type of local functions
      typedef typename DiscreteFunctionType::LocalFunctionType
        LocalFunctionType;

      //! type of grid partition
      typedef typename DiscreteFunctionSpaceType::GridPartType GridPartType;

      //! type of Lagrange point set
      typedef typename DiscreteFunctionSpaceType::LagrangePointSetType
        LagrangePointSetType;
      //! type of vectors in function's domain
      typedef typename DiscreteFunctionSpaceType::DomainType DomainType;
      //! type of vectors in function's range
      typedef typename DiscreteFunctionSpaceType::RangeType RangeType;

    public:
      //! empty contructor 
      LagrangeInterpolation () {}

      //! virtual destructor because of inheritance from Operator  
      virtual ~LagrangeInterpolation () {}

      /** interpolate an analytical function into a Lagrange discrete function
       *
       *  This Method evaluates the given function (which can be evaluated
       *  globally) at the Lagrange points and writes the values into a discrete
       *  function.
       *
       *  \param[in] function function to interpolate
       *
       *  \param[out] discreteFunction discrete function to receive the
       *              interpolation
       */
      void operator () ( const Function &function,
                         DiscreteFunctionType &discreteFunction ) const 
      {
        interpolateFunction( function, discreteFunction ); 
      }

      /** interpolate an analytical function into a Lagrange discrete function
       *
       *  This Method evaluates the given function (which can be evaluated
       *  globally) at the Lagrange points and writes the values into a discrete
       *  function.
       *
       *  \param[in] function function to interpolate
       *
       *  \param[out] discreteFunction discrete function to receive the
       *              interpolation
       */
      static void interpolateFunction ( const Function &function, DiscreteFunctionType &discreteFunction )
      {
        const bool hasLocalFunction = Conversion< Function, HasLocalFunction >::exists;
        interpolateFunction( function, discreteFunction, integral_constant< bool, hasLocalFunction >() );
      }

      //! \copydoc interpolateFunction 
      //- make interface equal to DGL2Projection 
      static void apply ( const Function &function, DiscreteFunctionType &discreteFunction )
      {
        interpolateFunction( function, discreteFunction );
      }

    private:
      static void interpolateFunction ( const Function &function, DiscreteFunctionType &discreteFunction, integral_constant< bool, true > )
      {
        interpolateDiscreteFunction( function, discreteFunction );
      }

      static void interpolateFunction ( const Function &function, DiscreteFunctionType &discreteFunction, integral_constant< bool, false > )
      {
        typedef GridFunctionAdapter< Function, GridPartType > GridFunctionType;

        const DiscreteFunctionSpaceType &dfSpace = discreteFunction.space();
        GridFunctionType dfAdapter( "function", function, dfSpace.gridPart() );
        interpolateDiscreteFunction( dfAdapter, discreteFunction );
      }

      template< class GridFunction >
      static void interpolateDiscreteFunction ( const GridFunction &function, DiscreteFunctionType &discreteFunction );
    };


    
    template< class Function, class DiscreteFunction, class IteratorProvider >
    template< class GridFunction >
    inline void LagrangeInterpolation< Function, DiscreteFunction, IteratorProvider >
      ::interpolateDiscreteFunction ( const GridFunction &function,
                                      DiscreteFunctionType &discreteFunction )
    {
      typedef typename DiscreteFunctionType::DofType DofType;
      typedef typename DiscreteFunctionType::DofIteratorType DofIteratorType;
      typedef typename IteratorProvider::IteratorType IteratorType;
      static const int dimRange = DiscreteFunctionSpaceType::dimRange;

      typedef typename GridFunction::LocalFunctionType FunctionLocalFunctionType;

      // set all DoFs to infinity
      const DofIteratorType dend = discreteFunction.dend();
      for( DofIteratorType dit = discreteFunction.dbegin(); dit != dend; ++dit )
        *dit = std::numeric_limits< DofType >::infinity();

      const DiscreteFunctionSpaceType &dfSpace = discreteFunction.space();

      IteratorProvider iteratorProvider( dfSpace );

      const IteratorType end = iteratorProvider.end();
      for( IteratorType it = iteratorProvider.begin(); it != end; ++it )
      {
        const LagrangePointSetType &lagrangePointSet
          = dfSpace.lagrangePointSet( *it );

        FunctionLocalFunctionType f_local = function.localFunction( *it );
        LocalFunctionType df_local = discreteFunction.localFunction( *it );

        // assume point based local dofs 
        const int nop = lagrangePointSet.nop();
        int k = 0;
        for( int qp = 0; qp < nop; ++qp )
        {
          // if the first DoF for this point is already valid, continue
          if( df_local[ k ] == std::numeric_limits< DofType >::infinity() )
          {
            // evaluate the function in the Lagrange point
            RangeType phi;
            f_local.evaluate( lagrangePointSet[ qp ], phi );

            // assign the appropriate values to the DoFs
            for( int i = 0; i < dimRange; ++i, ++k )
              df_local[ k ] = phi[ i ];
          }
          else
            k += dimRange;
        }
      }
    }

  } // namespace Fem 


  /** \class LagrangeInterpolation
   *  \brief Generates the Lagrange Interpolation of an analytic function
   */
  template< class DiscreteFunction >
  class LagrangeInterpolation
  {
    typedef LagrangeInterpolation< DiscreteFunction > ThisType;

  public:
    //! type of discrete functions
    typedef DiscreteFunction DiscreteFunctionType;

    //! type of discrete function space
    typedef typename DiscreteFunctionType::DiscreteFunctionSpaceType
      DiscreteFunctionSpaceType;
    //! type of local functions
    typedef typename DiscreteFunctionType::LocalFunctionType
      LocalFunctionType;

    //! type of grid partition
    typedef typename DiscreteFunctionSpaceType::GridPartType GridPartType;

    //! type of Lagrange point set
    typedef typename DiscreteFunctionSpaceType::LagrangePointSetType
      LagrangePointSetType;
    //! type of vectors in function's domain
    typedef typename DiscreteFunctionSpaceType::DomainType DomainType;
    //! type of vectors in function's range
    typedef typename DiscreteFunctionSpaceType::RangeType RangeType;

  public:
    /** interpolate an analytical function into a Lagrange discrete function
     *
     *  This Method evaluates the given function (which can be evaluated
     *  globally) at the Lagrange points and writes the values into a discrete
     *  function.
     *
     *  \param[in] function function to interpolate
     *
     *  \param[out] discreteFunction discrete function to receive the
     *              interpolation
     */
    template< class Function >
    DUNE_VERSION_DEPRECATED(1,4,remove)
    static void interpolateFunction ( const Function &function,
                                      DiscreteFunctionType &discreteFunction )
    {
      // forward to new implementation 
      Fem :: LagrangeInterpolation< Function, DiscreteFunctionType > 
        :: interpolateFunction ( function, discreteFunction );
    }

    //! \copydoc interpolateFunction 
    //- make interface equal to DGL2Projection 
    template< class Function >
    DUNE_VERSION_DEPRECATED(1,4,remove)
    static void apply ( const Function &function,
                        DiscreteFunctionType &discreteFunction )
    {
      interpolateFunction( function, discreteFunction );
    }
  };

} // namespace Dune

#endif // #ifndef DUNE_FEM_LAGRANGEINTERPOLATION_HH
