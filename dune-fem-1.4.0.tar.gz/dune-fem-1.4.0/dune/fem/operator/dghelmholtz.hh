/**************************************************************************
 
  The dune-fem module is a module of DUNE (see www.dune-project.org).
  It is based on the dune-grid interface library 
  extending the grid interface by a number of discretization algorithms
  for solving non-linear systems of partial differential equations.

  Copyright (C) 2003 - 2013 Robert Kloefkorn
  Copyright (C) 2003 - 2010 Mario Ohlberger 
  Copyright (C) 2004 - 2013 Andreas Dedner
  Copyright (C) 2005        Adrian Burri
  Copyright (C) 2005 - 2012 Mirko Kraenkel
  Copyright (C) 2006 - 2013 Christoph Gersbacher
  Copyright (C) 2006 - 2013 Martin Nolte
  Copyright (C) 2011 - 2013 Tobias Malkmus

  The dune-fem module is free software; you can redistribute it and/or 
  modify it under the terms of the GNU General Public License as 
  published by the Free Software Foundation; either version 2 of 
  the License, or (at your option) any later version.

  The dune-fem module is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along
  with this program; if not, write to the Free Software Foundation, Inc.,
  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 
**************************************************************************/
#ifndef DUNE_FEM_OPERATOR_DGHELMHOLTZ_HH
#define DUNE_FEM_OPERATOR_DGHELMHOLTZ_HH

#include <dune/fem/operator/common/operator.hh>
#include <dune/fem/operator/common/differentiableoperator.hh>


namespace Dune
{

  namespace Fem
  {

    // DGHelmholtzJacobianOperator
    // ---------------------------

    template< class JacobianOp >
    class DGHelmholtzJacobianOperator
    : public Operator< typename JacobianOp::DomainFunctionType, typename JacobianOp::RangeFunctionType >
    {
      typedef DGHelmholtzJacobianOperator< JacobianOp > ThisType;
      typedef Operator< typename JacobianOp::DomainFunctionType, typename JacobianOp::RangeFunctionType > BaseType;

      template< class > friend class DGHelmholtzOperator;

    public:
      typedef typename BaseType::DomainFunctionType DomainFunctionType;
      typedef typename BaseType::RangeFunctionType RangeFunctionType;

      typedef typename DomainFunctionType::DiscreteFunctionSpaceType DomainFunctionSpaceType;
      typedef typename RangeFunctionType::DiscreteFunctionSpaceType RangeFunctionSpaceType;

      DGHelmholtzJacobianOperator ( const std::string &name, const DomainFunctionSpaceType &dSpace, const RangeFunctionSpaceType &rSpace )
      : jacobianOp_( name, dSpace, rSpace ),
        lambda_( 0 ),
        wTmp_( "DGHelmholtzJacobianOperator temporary", rSpace )
      {}

      void operator() ( const DomainFunctionType &u, RangeFunctionType &w ) const
      {
        w.assign( u );
        if( lambda() != 0.0 )
        {
          jacobianOp_( u, wTmp_ );
          w.axpy( -lambda(), wTmp_ );
        }
      }

      const double &lambda () const { return lambda_; }
      void setLambda ( double lambda ) { lambda_ = lambda; }

    protected:
      JacobianOp jacobianOp_;
      double lambda_;
      mutable RangeFunctionType wTmp_;
    };



    // DGHelmholtzOperator
    // -------------------

    template< class SpaceOperator >
    class DGHelmholtzOperator
    : public DifferentiableOperator< DGHelmholtzJacobianOperator< typename SpaceOperator::JacobianOperatorType > >
    {
      typedef DGHelmholtzOperator< SpaceOperator > ThisType;
      typedef DifferentiableOperator< DGHelmholtzJacobianOperator< typename SpaceOperator::JacobianOperatorType > > BaseType;

    public:
      typedef SpaceOperator SpaceOperatorType;

      typedef typename BaseType::DomainFunctionType DomainFunctionType;
      typedef typename BaseType::RangeFunctionType RangeFunctionType;

      typedef typename BaseType::JacobianOperatorType JacobianOperatorType;

      typedef typename DomainFunctionType::DiscreteFunctionSpaceType DiscreteFunctionSpaceType;

      explicit DGHelmholtzOperator ( SpaceOperatorType &spaceOp )
      : spaceOp_( spaceOp ),
        lambda_( 0 ),
        wTmp_( "DGHelmholtzOperator temporary", space() )
      {}

      void operator() ( const DomainFunctionType &u, RangeFunctionType &w ) const
      {
        w.assign( u );
        if( lambda() != 0.0 )
        {
          spaceOperator()( u, wTmp_ );
          w.axpy( -lambda(), wTmp_ );
        }
      }

      void jacobian ( const DomainFunctionType &u, JacobianOperatorType &jOp ) const
      {
        spaceOperator().jacobian( u, jOp.jacobianOp_ );
        jOp.setLambda( lambda() );
      }

      const double &lambda () const { return lambda_; }
      void setLambda ( double lambda ) { lambda_ = lambda; }

      void setTime ( double time ) { spaceOperator().setTime( time ); }

      const DiscreteFunctionSpaceType &space () const { return spaceOperator().space(); }

      void initializeTimeStepSize ( const DomainFunctionType &u ) const
      {
        spaceOperator()( u, wTmp_ );
      }

      double timeStepEstimate () const { return spaceOperator().timeStepEstimate(); }

      const SpaceOperatorType &spaceOperator () const { return spaceOp_; }
      SpaceOperatorType &spaceOperator () { return spaceOp_; }

    protected:
      SpaceOperator &spaceOp_;
      double lambda_;
      mutable RangeFunctionType wTmp_;
    };

  } // namespace Fem

} // namespace Dune

#endif // #ifndef DUNE_FEM_OPERATOR_DGHELMHOLTZ_HH
