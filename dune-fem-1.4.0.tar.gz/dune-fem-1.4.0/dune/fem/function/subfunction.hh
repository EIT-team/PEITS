/**************************************************************************
 
  The dune-fem module is a module of DUNE (see www.dune-project.org).
  It is based on the dune-grid interface library 
  extending the grid interface by a number of discretization algorithms
  for solving non-linear systems of partial differential equations.

  Copyright (C) 2003 - 2013 Robert Kloefkorn
  Copyright (C) 2003 - 2010 Mario Ohlberger 
  Copyright (C) 2004 - 2013 Andreas Dedner
  Copyright (C) 2005        Adrian Burri
  Copyright (C) 2005 - 2012 Mirko Kraenkel
  Copyright (C) 2006 - 2013 Christoph Gersbacher
  Copyright (C) 2006 - 2013 Martin Nolte
  Copyright (C) 2011 - 2013 Tobias Malkmus

  The dune-fem module is free software; you can redistribute it and/or 
  modify it under the terms of the GNU General Public License as 
  published by the Free Software Foundation; either version 2 of 
  the License, or (at your option) any later version.

  The dune-fem module is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along
  with this program; if not, write to the Free Software Foundation, Inc.,
  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 
**************************************************************************/
#ifndef DUNE_FEM_SUBFUNCTION_HH
#define DUNE_FEM_SUBFUNCTION_HH

#include <vector>

#include <dune/fem/space/combinedspace.hh>
#include <dune/fem/storage/subarray.hh>
#include <dune/fem/function/vectorfunction/vectorfunction.hh>

namespace Dune 
{

  namespace Fem 
  {

    //! @ingroup SubDFunction
    //! A class for extracting sub functions from a 
    //! discrete function containing pointbased combined data.
    template <class DiscreteFunctionImp>   
    class SubFunctionStorage
    {
      SubFunctionStorage( const SubFunctionStorage& );
    protected:  
      typedef DiscreteFunctionImp DiscreteFunctionType;
      typedef typename DiscreteFunctionType :: DiscreteFunctionSpaceType  SpaceType;
      enum { dimRange = SpaceType :: dimRange };
      typedef typename DiscreteFunctionType :: DofStorageType            DofStorageType;
    public:  
      typedef typename SpaceType :: template ToNewDimRange < 1 > :: Type  SubSpaceType;  

      typedef CombinedSubMapper< typename SubSpaceType :: MapperType , dimRange, PointBased >  SubMapperType;
      typedef Fem :: SubVector< DofStorageType, SubMapperType >                  SubDofVectorType;
      typedef VectorDiscreteFunction< SubSpaceType, SubDofVectorType >    SubDiscreteFunctionType;

      //! constructor storing the discrete function 
      explicit SubFunctionStorage( DiscreteFunctionType& discreteFunction ) :
        discreteFunction_( discreteFunction ),
        space_( discreteFunction.space() ),
        subSpace_( space_.gridPart (), 
                         space_.communicationInterface(),
                         space_.communicationDirection() ),
        subMapper_( dimRange, (SubMapperType *) 0 ),
        subVector_( dimRange, (SubDofVectorType *) 0 ),
        subDiscreteFunction_( dimRange, (SubDiscreteFunctionType *) 0 )
      {}

      //! destructor 
      ~SubFunctionStorage() 
      {
        for(int i=0; i<dimRange; ++i)
        {
          delete subDiscreteFunction_[ i ]; subDiscreteFunction_[ i ] = 0;
          delete subVector_[ i ];           subVector_[ i ] = 0;
          delete subMapper_[ i ];           subMapper_[ i ] = 0;
        }
      }

      /** \brief return a SubDiscreteFunction repsenting only one 
          component of the original discrete function
          \param component the component to be extracted 
          
          \return reference to SubDiscreteFunction for given component
      */
      SubDiscreteFunctionType& subFunction(const size_t component) const
      {
        assert( component < dimRange );
        if( ! subDiscreteFunction_[ component ] )
        {
          subMapper_[ component ] = new SubMapperType( subSpace_.mapper(), component );
          subVector_[ component ] = new SubDofVectorType( discreteFunction_.dofStorage(), 
                                                          *subMapper_[component] );
          subDiscreteFunction_[ component ] = 
            new SubDiscreteFunctionType( std::string(discreteFunction_.name()+ "_sub"),
                                         subSpace_, *( subVector_[ component ] ));
        }
        return *( subDiscreteFunction_[ component ] );
      }

    protected:
      DiscreteFunctionType& discreteFunction_;
      const SpaceType& space_;
      SubSpaceType subSpace_;
      mutable std::vector< SubMapperType * > subMapper_;
      mutable std::vector< SubDofVectorType * > subVector_;
      mutable std::vector< SubDiscreteFunctionType* > subDiscreteFunction_;
    };

  } // namespace Fem 

} // namespace Dune

#endif // #ifndef DUNE_FEM_SUBFUNCTION_HH
