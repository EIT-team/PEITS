/**************************************************************************
 
  The dune-fem module is a module of DUNE (see www.dune-project.org).
  It is based on the dune-grid interface library 
  extending the grid interface by a number of discretization algorithms
  for solving non-linear systems of partial differential equations.

  Copyright (C) 2003 - 2013 Robert Kloefkorn
  Copyright (C) 2003 - 2010 Mario Ohlberger 
  Copyright (C) 2004 - 2013 Andreas Dedner
  Copyright (C) 2005        Adrian Burri
  Copyright (C) 2005 - 2012 Mirko Kraenkel
  Copyright (C) 2006 - 2013 Christoph Gersbacher
  Copyright (C) 2006 - 2013 Martin Nolte
  Copyright (C) 2011 - 2013 Tobias Malkmus

  The dune-fem module is free software; you can redistribute it and/or 
  modify it under the terms of the GNU General Public License as 
  published by the Free Software Foundation; either version 2 of 
  the License, or (at your option) any later version.

  The dune-fem module is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along
  with this program; if not, write to the Free Software Foundation, Inc.,
  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 
**************************************************************************/
#include <config.h>

#include <fstream>
#include <iostream>
#include <cstdio>

#include <sys/stat.h>  
#include <dirent.h>

#include <dune/fem/io/io.hh>
#include <dune/common/exceptions.hh>

namespace Dune
{

  namespace Fem
  {

    bool createDirectory ( const std::string &name )
    {
      // try to open directory (returns null pointer, if path does not exist)
      DIR *dir = opendir( name.c_str() );
      if( dir != 0 )
      {
        if( closedir( dir ) < 0 )
          std::cerr << "Error: Could not close directory." << std::endl;
        return true;
      }

      // try to create the father directory
      size_t pos = name.rfind( '/' );
      if( pos != std::string::npos )
      {
        const std::string father = name.substr( 0, pos );
        if( !createDirectory( father ) )
          return false;
      }

      // try to create the new child directory
      mode_t mode = S_IRWXU | S_IRGRP | S_IXGRP | S_IROTH | S_IXOTH;
      return (mkdir( name.c_str(), mode ) >= 0);
    }


    bool fileExists ( const std::string &name )
    {
      std::ifstream file( name.c_str() );
      return file.is_open();
    }


    bool directoryExists ( const std::string &name )
    {
      // if directory does not exist return false 
      DIR* directory = opendir( name.c_str() );
      const bool directoryExists = (directory != 0);
      // close directory again 
      closedir( directory );
      return directoryExists;
    }


    std::string executeCommand ( const std::string &command )
    {
      std::string returnString;
      FILE *pipe = popen( command.c_str(), "r" );

      if( !pipe )
        DUNE_THROW( IOError, "Unable to execute '" << command << "'." );

      std::size_t size;
      do
      {
        char buffer[ 4096 ];
        size = fread( buffer, sizeof( char ), sizeof( buffer ) / sizeof( char ), pipe );
        returnString.append( buffer, size );
      }
      while( size > std::size_t( 0 ) );

      const int status = pclose( pipe );
      if( status != 0 )
        DUNE_THROW( IOError, "Command '" << command << "' returned unsuccessfully (" << status << ")." );

      return returnString;
    }

  } // namespace Fem  
  
} // namespace Dune
