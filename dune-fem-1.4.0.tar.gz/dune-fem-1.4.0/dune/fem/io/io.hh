/**************************************************************************
 
  The dune-fem module is a module of DUNE (see www.dune-project.org).
  It is based on the dune-grid interface library 
  extending the grid interface by a number of discretization algorithms
  for solving non-linear systems of partial differential equations.

  Copyright (C) 2003 - 2013 Robert Kloefkorn
  Copyright (C) 2003 - 2010 Mario Ohlberger 
  Copyright (C) 2004 - 2013 Andreas Dedner
  Copyright (C) 2005        Adrian Burri
  Copyright (C) 2005 - 2012 Mirko Kraenkel
  Copyright (C) 2006 - 2013 Christoph Gersbacher
  Copyright (C) 2006 - 2013 Martin Nolte
  Copyright (C) 2011 - 2013 Tobias Malkmus

  The dune-fem module is free software; you can redistribute it and/or 
  modify it under the terms of the GNU General Public License as 
  published by the Free Software Foundation; either version 2 of 
  the License, or (at your option) any later version.

  The dune-fem module is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along
  with this program; if not, write to the Free Software Foundation, Inc.,
  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 
**************************************************************************/
#ifndef DUNE_FEM_IO_HH
#define DUNE_FEM_IO_HH

#include <iostream>

namespace Dune
{
  
  namespace Fem
  {

    /** \brief create a directory
     *
     *  \param[in]  name  name of the directory to create
     *
     *  \returns whether the directory has been successfully created
     */
    bool createDirectory ( const std::string &name );

    /** \brief check whether a file exists
     *
     *  \param[in]  name  name of the file to check
     *
     *  \return true if the file exists, false otherwise
     */
    bool fileExists ( const std::string &name );

    /** \brief check whether a directory exists 
     *
     *  \param[in]  name  name of the directory to check
     *
     *  \returns true if the directory exists, false otherwise 
     */
    bool directoryExists ( const std::string &name );

    /** \brief executes a command and return the output  
     *
     *  \param[in]  command   command to execute
     *
     *  \returns the output of the executed command
     *
     *  \note  This command throws an exception if the command 
     *         returns unsuccsessfully.
     */
    std::string executeCommand ( const std::string &command );

  } // namespace Fem

} // namespace Dune

#endif // #ifndef DUNE_FEM_IO_HH
