/**************************************************************************
 
  The dune-fem module is a module of DUNE (see www.dune-project.org).
  It is based on the dune-grid interface library 
  extending the grid interface by a number of discretization algorithms
  for solving non-linear systems of partial differential equations.

  Copyright (C) 2003 - 2013 Robert Kloefkorn
  Copyright (C) 2003 - 2010 Mario Ohlberger 
  Copyright (C) 2004 - 2013 Andreas Dedner
  Copyright (C) 2005        Adrian Burri
  Copyright (C) 2005 - 2012 Mirko Kraenkel
  Copyright (C) 2006 - 2013 Christoph Gersbacher
  Copyright (C) 2006 - 2013 Martin Nolte
  Copyright (C) 2011 - 2013 Tobias Malkmus

  The dune-fem module is free software; you can redistribute it and/or 
  modify it under the terms of the GNU General Public License as 
  published by the Free Software Foundation; either version 2 of 
  the License, or (at your option) any later version.

  The dune-fem module is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along
  with this program; if not, write to the Free Software Foundation, Inc.,
  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 
**************************************************************************/
#ifndef DUNE_FEM_BASEFUNCTIONFACTORY_HH
#define DUNE_FEM_BASEFUNCTIONFACTORY_HH

#include <dune/geometry/type.hh>

#include <dune/fem/space/basefunctions/basefunctioninterface.hh>

namespace Dune
{

  namespace Fem 
  {

    //! \brief Interface class for the generation of base functions.
    //! For every concrete set of base functions, derive your own concrete
    //! base function factory.
    template< class FunctionSpace >
    struct BaseFunctionFactory 
    {
      typedef FunctionSpace FunctionSpaceType;

      typedef BaseFunctionInterface< FunctionSpaceType > BaseFunctionType;

      //! constructor storing geometry type 
      explicit BaseFunctionFactory ( const GeometryType &geo )
      : geo_( geo )
      {}

      virtual ~BaseFunctionFactory() {}

      //! return pointer to num-th base function 
      virtual BaseFunctionType *baseFunction ( int num ) const = 0;

      //! return number of base function 
      virtual int numBaseFunctions () const = 0;

      //! return geometry type to which base functions belong
      const GeometryType &geometry () const { return geo_; }

    private:
      GeometryType geo_;
    };

  } // namespace Fem 

} // namespace Dune

#endif // #ifndef DUNE_FEM_BASEFUNCTIONFACTORY_HH
