/**************************************************************************
 
  The dune-fem module is a module of DUNE (see www.dune-project.org).
  It is based on the dune-grid interface library 
  extending the grid interface by a number of discretization algorithms
  for solving non-linear systems of partial differential equations.

  Copyright (C) 2003 - 2013 Robert Kloefkorn
  Copyright (C) 2003 - 2010 Mario Ohlberger 
  Copyright (C) 2004 - 2013 Andreas Dedner
  Copyright (C) 2005        Adrian Burri
  Copyright (C) 2005 - 2012 Mirko Kraenkel
  Copyright (C) 2006 - 2013 Christoph Gersbacher
  Copyright (C) 2006 - 2013 Martin Nolte
  Copyright (C) 2011 - 2013 Tobias Malkmus

  The dune-fem module is free software; you can redistribute it and/or 
  modify it under the terms of the GNU General Public License as 
  published by the Free Software Foundation; either version 2 of 
  the License, or (at your option) any later version.

  The dune-fem module is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along
  with this program; if not, write to the Free Software Foundation, Inc.,
  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 
**************************************************************************/
#include <config.h>

#include <iostream>
#include <dune/common/stdstreams.hh>
#include <dune/common/fvector.hh>
#include <dune/common/fmatrix.hh>

using namespace Dune;

#include <dune/fem/space/common/arrays.hh>

using namespace Fem;

template <class Vector> 
void checkVector( Vector& vector , const size_t rows, const size_t cols ) 
{
  std::cout << "Start Vector check: " << std::endl;
  vector.resize( rows );
  std::cout << "vector: capacity " << vector.capacity() << "  size " << vector.size() << std::endl;
  for( size_t i=0; i<rows; ++i ) 
  {
    vector[ i ].resize( cols );
    std::cout << "vector["<<i<<"]: capacity " << vector[ i ].capacity() << "  size " << vector[ i ].size() << std::endl;
    typedef typename Vector :: value_type :: value_type value_type;
    for( size_t j=0; j<cols; ++j ) 
    {
      vector[ i ][ j ] = value_type( j );
    }
  }
  std::cout << "End Vector check!" << std::endl << std::endl;
}

//**************************************************
//
//  main programm, run algorithm twice to calc EOC 
//
//**************************************************
int main( int argc, char *argv[] )
try {
  typedef FieldVector< double , 1 > ValueType;

  MutableArray< MutableArray< ValueType > > vector;
  vector.setMemoryFactor( 1.1 );

  checkVector( vector, 10, 4 );
  checkVector( vector, 7, 6 );
  checkVector( vector, 20, 9 );
  checkVector( vector, 2, 5 );
  return 0;
}
catch( const Dune :: Exception &exception )
{
  std :: cerr << exception << std :: endl;
  return 1;
}

