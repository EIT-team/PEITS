/**************************************************************************
 
  The dune-fem module is a module of DUNE (see www.dune-project.org).
  It is based on the dune-grid interface library 
  extending the grid interface by a number of discretization algorithms
  for solving non-linear systems of partial differential equations.

  Copyright (C) 2003 - 2013 Robert Kloefkorn
  Copyright (C) 2003 - 2010 Mario Ohlberger 
  Copyright (C) 2004 - 2013 Andreas Dedner
  Copyright (C) 2005        Adrian Burri
  Copyright (C) 2005 - 2012 Mirko Kraenkel
  Copyright (C) 2006 - 2013 Christoph Gersbacher
  Copyright (C) 2006 - 2013 Martin Nolte
  Copyright (C) 2011 - 2013 Tobias Malkmus

  The dune-fem module is free software; you can redistribute it and/or 
  modify it under the terms of the GNU General Public License as 
  published by the Free Software Foundation; either version 2 of 
  the License, or (at your option) any later version.

  The dune-fem module is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along
  with this program; if not, write to the Free Software Foundation, Inc.,
  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 
**************************************************************************/
#ifndef DUNE_FEM_REDUCEDBASISSPACE_BASEFUNCTIONSET_HH
#define DUNE_FEM_REDUCEDBASISSPACE_BASEFUNCTIONSET_HH

#include <dune/fem/storage/array.hh>
#include <dune/fem/space/basefunctions/basefunctionsetinterface.hh>

namespace Dune
{

  namespace Fem
  {

    template< class BaseFunctionImp >
    class ReducedBasisBaseFunctionSet;

    
    template< class BaseFunction >
    class ReducedBasisBaseFunctionSetTraits
    {
      typedef ReducedBasisBaseFunctionSetTraits< BaseFunction > ThisType;

    public:
      typedef ReducedBasisBaseFunctionSet< BaseFunction > BaseFunctionSetType;

      typedef BaseFunction BaseFunctionType;
      
      typedef typename BaseFunctionType::DiscreteFunctionSpaceType BaseFunctionSpaceType;
       
      typedef typename BaseFunctionSpaceType::BaseFunctionSetType::FunctionSpaceType
        FunctionSpaceType;

      static const int codimension = 0;
    };


    /** \class ReducedBasisBaseFunctionSet 
     *  \brief The ReducedBasisBaseFunctionSet class provides  
     *
     *  This class is needed to build the space and provides the functionality of
     *  the space for example the jacobian method is implemented here 
     */
    template< class BaseFunction >
    class ReducedBasisBaseFunctionSet
    : public BaseFunctionSetDefault< ReducedBasisBaseFunctionSetTraits< BaseFunction > >
    {
      typedef ReducedBasisBaseFunctionSet< BaseFunction > ThisType;
      typedef BaseFunctionSetDefault< ReducedBasisBaseFunctionSetTraits< BaseFunction> >
        BaseType;

    public:
      typedef ThisType BaseFunctionSetType;

      typedef ReducedBasisBaseFunctionSetTraits< BaseFunction > Traits;

      typedef typename Traits::BaseFunctionType BaseFunctionType;
      typedef typename Traits::BaseFunctionSpaceType BaseFunctionSpaceType;

      typedef typename BaseFunctionType::LocalFunctionType LocalBaseFunctionType;

      typedef typename BaseFunctionSpaceType::GridPartType GridPartType;
     
      typedef typename Traits::FunctionSpaceType FunctionSpaceType;
      
      typedef typename FunctionSpaceType::DomainFieldType DomainFieldType;
      typedef typename FunctionSpaceType::RangeFieldType RangeFieldType;

      typedef typename FunctionSpaceType::DomainType DomainType;
      typedef typename FunctionSpaceType::RangeType RangeType;

      typedef typename FunctionSpaceType::JacobianRangeType JacobianRangeType;
      typedef typename FunctionSpaceType::HessianRangeType HessianRangeType;

      static const int dimDomain = FunctionSpaceType::dimDomain;
      static const int dimRange = FunctionSpaceType::dimRange;

      typedef Fem :: DynamicArray< BaseFunctionType* > BaseFunctionListType;

    private:
      typedef typename GridPartType::GridType::template Codim< 0 >::Entity ElementType;

    public:
      using BaseType::evaluate;

      /** \brief default constructor */
      ReducedBasisBaseFunctionSet ()
      : baseFunctionList_( 0 ),
        entity_( 0 )
      {}
     
      /** constructor
       *
       *  This constructor initializes the base function set, but does not bind
       *  it to an entity.
       *
       *  \param[in]  baseFunctionList  array containing the discrete functions
       *                                to be used as base functions
       */
      explicit ReducedBasisBaseFunctionSet ( const BaseFunctionListType &baseFunctionList )
      : baseFunctionList_( &baseFunctionList ),
        entity_( 0 )
      {}

      /** constructor
       *
       *  This constructor initializes the base function set and binds it to an
       *  entity.
       *
       *  \param[in]  baseFunctionList  array containing the discrete functions
       *                                to be used as base functions
       *  \param[in]  entity            entity (of codim 0) to bind the base
       *                                function set to
       */
      ReducedBasisBaseFunctionSet ( const BaseFunctionListType &baseFunctionList,
                                    const ElementType &entity )
      : baseFunctionList_( &baseFunctionList ),
        entity_( &entity )
      {}
      
      /** \copydoc Dune::Fem::BaseFunctionSetInterface::evaluate(const int baseFunction,const FieldVector<int,diffOrder> &diffVariable,const Point &x,RangeType &value) const */
      template< int diffOrder, class Point >
      void evaluate ( const int baseFunction,
                      const FieldVector< int, diffOrder > &diffVariable,
                      const Point &x,
                      RangeType &value ) const;

      /** \brief obtain the entity, this base function set belongs to */
      const ElementType &entity () const
      {
        assert( entity_ != 0 );
        return *entity_;
      }

      GeometryType geometryType () const
      {
        return entity().geometry().type();
      }

      /** \copydoc Dune::Fem::BaseFunctionSetInterface::size */
      std::size_t size () const
      {
        assert( baseFunctionList_ != 0 );
        return baseFunctionList_->size();
      }

    protected:
      const BaseFunctionListType *baseFunctionList_;
      const ElementType *entity_;
    };


    // Implementation of ReducedBasisBaseFunctionSet
    // ---------------------------------------------

    template< class BaseFunction >
    template< int diffOrd, class PointType >
    inline void ReducedBasisBaseFunctionSet< BaseFunction >
      ::evaluate ( const int baseFunction,
                   const FieldVector< int, diffOrd > &diffVariable,
                   const PointType &x,
                   RangeType &phi ) const
    {
      assert( baseFunctionList_ != 0 );
      assert( (baseFunction >= 0) && (baseFunction < int( size() )) );

      const LocalBaseFunctionType localBaseFunction
        = (*baseFunctionList_)[ baseFunction ]->localFunction( entity() );
      localBaseFunction.evaluate( diffVariable, x, phi );
    }

  } // namespace Fem

} // namespace Dune

#endif // #ifndef DUNE_FEM_REDUCEDBASISSPACE_BASEFUNCTIONSET_HH
