/**************************************************************************
 
  The dune-fem module is a module of DUNE (see www.dune-project.org).
  It is based on the dune-grid interface library 
  extending the grid interface by a number of discretization algorithms
  for solving non-linear systems of partial differential equations.

  Copyright (C) 2003 - 2013 Robert Kloefkorn
  Copyright (C) 2003 - 2010 Mario Ohlberger 
  Copyright (C) 2004 - 2013 Andreas Dedner
  Copyright (C) 2005        Adrian Burri
  Copyright (C) 2005 - 2012 Mirko Kraenkel
  Copyright (C) 2006 - 2013 Christoph Gersbacher
  Copyright (C) 2006 - 2013 Martin Nolte
  Copyright (C) 2011 - 2013 Tobias Malkmus

  The dune-fem module is free software; you can redistribute it and/or 
  modify it under the terms of the GNU General Public License as 
  published by the Free Software Foundation; either version 2 of 
  the License, or (at your option) any later version.

  The dune-fem module is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along
  with this program; if not, write to the Free Software Foundation, Inc.,
  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 
**************************************************************************/
#ifndef DUNE_FEM_SPACE_PADAPTIVE_RESTRICTPROLONG_HH
#define DUNE_FEM_SPACE_PADAPTIVE_RESTRICTPROLONG_HH

#include <dune/geometry/referenceelements.hh>

#include <dune/fem/function/localfunction/localfunction.hh>
#include <dune/fem/space/lagrange/lagrangepoints.hh>


namespace Dune
{

  namespace Fem
  {

    // PLagrangeLocalRestrictProlong
    // -----------------------------

    template< class G, class LagrangePointSetProvider >
    struct PLagrangeLocalRestrictProlong
    {
      typedef G Grid;

      typedef typename Grid::ctype ctype;
      static const int dimension = Grid::dimension;
      typedef FieldVector< ctype, dimension > DomainVector;

      typedef typename Grid::template Codim< 0 >::Entity Entity;

      typedef typename LagrangePointSetProvider :: LagrangePointSetType  LagrangePointSet;

    private:
      typedef typename Entity::LocalGeometry LocalGeometry;

      typedef typename LagrangePointSet::template Codim< 0 >::SubEntityIteratorType
        EntityDofIterator;

    public:
      PLagrangeLocalRestrictProlong ( const LagrangePointSetProvider &lpsProvider )
      : lpsProvider_( lpsProvider )
      {}

      template< class DomainField >
      void setFatherChildWeight ( const DomainField &weight ) {}

      template< class FT, class ST, class LocalGeometry >
      void restrictLocal ( LocalFunction< FT > &fatherFunction,
                           const LocalFunction< ST > &sonFunction,
                          const LocalGeometry &geometryInFather,
                           const bool initialize ) const
      {
        static const int dimRange = LocalFunction< ST >::dimRange;

        const Entity &father = fatherFunction.entity();
        const Entity &son = sonFunction.entity();

        const Dune::ReferenceElement< ctype, dimension > &refSon
          = Dune::ReferenceElements< ctype, dimension >::general( son.type() );

        const LagrangePointSet &pointSet = lagrangePointSet( father );

        const EntityDofIterator send = pointSet.template endSubEntity< 0 >( 0 );
        for( EntityDofIterator sit = pointSet.template beginSubEntity< 0 >( 0 ); sit != send; ++sit )
        {
          const unsigned int dof = *sit;
          const DomainVector &pointInFather = pointSet.point( dof );
          const DomainVector pointInSon = geometryInFather.local( pointInFather );
          if( refSon.checkInside( pointInSon ) )
          {
            typename LocalFunction< ST >::RangeType phi;
            sonFunction.evaluate( pointInSon, phi );
            for( int coordinate = 0; coordinate < dimRange; ++coordinate )
              fatherFunction[ dimRange * dof + coordinate ] = phi[ coordinate ];
          }
        }
      }

      template< class FT, class ST, class LocalGeometry >
      void prolongLocal ( const LocalFunction< FT > &fatherFunction,
                          LocalFunction< ST > &sonFunction,
                          const LocalGeometry &geometryInFather,
                          bool initialize ) const
      {
        static const int dimRange = LocalFunction< FT >::dimRange;

        const Entity &son = sonFunction.entity();

        const LagrangePointSet &pointSet = lagrangePointSet( son );

        const EntityDofIterator send = pointSet.template endSubEntity< 0 >( 0 );
        for( EntityDofIterator sit = pointSet.template beginSubEntity< 0 >( 0 ); sit != send; ++sit )
        {
          const unsigned int dof = *sit;
          const DomainVector &pointInSon = pointSet.point( dof );
          const DomainVector pointInFather = geometryInFather.global( pointInSon );
          
          typename LocalFunction< FT >::RangeType phi;
          fatherFunction.evaluate( pointInFather, phi );
          for( int coordinate = 0; coordinate < dimRange; ++coordinate )
          {
            const int idx = dimRange * dof + coordinate  ;
            sonFunction[ idx ] = phi[ coordinate ];
          }
        }
      }

      template< class FT, class ST >
      void localInterpolation ( const LocalFunction< FT > &oldFunction,
                                LocalFunction< ST > &newFunction ) const
      {
        static const int dimRange = LocalFunction< ST >::dimRange;

        const Entity &entity = newFunction.entity();

        const LagrangePointSet &pointSet = lagrangePointSet( entity );

        const EntityDofIterator send = pointSet.template endSubEntity< 0 >( 0 );
        for( EntityDofIterator sit = pointSet.template beginSubEntity< 0 >( 0 ); sit != send; ++sit )
        {
          const unsigned int dof = *sit;
          const DomainVector &localPoint = pointSet.point( dof );
          
          typename LocalFunction< FT >::RangeType phi;
          oldFunction.evaluate( localPoint, phi );
          for( int coordinate = 0; coordinate < dimRange; ++coordinate )
          {
            const int idx = dimRange * dof + coordinate  ;
            newFunction[ idx ] = phi[ coordinate ];
          }
        }
      }

      bool needCommunication () const { return false; }

      const LagrangePointSet &lagrangePointSet ( const Entity &entity ) const
      {
        return lpsProvider_.lagrangePointSet( entity );
      }

    protected:
      const LagrangePointSetProvider& lpsProvider_;
    };

  } // namespace Fem

} // namespace Dune 

#endif // #ifndef DUNE_FEM_SPACE_PADAPTIVE_RESTRICTPROLONG_HH
