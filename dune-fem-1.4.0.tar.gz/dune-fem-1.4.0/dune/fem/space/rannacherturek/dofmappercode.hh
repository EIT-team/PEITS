/**************************************************************************
 
  The dune-fem module is a module of DUNE (see www.dune-project.org).
  It is based on the dune-grid interface library 
  extending the grid interface by a number of discretization algorithms
  for solving non-linear systems of partial differential equations.

  Copyright (C) 2003 - 2013 Robert Kloefkorn
  Copyright (C) 2003 - 2010 Mario Ohlberger 
  Copyright (C) 2004 - 2013 Andreas Dedner
  Copyright (C) 2005        Adrian Burri
  Copyright (C) 2005 - 2012 Mirko Kraenkel
  Copyright (C) 2006 - 2013 Christoph Gersbacher
  Copyright (C) 2006 - 2013 Martin Nolte
  Copyright (C) 2011 - 2013 Tobias Malkmus

  The dune-fem module is free software; you can redistribute it and/or 
  modify it under the terms of the GNU General Public License as 
  published by the Free Software Foundation; either version 2 of 
  the License, or (at your option) any later version.

  The dune-fem module is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along
  with this program; if not, write to the Free Software Foundation, Inc.,
  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 
**************************************************************************/
#ifndef DUNE_FEM_SPACE_RANNACHERTUREK_DOFMAPPERCODE_HH
#define DUNE_FEM_SPACE_RANNACHERTUREK_DOFMAPPERCODE_HH

// dune-geometry includes
#include <dune/geometry/referenceelements.hh>

// dune-fem includes
#include <dune/fem/space/dofmapper/code.hh>
#include <dune/fem/space/dofmapper/compile.hh>
#include <dune/fem/space/dofmapper/indexsetdofmapper.hh>


namespace Dune
{

  namespace Fem
  {
  
    // RannacherTurekBlockMapperSingletonKey
    // -------------------------------------

    template< class GridPart >
    class RannacherTurekBlockMapperSingletonKey
    {
      typedef RannacherTurekBlockMapperSingletonKey< GridPart > ThisType;

    public:
      typedef GridPart GridPartType;

      RannacherTurekBlockMapperSingletonKey ( const GridPartType &gridPart )
      : gridPart_( gridPart )
      {}

      const GridPartType &gridPart () const { return gridPart_; }
    
      bool operator== ( const ThisType &other ) const
      {
        return ( &gridPart_ == &(other.gridPart_) );
      }
      
      bool operator!= ( const ThisType &other ) const
      {
        return !( *this == other );
      }

    private:
      const GridPartType &gridPart_;
    };



    // RannacherTurekDofMapperCodeFactory
    // ----------------------------------

    template< class LocalCoefficients >
    struct RannacherTurekDofMapperCodeFactory
    {
      typedef LocalCoefficients LocalCoefficientsType;

      RannacherTurekDofMapperCodeFactory ( const LocalCoefficients &localCoefficients = LocalCoefficients() )
      : localCoefficients_( localCoefficients )
      {}

      template< class Field, int dim >
      Dune::Fem::DofMapperCode operator() ( const Dune::ReferenceElement< Field, dim > &refElement ) const
      {
        return Dune::Fem::compile( refElement, localCoefficients() );
      }

      const LocalCoefficientsType &localCoefficients () const
      {
        return localCoefficients_;
      }

    private:
      LocalCoefficientsType localCoefficients_;
    };



    // RannacherTurekBlockMapperFactory
    // --------------------------------

    template< class GridPart, class LocalCoefficients >
    struct RannacherTurekBlockMapperFactory
    {
      typedef GridPart GridPartType;
      typedef LocalCoefficients LocalCoefficientsType;

      typedef Dune::Fem::IndexSetDofMapper< GridPartType > BlockMapperType;

      static BlockMapperType *createObject ( const RannacherTurekBlockMapperSingletonKey< GridPartType > &key )
      {
        return createObject( key.gridPart() );
      }

      static BlockMapperType *createObject ( const GridPart &gridPart )
      {
        RannacherTurekDofMapperCodeFactory< LocalCoefficientsType > codeFactory;
        return new BlockMapperType( gridPart, codeFactory );
      }

      static void deleteObject ( BlockMapperType *blockMapper )
      {
        delete blockMapper;
      }
    };

  } // namespace Fem

} // namespace Dune

#endif // #ifndef DUNE_FEM_SPACE_RANNACHERTUREK_DOFMAPPERCODE_HH
