/**************************************************************************
 
  The dune-fem module is a module of DUNE (see www.dune-project.org).
  It is based on the dune-grid interface library 
  extending the grid interface by a number of discretization algorithms
  for solving non-linear systems of partial differential equations.

  Copyright (C) 2003 - 2013 Robert Kloefkorn
  Copyright (C) 2003 - 2010 Mario Ohlberger 
  Copyright (C) 2004 - 2013 Andreas Dedner
  Copyright (C) 2005        Adrian Burri
  Copyright (C) 2005 - 2012 Mirko Kraenkel
  Copyright (C) 2006 - 2013 Christoph Gersbacher
  Copyright (C) 2006 - 2013 Martin Nolte
  Copyright (C) 2011 - 2013 Tobias Malkmus

  The dune-fem module is free software; you can redistribute it and/or 
  modify it under the terms of the GNU General Public License as 
  published by the Free Software Foundation; either version 2 of 
  the License, or (at your option) any later version.

  The dune-fem module is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along
  with this program; if not, write to the Free Software Foundation, Inc.,
  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 
**************************************************************************/
#ifndef DUNE_FEM_SPACE_RANNACHERTUREK_LOCALINTERPOLATION_HH
#define DUNE_FEM_SPACE_RANNACHERTUREK_LOCALINTERPOLATION_HH

// C++ includes
#include <cstdlib>
#include <vector>

// dune-common includes
#include <dune/common/fvector.hh>


namespace Dune
{

  namespace Fem
  {

    // VectorialLocalInterpolation
    // ---------------------------

    template< class LocalInterpolation, class RangeVector >
    struct VectorialLocalInterpolation
    {
      typedef LocalInterpolation LocalInterpolationType;
      typedef RangeVector RangeType;

      typedef typename RangeType::field_type RangeFieldType;
      static const int dimRange = RangeType::dimension;

      typedef std::size_t size_type;

    private:
      template< class LocalFunction >
      struct LocalFunctionWrapper;

    public:
      explicit VectorialLocalInterpolation ( const LocalInterpolationType &localInterpolation = LocalInterpolationType() )
      : localInterpolation_( localInterpolation )
      {}
      
      template< class LocalFunction, class LocalDofVector >
      void operator() ( const LocalFunction &f, LocalDofVector &dofs ) const;

    protected:
      const LocalInterpolationType &localInterpolation () const { return localInterpolation_; }

    private:
      LocalInterpolationType localInterpolation_;
    };



    // Implementation of VectorialLocalInterpolation::LocalFunctionWrapper
    // -------------------------------------------------------------------

    template< class LocalInterpolation, class RangeVector >
    template< class LocalFunction >
    struct VectorialLocalInterpolation< LocalInterpolation, RangeVector >::LocalFunctionWrapper
    {
      LocalFunctionWrapper ( const LocalFunction &localFunction, size_type component )
      : localFunction_( localFunction ),
        component_( component )
      {}

      template< class RangeFieldType >
      void evaluate ( const typename LocalFunction::DomainType &x, Dune::FieldVector< RangeFieldType, 1 > &y ) const
      {
        typename LocalFunction::RangeType z;
        localFunction().evaluate( x, z );
        y = z[ component() ];
      }

    private:
      const LocalFunction &localFunction () const { return localFunction_; }

      size_type component () const { return component_; }

      const LocalFunction &localFunction_;
      size_type component_;
    };



    // Implementation of VectorialLocalInterpolation
    // ---------------------------------------------

     
    template< class LocalInterpolation, class RangeVector >
    template< class LocalFunction, class LocalDofVector >
    inline void VectorialLocalInterpolation< LocalInterpolation, RangeVector >
      ::operator() ( const LocalFunction &f, LocalDofVector &dofs ) const
    {
      std::vector< RangeFieldType > phi;
      
      for( int k = 0; k < dimRange; ++k )
      {
        LocalFunctionWrapper< LocalFunction > localFunctionWrapper( f, k );
        localInterpolation().interpolate( localFunctionWrapper, phi );
        
        const size_type size = phi.size();
        for( size_type i = 0; i < size; ++i )
        {
          dofs[ i*dimRange + k ] = phi[ i ];
        }
      }
    }

  } // namespace Fem

} // namespace Dune

#endif // #ifndef DUNE_FEM_SPACE_RANNACHERTUREK_LOCALINTERPOLATION_HH
