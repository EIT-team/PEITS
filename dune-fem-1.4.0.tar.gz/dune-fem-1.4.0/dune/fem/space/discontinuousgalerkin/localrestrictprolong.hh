/**************************************************************************
 
  The dune-fem module is a module of DUNE (see www.dune-project.org).
  It is based on the dune-grid interface library 
  extending the grid interface by a number of discretization algorithms
  for solving non-linear systems of partial differential equations.

  Copyright (C) 2003 - 2013 Robert Kloefkorn
  Copyright (C) 2003 - 2010 Mario Ohlberger 
  Copyright (C) 2004 - 2013 Andreas Dedner
  Copyright (C) 2005        Adrian Burri
  Copyright (C) 2005 - 2012 Mirko Kraenkel
  Copyright (C) 2006 - 2013 Christoph Gersbacher
  Copyright (C) 2006 - 2013 Martin Nolte
  Copyright (C) 2011 - 2013 Tobias Malkmus

  The dune-fem module is free software; you can redistribute it and/or 
  modify it under the terms of the GNU General Public License as 
  published by the Free Software Foundation; either version 2 of 
  the License, or (at your option) any later version.

  The dune-fem module is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along
  with this program; if not, write to the Free Software Foundation, Inc.,
  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 
**************************************************************************/
#ifndef DUNE_FEM_SPACE_DISCONTINUOUSGALERKIN_LOCALRESTRICTPROLONG_HH_
#define DUNE_FEM_SPACE_DISCONTINUOUSGALERKIN_LOCALRESTRICTPROLONG_HH_

// dune-fem includes
#include <dune/fem/function/localfunction/temporary.hh>
#include <dune/fem/quadrature/cachingquadrature.hh>
#include <dune/fem/space/common/adaptmanager.hh>
#include <dune/fem/space/common/localrestrictprolong.hh>

// local includes
#include "declaration.hh" 
#include "localdgmassmatrix.hh"


namespace Dune
{

  namespace Fem 
  {

    /** @ingroup RestrictProlongImpl
        @{
    **/


    // DiscontinuousGalerkinLocalRestrictProlong
    // -----------------------------------------

    template< class DiscreteFunctionSpace, bool applyInverse >
    class DiscontinuousGalerkinLocalRestrictProlong
    {
      typedef DiscontinuousGalerkinLocalRestrictProlong< DiscreteFunctionSpace, applyInverse > ThisType;

    public:
      typedef DiscreteFunctionSpace DiscreteFunctionSpaceType;

      typedef typename DiscreteFunctionSpaceType::DomainFieldType DomainFieldType;
      typedef typename DiscreteFunctionSpaceType::RangeFieldType RangeFieldType;
      typedef typename DiscreteFunctionSpaceType::RangeType RangeType;

      typedef typename DiscreteFunctionSpaceType::GridPartType GridPartType;

      typedef CachingQuadrature< GridPartType, 0 > QuadratureType;

      typedef LocalMassMatrix< DiscreteFunctionSpaceType, QuadratureType > LocalMassMatrixType;

      DiscontinuousGalerkinLocalRestrictProlong ( const DiscreteFunctionSpaceType& space )
      : localMassMatrix_( space, space.order() * 2 ),
        weight_( -1 ),
        temp_( space )
      {}

      void setFatherChildWeight ( const DomainFieldType &weight )
      {
        weight_ = weight;
      }

      //! restrict data to father 
      template< class FT, class ST, class LocalGeometry >
      void restrictLocal ( LocalFunction< FT > &lfFather, const LocalFunction< ST > &lfSon, 
                           const LocalGeometry &geometryInFather, bool initialize ) const
      {
        typedef ConstantLocalRestrictProlong< DiscreteFunctionSpaceType > ConstantLocalRestrictProlongType;
        const DomainFieldType weight = (weight_ < DomainFieldType( 0 ) ? ConstantLocalRestrictProlongType::calcWeight( lfFather.entity(), lfSon.entity() ) : weight_); 

        assert( weight > 0.0 );

        if( initialize )
          lfFather.clear();

        if( applyInverse )
        {
          temp_.init( lfFather.entity() );
          temp_.clear();
        }

        typedef typename LocalFunction< ST > :: EntityType  EntityType ;
        typedef typename EntityType :: Geometry   Geometry;
        const EntityType& sonEntity = lfSon.entity();
        const Geometry& sonGeo = sonEntity.geometry();

        QuadratureType quad( sonEntity, 2*lfFather.order()+1 );
        const int nop = quad.nop();
        for( int qp = 0; qp < nop; ++qp )
        {
          RangeFieldType quadWeight = quad.weight( qp );
          
          // in case of non-orthonormal basis we have to 
          // apply the integration element and the 
          // inverse mass matrix later
          if( applyInverse ) 
          {
            quadWeight *= sonGeo.integrationElement( quad.point(qp) );
          }
          else 
            quadWeight *= weight ;

          RangeType value;
          lfSon.evaluate( quad[ qp ], value );
          value *= quadWeight;

          if( applyInverse )
            temp_.axpy( geometryInFather.global( quad.point( qp ) ), value );
          else 
            lfFather.axpy( geometryInFather.global( quad.point( qp ) ), value );
        }

        if( applyInverse ) 
        {
          localMassMatrix_.applyInverse( temp_ );
          lfFather += temp_;
        }
      }

      template< class FT, class ST, class LocalGeometry >
      void prolongLocal ( const LocalFunction< FT > &lfFather, LocalFunction< ST > &lfSon,
                          const LocalGeometry &geometryInFather, bool initialize ) const
      {
        lfSon.clear();

        typedef typename LocalFunction< ST > :: EntityType  EntityType ;
        typedef typename EntityType :: Geometry   Geometry;
        const EntityType& sonEntity = lfSon.entity();
        const Geometry& sonGeo = sonEntity.geometry();

        QuadratureType quad( sonEntity, 2*lfSon.order()+1 );
        const int nop = quad.nop();
        for( int qp = 0; qp < nop; ++qp )
        {
          RangeFieldType quadWeight = quad.weight( qp );
          
          // in case of non-orthonormal basis we have to 
          // apply the integration element and the 
          // inverse mass matrix later
          if( applyInverse ) 
          {
            quadWeight *= sonGeo.integrationElement( quad.point(qp) );
          }

          RangeType value;
          lfFather.evaluate( geometryInFather.global( quad.point( qp ) ), value );
          value *= quadWeight;
          lfSon.axpy( quad[ qp ], value );
        }

        if( applyInverse ) 
        {
          localMassMatrix_.applyInverse( sonEntity, lfSon );
        }
      }

      bool needCommunication () const { return true; }

    protected:
      LocalMassMatrixType localMassMatrix_;
      DomainFieldType weight_;
      mutable TemporaryLocalFunction< DiscreteFunctionSpace > temp_;
    };



    // DefaultLocalRestrictProlong for DiscontinuousGalerkinSpace
    // ----------------------------------------------------------

    template< class FunctionSpaceImp, class GridPartImp, int polOrd, template< class > class StorageImp >
    struct DefaultLocalRestrictProlong< DiscontinuousGalerkinSpace< FunctionSpaceImp, GridPartImp, polOrd, StorageImp > >
    : public DiscontinuousGalerkinLocalRestrictProlong< DiscontinuousGalerkinSpace< FunctionSpaceImp, GridPartImp, polOrd, StorageImp >, false >
    {
      typedef DiscontinuousGalerkinLocalRestrictProlong< DiscontinuousGalerkinSpace<
        FunctionSpaceImp, GridPartImp, polOrd, StorageImp >, false  >  BaseType;
      DefaultLocalRestrictProlong ( const DiscontinuousGalerkinSpace< FunctionSpaceImp, GridPartImp, polOrd, StorageImp > & space )
        : BaseType( space )
      {}
    };

    template< class FunctionSpaceImp, class GridPartImp, template< class > class StorageImp >
    struct DefaultLocalRestrictProlong< DiscontinuousGalerkinSpace< FunctionSpaceImp, GridPartImp, 0, StorageImp > >
    : public ConstantLocalRestrictProlong< DiscontinuousGalerkinSpace< FunctionSpaceImp, GridPartImp, 0, StorageImp > >
    {
      DefaultLocalRestrictProlong ( const DiscontinuousGalerkinSpace< FunctionSpaceImp, GridPartImp, 0, StorageImp > & )
      {}
    };



    // DefaultLocalRestrictProlong for LegendreDiscontinuousGalerkinSpace
    // ------------------------------------------------------------------

    template< class FunctionSpaceImp, class GridPartImp, int polOrd, template< class > class StorageImp >
    struct DefaultLocalRestrictProlong< LegendreDiscontinuousGalerkinSpace< FunctionSpaceImp, GridPartImp, polOrd, StorageImp > >
    : public DiscontinuousGalerkinLocalRestrictProlong< LegendreDiscontinuousGalerkinSpace< FunctionSpaceImp, GridPartImp, polOrd, StorageImp >, false >
    {
      typedef DiscontinuousGalerkinLocalRestrictProlong<
        LegendreDiscontinuousGalerkinSpace< FunctionSpaceImp, GridPartImp, polOrd,  StorageImp >, false > BaseType;
      DefaultLocalRestrictProlong ( const LegendreDiscontinuousGalerkinSpace< FunctionSpaceImp, GridPartImp, polOrd, StorageImp > & space )
        : BaseType( space )
      {}
    };

    template< class FunctionSpaceImp, class GridPartImp, template< class > class StorageImp >
    struct DefaultLocalRestrictProlong< LegendreDiscontinuousGalerkinSpace< FunctionSpaceImp, GridPartImp, 0, StorageImp > >
    : public ConstantLocalRestrictProlong< LegendreDiscontinuousGalerkinSpace< FunctionSpaceImp, GridPartImp, 0, StorageImp > >
    {
      DefaultLocalRestrictProlong ( const LegendreDiscontinuousGalerkinSpace< FunctionSpaceImp, GridPartImp, 0, StorageImp > & )
      {}
    };



    // DefaultLocalRestrictProlong for HierarchicLegendreDiscontinuousGalerkinSpace
    // ----------------------------------------------------------------------------

    template< class FunctionSpaceImp, class GridPartImp, int polOrd, template< class > class StorageImp >
    struct DefaultLocalRestrictProlong< HierarchicLegendreDiscontinuousGalerkinSpace< FunctionSpaceImp, GridPartImp, polOrd, StorageImp > >
    : public DiscontinuousGalerkinLocalRestrictProlong< HierarchicLegendreDiscontinuousGalerkinSpace< FunctionSpaceImp, GridPartImp, polOrd, StorageImp >, false >
    {
      typedef DiscontinuousGalerkinLocalRestrictProlong<
        HierarchicLegendreDiscontinuousGalerkinSpace< FunctionSpaceImp, GridPartImp, polOrd,  StorageImp >, false > BaseType;
      DefaultLocalRestrictProlong ( const HierarchicLegendreDiscontinuousGalerkinSpace< FunctionSpaceImp, GridPartImp, polOrd, StorageImp > & space )
        : BaseType( space )
      {}
    };

    template< class FunctionSpaceImp, class GridPartImp, template< class > class StorageImp >
    struct DefaultLocalRestrictProlong< HierarchicLegendreDiscontinuousGalerkinSpace< FunctionSpaceImp, GridPartImp, 0, StorageImp > >
    : public ConstantLocalRestrictProlong< HierarchicLegendreDiscontinuousGalerkinSpace< FunctionSpaceImp, GridPartImp, 0, StorageImp > >
    {
      DefaultLocalRestrictProlong ( const HierarchicLegendreDiscontinuousGalerkinSpace< FunctionSpaceImp, GridPartImp, 0, StorageImp > & )
      {}
    };



    // DefaultLocalRestrictProlong for LagrangeDiscontinuousGalerkinSpace
    // ------------------------------------------------------------------

    template< class FunctionSpaceImp, class GridPartImp, int polOrd, template< class > class StorageImp >
    struct DefaultLocalRestrictProlong< LagrangeDiscontinuousGalerkinSpace< FunctionSpaceImp, GridPartImp, polOrd, StorageImp > >
    : public DiscontinuousGalerkinLocalRestrictProlong< LagrangeDiscontinuousGalerkinSpace< FunctionSpaceImp, GridPartImp, polOrd, StorageImp >, true >
    {
      typedef DiscontinuousGalerkinLocalRestrictProlong< LagrangeDiscontinuousGalerkinSpace< FunctionSpaceImp, GridPartImp, polOrd, StorageImp >, true >  BaseType ;
      DefaultLocalRestrictProlong ( const LagrangeDiscontinuousGalerkinSpace< FunctionSpaceImp, GridPartImp, polOrd, StorageImp > & space )
        : BaseType( space )
      {}
    };

    template< class FunctionSpaceImp, class GridPartImp, template< class > class StorageImp >
    struct DefaultLocalRestrictProlong< LagrangeDiscontinuousGalerkinSpace< FunctionSpaceImp, GridPartImp, 0, StorageImp > >
    : public ConstantLocalRestrictProlong< LagrangeDiscontinuousGalerkinSpace< FunctionSpaceImp, GridPartImp, 0, StorageImp > >
    {
      DefaultLocalRestrictProlong ( const LagrangeDiscontinuousGalerkinSpace< FunctionSpaceImp, GridPartImp, 0, StorageImp > & )
      {}
    };

    ///@}

  } // namespace Fem 

} // namespace Dune

#endif // #ifndef DUNE_FEM_SPACE_DISCONTINUOUSGALERKIN_LOCALRESTRICTPROLONG_HH_
