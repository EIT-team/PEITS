/**************************************************************************
 
  The dune-fem module is a module of DUNE (see www.dune-project.org).
  It is based on the dune-grid interface library 
  extending the grid interface by a number of discretization algorithms
  for solving non-linear systems of partial differential equations.

  Copyright (C) 2003 - 2013 Robert Kloefkorn
  Copyright (C) 2003 - 2010 Mario Ohlberger 
  Copyright (C) 2004 - 2013 Andreas Dedner
  Copyright (C) 2005        Adrian Burri
  Copyright (C) 2005 - 2012 Mirko Kraenkel
  Copyright (C) 2006 - 2013 Christoph Gersbacher
  Copyright (C) 2006 - 2013 Martin Nolte
  Copyright (C) 2011 - 2013 Tobias Malkmus

  The dune-fem module is free software; you can redistribute it and/or 
  modify it under the terms of the GNU General Public License as 
  published by the Free Software Foundation; either version 2 of 
  the License, or (at your option) any later version.

  The dune-fem module is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along
  with this program; if not, write to the Free Software Foundation, Inc.,
  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 
**************************************************************************/
#include <config.h>

#include <dune/fem/space/discontinuousgalerkin/legendrepolynomials.hh>

namespace Dune
{

  namespace Fem 
  {  

    const double LegendrePolynomials::weight[ LegendrePolynomials::maxOrder ]
      = { 1.0, 1.73205080756887729352744634151, 2.23606797749978969640917366873, 2.64575131106459059050161575364, 3.0, 3.31662479035539984911493273667, 3.60555127546398929311922126747,
          3.87298334620741688517926539978, 4.12310562561766054982140985597, 4.35889894354067355223698198386, 4.58257569495584000658804719373 };

    const double LegendrePolynomials::factor[ LegendrePolynomials::maxOrder ][ LegendrePolynomials::maxOrder ]
      = { { 1.0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
          { -1.0, 2.0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
          { 1.0, - 6.0, 6.0, 0, 0, 0, 0, 0, 0, 0, 0 },
          { -1.0, 12.0, -30.0, 20.0, 0, 0, 0, 0, 0, 0, 0 },
          { 1.0, -20.0, 90.0, -140.0, 70.0, 0, 0, 0, 0, 0, 0 },
          { -1.0, 30.0, -210.0, 560.0, -630.0, 252.0, 0, 0, 0, 0, 0 },
          { 1.0, -42.0, 420.0, -1680.0, 3150.0, -2772.0, 924.0, 0, 0, 0, 0 },
          { -1.0, 56.0, -756.0, 4200.0, -11550.0, 16632.0, -12012.0, 3432.0, 0, 0, 0 },
          { 1.0, -72.00, 1260.0, -9240.0, 34650.0, -72072.0, 84084.0, -51480.0, 12870.0, 0, 0 },
          { -1.0, 90.0, -1980.0, 18480.0, -90090.0, 252252.0, -420420.0, 411840.0, -218790.0, 48620.0, 0 },
          { 1.0, -110.0, 2970.0, -34920.0, 210210.0, -756756.0, 1681680.0, -2333760.0, 1969110.0, -923780.0, 184756.0 } };

  } // namespace Fem 

} // namespace Dune 

