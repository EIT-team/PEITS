/**************************************************************************
 
  The dune-fem module is a module of DUNE (see www.dune-project.org).
  It is based on the dune-grid interface library 
  extending the grid interface by a number of discretization algorithms
  for solving non-linear systems of partial differential equations.

  Copyright (C) 2003 - 2013 Robert Kloefkorn
  Copyright (C) 2003 - 2010 Mario Ohlberger 
  Copyright (C) 2004 - 2013 Andreas Dedner
  Copyright (C) 2005        Adrian Burri
  Copyright (C) 2005 - 2012 Mirko Kraenkel
  Copyright (C) 2006 - 2013 Christoph Gersbacher
  Copyright (C) 2006 - 2013 Martin Nolte
  Copyright (C) 2011 - 2013 Tobias Malkmus

  The dune-fem module is free software; you can redistribute it and/or 
  modify it under the terms of the GNU General Public License as 
  published by the Free Software Foundation; either version 2 of 
  the License, or (at your option) any later version.

  The dune-fem module is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along
  with this program; if not, write to the Free Software Foundation, Inc.,
  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 
**************************************************************************/
#ifndef DUNE_FEM_SPACE_LAGRANGE_SHAPEFUNCTIONSET_HH
#define DUNE_FEM_SPACE_LAGRANGE_SHAPEFUNCTIONSET_HH

#include <cassert>
#include <cstdlib>

#include <dune/common/fvector.hh>
#include <dune/common/nullptr.hh>
#include <dune/common/static_assert.hh>

#include <dune/geometry/genericgeometry/topologytypes.hh>
#include <dune/geometry/type.hh>

#include <dune/fem/space/common/functionspace.hh>
#include <dune/fem/space/shapefunctionset/simple.hh>

#include "genericbasefunctions.hh"
#include "genericlagrangepoints.hh"

/*
  @file
  @brief Shape function set for Lagrange space
  @author Christoph Gersbacher
*/

namespace Dune
{

  namespace Fem
  {

    // LagrangeShapeFunctionInterface
    // ------------------------------

    /**
     * \brief abstract base class for Lagrange shape functions
     *
     * \tparam  FunctionSpace  scalar function space
     */
    template< class FunctionSpace >
    class LagrangeShapeFunctionInterface
    {
      typedef LagrangeShapeFunctionInterface< FunctionSpace > ThisType;
      
      dune_static_assert( (FunctionSpace::dimRange == 1), "FunctionSpace must be scalar." );

    public:
      typedef FunctionSpace FunctionSpaceType;

      typedef typename FunctionSpaceType::DomainType DomainType;
      typedef typename FunctionSpaceType::RangeType RangeType;
      typedef typename FunctionSpaceType::JacobianRangeType JacobianRangeType;
      typedef typename FunctionSpaceType::HessianRangeType HessianRangeType;

      virtual ~LagrangeShapeFunctionInterface () {}

      virtual void evaluate ( const DomainType &x, RangeType &value ) const = 0;
      virtual void jacobian ( const DomainType &x, JacobianRangeType &jacobian ) const = 0;
      virtual void hessian ( const DomainType &x, HessianRangeType &hessian ) const = 0;

      virtual int order () const = 0;

      virtual const ThisType *clone () const = 0;
    };



    // LagrangeShapeFunction
    // ---------------------

    /**
     * \brief implementation of Lagrange shape function 
     *        using generic Lagrange shape functions
     *
     * \tparam  FunctionSpace  scalar function space
     * \tparam  GeometryType   generic geometry type wrapper
     * \tparam  polOrder       polynomial order
     */
    template< class FunctionSpace, class GeometryType, unsigned int polOrder >
    class LagrangeShapeFunction
    : public LagrangeShapeFunctionInterface< FunctionSpace >
    {
      typedef LagrangeShapeFunction< FunctionSpace, GeometryType, polOrder > ThisType;
      typedef LagrangeShapeFunctionInterface< FunctionSpace > BaseType;

      static const int dimension = FunctionSpace::dimDomain;

    public:
      typedef GenericLagrangeBaseFunction< FunctionSpace, GeometryType, polOrder >
        GenericBaseFunctionType;

      typedef typename BaseType::DomainType DomainType;
      typedef typename BaseType::RangeType RangeType;
      typedef typename BaseType::JacobianRangeType JacobianRangeType;
      typedef typename BaseType::HessianRangeType HessianRangeType;

      explicit LagrangeShapeFunction ( const GenericBaseFunctionType &genericShapeFunction )
      : genericShapeFunction_( genericShapeFunction )
      {}

      virtual void evaluate ( const DomainType &x, RangeType &value ) const;
      virtual void jacobian ( const DomainType &x, JacobianRangeType &jacobian ) const;
      virtual void hessian ( const DomainType &x, HessianRangeType &hessian ) const;

      virtual int order () const { return polOrder; }
      
      virtual const BaseType *clone () const { return new ThisType( *this ); }

    protected:
      GenericBaseFunctionType genericShapeFunction_;
    };



    // LagrangeShapeFunctionFactory
    // ----------------------------

    /**
     * \brief factory class 
     *
     * \tparam  FunctionSpace  scalar function space
     * \tparam  polOrder       polynomial order
     */

    template< class FunctionSpace, int polOrder >
    class LagrangeShapeFunctionFactory 
    {
      static const int dimension = FunctionSpace::dimDomain;

    public:
      typedef LagrangeShapeFunctionInterface< FunctionSpace > ShapeFunctionType;

    private:
      template< class Topology >
      struct Switch;

    public:
      explicit LagrangeShapeFunctionFactory ( const Dune::GeometryType &type )
      : topologyId_( type.id() )
      {}

      int order () const;

      std::size_t numShapeFunctions () const;

      ShapeFunctionType *createShapeFunction( std::size_t i ) const;

    private:
      unsigned int topologyId_;
    };



    // LagrangeShapeFunctionSet
    // ------------------------

    /**
     * \brief Lagrange shape function set
     *
     * \tparam  FunctionSpace  function space
     * \tparam  polOrder       polynomial order
     */
    template< class FunctionSpace, int polOrder >
    class LagrangeShapeFunctionSet
    : public SimpleShapeFunctionSet< 
        typename LagrangeShapeFunctionFactory< FunctionSpace, polOrder >::ShapeFunctionType 
      >
    {
      dune_static_assert( (FunctionSpace::dimRange == 1), "FunctionSpace must be scalar." );

      typedef LagrangeShapeFunctionFactory< FunctionSpace, polOrder > ShapeFunctionFactoryType;
      typedef SimpleShapeFunctionSet< typename ShapeFunctionFactoryType::ShapeFunctionType > BaseType;

    public:
      LagrangeShapeFunctionSet ( const Dune::GeometryType &type )
      : BaseType( ShapeFunctionFactoryType( type ) )
      {}
    };



    // Implementation of LagrangeShapeFunction
    // ---------------------------------------

    template< class FunctionSpace, class GeometryType, unsigned int polOrder >
    inline void LagrangeShapeFunction< FunctionSpace, GeometryType, polOrder >
      ::evaluate ( const DomainType &x, RangeType &value ) const
    {
      FieldVector< int, 0 > diffVariable;
      return genericShapeFunction_.evaluate( diffVariable, x, value );
    }


    template< class FunctionSpace, class GeometryType, unsigned int polOrder >
    inline void LagrangeShapeFunction< FunctionSpace, GeometryType, polOrder >
      ::jacobian ( const DomainType &x, JacobianRangeType &jacobian ) const
    {
      FieldVector< int, 1 > diffVariable;
      RangeType tmp;

      int &i = diffVariable[ 0 ];
      for( i = 0; i < dimension; ++i )
      {
        genericShapeFunction_.evaluate( diffVariable, x, tmp );
        jacobian[ 0 ][ i ] = tmp[ 0 ];
      }
    }


    template< class FunctionSpace, class GeometryType, unsigned int polOrder >
    inline void LagrangeShapeFunction< FunctionSpace, GeometryType, polOrder >
      ::hessian ( const DomainType &x, HessianRangeType &hessian ) const
    {
      FieldVector< int, 2 > diffVariable;
      RangeType tmp;

      int &i = diffVariable[ 0 ];
      for( i = 0; i < dimension; ++i )
      {
        // we use symmetrized evaluation of the hessian, since calling
        // evaluate is in general quite expensive
        int &j = diffVariable[ 1 ];
        for( j = 0; j < i; ++j )
        {
          genericShapeFunction_.evaluate( diffVariable, x, tmp );
          hessian[ 0 ][ i ][ j ] = hessian[ 0 ][ j ][ i ] = tmp[ 0 ];
        }

        assert( j == i );
        genericShapeFunction_.evaluate( diffVariable, x, tmp );
        hessian[ 0 ][ i ][ i ] = tmp[ 0 ];
      }
    }



    // LagrangeShapeFunctionFactory::Switch
    // ------------------------------------

    template< class FunctionSpace, int polOrder >
    template< class Topology >
    struct LagrangeShapeFunctionFactory< FunctionSpace, polOrder >::Switch
    {
      // get generic geometry type
      static const unsigned int topologyId = Topology::id;
      typedef typename GeometryWrapper< topologyId, dimension >
        ::GenericGeometryType GenericGeometryType;

      // type of scalar shape function
      typedef LagrangeShapeFunction< FunctionSpace, GenericGeometryType, polOrder > 
        ShapeFunctionImpl;
      typedef typename ShapeFunctionImpl::GenericBaseFunctionType GenericBaseFunctionType;

      static void apply ( std::size_t &size )
      {
        size = GenericLagrangePoint< GenericGeometryType, polOrder >::numLagrangePoints;
      }

      static void apply ( const std::size_t &i, ShapeFunctionType *&shapeFunction )
      {
        shapeFunction = new ShapeFunctionImpl( GenericBaseFunctionType( i ) );
      }
    };



    // Implementation of LagrangeShapeFunctionFactory
    // ----------------------------------------------

    template< class FunctionSpace, int polOrder >
    const int LagrangeShapeFunctionFactory< FunctionSpace, polOrder >::dimension;


    template< class FunctionSpace, int polOrder >
    inline int LagrangeShapeFunctionFactory< FunctionSpace, polOrder >
      ::order () const
    {
      return polOrder;
    }


    template< class FunctionSpace, int polOrder >
    inline std::size_t LagrangeShapeFunctionFactory< FunctionSpace, polOrder >
      ::numShapeFunctions () const
    {
      std::size_t numShapeFunctions;
      GenericGeometry::IfTopology< Switch, dimension >::apply( topologyId_, numShapeFunctions );
      return numShapeFunctions;
    }


    template< class FunctionSpace, int polOrder >
    inline typename LagrangeShapeFunctionFactory< FunctionSpace, polOrder >::ShapeFunctionType *
    LagrangeShapeFunctionFactory< FunctionSpace, polOrder >
      ::createShapeFunction( const std::size_t i ) const
    {
      ShapeFunctionType *shapeFunction( nullptr );
      GenericGeometry::IfTopology< Switch, dimension >::apply( topologyId_, i, shapeFunction );
      return shapeFunction;
    }



    // Extern Template Instantiations
    // ------------------------------

    extern template class LagrangeShapeFunctionFactory< FunctionSpace< double, double, 1, 1 >, 1 >;
    extern template class LagrangeShapeFunctionFactory< FunctionSpace< double, double, 2, 1 >, 1 >;
    extern template class LagrangeShapeFunctionFactory< FunctionSpace< double, double, 3, 1 >, 1 >;
    extern template class LagrangeShapeFunctionFactory< FunctionSpace< float, float, 1, 1 >, 1 >;
    extern template class LagrangeShapeFunctionFactory< FunctionSpace< float, float, 2, 1 >, 1 >;
    extern template class LagrangeShapeFunctionFactory< FunctionSpace< float, float, 3, 1 >, 1 >;

    extern template class LagrangeShapeFunctionFactory< FunctionSpace< double, double, 1, 1 >, 2 >;
    extern template class LagrangeShapeFunctionFactory< FunctionSpace< double, double, 2, 1 >, 2 >;
    extern template class LagrangeShapeFunctionFactory< FunctionSpace< double, double, 3, 1 >, 2 >;
    extern template class LagrangeShapeFunctionFactory< FunctionSpace< float, float, 1, 1 >, 2 >;
    extern template class LagrangeShapeFunctionFactory< FunctionSpace< float, float, 2, 1 >, 2 >;
    extern template class LagrangeShapeFunctionFactory< FunctionSpace< float, float, 3, 1 >, 2 >;

    extern template class LagrangeShapeFunctionFactory< FunctionSpace< double, double, 1, 1 >, 3 >;
    extern template class LagrangeShapeFunctionFactory< FunctionSpace< double, double, 2, 1 >, 3 >;
    extern template class LagrangeShapeFunctionFactory< FunctionSpace< double, double, 3, 1 >, 3 >;
    extern template class LagrangeShapeFunctionFactory< FunctionSpace< float, float, 1, 1 >, 3 >;
    extern template class LagrangeShapeFunctionFactory< FunctionSpace< float, float, 2, 1 >, 3 >;
    extern template class LagrangeShapeFunctionFactory< FunctionSpace< float, float, 3, 1 >, 3 >;

  } // namespace Fem

} // namespace Dune

#endif // #ifndef DUNE_FEM_SPACE_LAGRANGE_SHAPEFUNCTIONSET_HH
