/**************************************************************************
 
  The dune-fem module is a module of DUNE (see www.dune-project.org).
  It is based on the dune-grid interface library 
  extending the grid interface by a number of discretization algorithms
  for solving non-linear systems of partial differential equations.

  Copyright (C) 2003 - 2013 Robert Kloefkorn
  Copyright (C) 2003 - 2010 Mario Ohlberger 
  Copyright (C) 2004 - 2013 Andreas Dedner
  Copyright (C) 2005        Adrian Burri
  Copyright (C) 2005 - 2012 Mirko Kraenkel
  Copyright (C) 2006 - 2013 Christoph Gersbacher
  Copyright (C) 2006 - 2013 Martin Nolte
  Copyright (C) 2011 - 2013 Tobias Malkmus

  The dune-fem module is free software; you can redistribute it and/or 
  modify it under the terms of the GNU General Public License as 
  published by the Free Software Foundation; either version 2 of 
  the License, or (at your option) any later version.

  The dune-fem module is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along
  with this program; if not, write to the Free Software Foundation, Inc.,
  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 
**************************************************************************/
#ifndef DUNE_FEM_SPACE_LAGRANGE_RESTRICTPROLONG_HH
#define DUNE_FEM_SPACE_LAGRANGE_RESTRICTPROLONG_HH

// C++ includes
#include <map>

// dune-geometry includes
#include <dune/geometry/referenceelements.hh>
#include <dune/geometry/type.hh>

// dune-fem includes
#include <dune/fem/gridpart/leafgridpart.hh>
#include <dune/fem/function/localfunction/localfunction.hh>

// local includes
#include "lagrangepoints.hh"


namespace Dune
{

  namespace Fem
  {

    template< class G, int ord >
    struct LagrangeLocalRestrictProlong
    {
      typedef G GridType;

      typedef typename GridType::ctype ctype;
      static const int dimension = GridType::dimension;

      typedef FieldVector< ctype, dimension > DomainVector;

      typedef LagrangePointSet< LeafGridPart< GridType >, ord > LagrangePointSetType;

    private:
      typedef typename LagrangePointSetType::template Codim< 0 >::SubEntityIteratorType
        EntityDofIterator;

      typedef std::map< const GeometryType, const LagrangePointSetType * > LagrangePointSetMapType;

    public:
      ~LagrangeLocalRestrictProlong ()
      {
        typedef typename LagrangePointSetMapType::iterator Iterator;
        const Iterator end = lagrangePointSet_.end();
        for( Iterator it = lagrangePointSet_.begin(); it != end; ++it )
          delete it->second;
      }

      template< class DomainField >
      void setFatherChildWeight ( const DomainField &weight ) {}

      template< class FT, class ST, class LocalGeometry >
      void restrictLocal ( LocalFunction< FT > &lfFather,
                           const LocalFunction< ST > &lfSon,
                           const LocalGeometry &geometryInFather,
                           const bool initialize ) const
      {
        static const int dimRange = LocalFunction< ST >::dimRange;

        const Dune::ReferenceElement< ctype, dimension > &refSon
          = Dune::ReferenceElements< ctype, dimension >::general( lfSon.entity().type() );

        const LagrangePointSetType &pointSet = lagrangePointSet( lfFather.entity() );

        const EntityDofIterator send = pointSet.template endSubEntity< 0 >( 0 );
        for( EntityDofIterator sit = pointSet.template beginSubEntity< 0 >( 0 ); sit != send; ++sit )
        {
          const unsigned int dof = *sit;
          const DomainVector &pointInFather = pointSet.point( dof );
          const DomainVector pointInSon = geometryInFather.local( pointInFather );
          if( refSon.checkInside( pointInSon ) )
          {
            typename LocalFunction< ST >::RangeType phi;
            lfSon.evaluate( pointInSon, phi );
            for( int coordinate = 0; coordinate < dimRange; ++coordinate )
              lfFather[ dimRange * dof + coordinate ] = phi[ coordinate ];
          }
        }
      }

      template< class FT, class ST, class LocalGeometry >
      void prolongLocal ( const LocalFunction< FT > &lfFather, LocalFunction< ST > &lfSon,
                          const LocalGeometry &geometryInFather,
                          bool initialize ) const
      {
        static const int dimRange = LocalFunction< FT >::dimRange;

        const LagrangePointSetType &pointSet = lagrangePointSet( lfSon.entity() );

        const EntityDofIterator send = pointSet.template endSubEntity< 0 >( 0 );
        for( EntityDofIterator sit = pointSet.template beginSubEntity< 0 >( 0 ); sit != send; ++sit )
        {
          const unsigned int dof = *sit;
          const DomainVector &pointInSon = pointSet.point( dof );
          const DomainVector pointInFather = geometryInFather.global( pointInSon );
          
          typename LocalFunction< FT >::RangeType phi;
          lfFather.evaluate( pointInFather, phi );
          for( int coordinate = 0; coordinate < dimRange; ++coordinate )
            lfSon[ dimRange * dof + coordinate ] = phi[ coordinate ];
        }
      }

      bool needCommunication () const { return false; }

    protected:
      template< class Entity >
      const LagrangePointSetType &lagrangePointSet ( const Entity &entity ) const
      {
        return lagrangePointSet( entity.type() );
      }

      const LagrangePointSetType &lagrangePointSet ( const GeometryType &type ) const
      {
        typedef typename LagrangePointSetMapType::iterator Iterator;
        Iterator it = lagrangePointSet_.find( type );
        if( it == lagrangePointSet_.end() )
          it = lagrangePointSet_.insert( it, std::make_pair( type, new LagrangePointSetType( type, ord ) ) );
        assert( it->second != 0 );
        return *(it->second);
      }

    private:
      mutable LagrangePointSetMapType lagrangePointSet_;
    };

  } // namespace Fem 

} // namespace Dune

#endif // #ifndef DUNE_FEM_SPACE_LAGRANGE_RESTRICTPROLONG_HH
