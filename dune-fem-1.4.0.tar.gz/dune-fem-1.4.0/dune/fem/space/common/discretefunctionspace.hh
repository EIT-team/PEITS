/**************************************************************************
 
  The dune-fem module is a module of DUNE (see www.dune-project.org).
  It is based on the dune-grid interface library 
  extending the grid interface by a number of discretization algorithms
  for solving non-linear systems of partial differential equations.

  Copyright (C) 2003 - 2013 Robert Kloefkorn
  Copyright (C) 2003 - 2010 Mario Ohlberger 
  Copyright (C) 2004 - 2013 Andreas Dedner
  Copyright (C) 2005        Adrian Burri
  Copyright (C) 2005 - 2012 Mirko Kraenkel
  Copyright (C) 2006 - 2013 Christoph Gersbacher
  Copyright (C) 2006 - 2013 Martin Nolte
  Copyright (C) 2011 - 2013 Tobias Malkmus

  The dune-fem module is free software; you can redistribute it and/or 
  modify it under the terms of the GNU General Public License as 
  published by the Free Software Foundation; either version 2 of 
  the License, or (at your option) any later version.

  The dune-fem module is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along
  with this program; if not, write to the Free Software Foundation, Inc.,
  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 
**************************************************************************/
#ifndef DUNE_FEM_DISCRETEFUNCTIONSPACE_HH
#define DUNE_FEM_DISCRETEFUNCTIONSPACE_HH

// C++ includes
#include <cassert>

// dune-common includes 
#include <dune/common/bartonnackmanifcheck.hh>
#include <dune/common/nullptr.hh>

// dune-fem includes
#include <dune/fem/function/localfunction/wrapper.hh>
#include <dune/fem/function/localfunction/temporary.hh>
#include <dune/fem/space/common/commoperations.hh>
#include <dune/fem/space/common/communicationmanager.hh>
#include <dune/fem/space/common/dofmanager.hh>
#include <dune/fem/space/common/functionspace.hh>
#include <dune/fem/storage/singletonlist.hh>
#include <dune/fem/version.hh>

// local includes 
#include "allgeomtypes.hh"
#include "dofstorage.hh"


namespace Dune
{

  namespace Fem
  {

    /** @addtogroup DiscreteFunctionSpace 
        This provides the interfaces for discrete function spaces. 
        Discrete function spaces contain functions
        from a \ref FunctionSpaceInterface "function space"
        but the domain is defined by a grid
        or more precisly by a \ref GridPart "grid part".
   
        \remarks The interface for using a DiscreteFunctionSpace is
        defined by the class DiscreteFunctionSpaceInterface.

        @{
    */

    // ExportsDiscreteFunctionSpaceType
    // --------------------------------

    template< class T >
    class ExportsDiscreteFunctionSpaceType
    {
      typedef char Small;
      struct Big { char dummy[ 2 ]; };

      template< class U >
      static Small test ( const U &, typename U::DiscreteFunctionSpaceType * = nullptr );
      static Big test ( ... );

      static const T &makeT ();

      template< class U, bool >
      struct GetDiscreteFunctionSpaceType;

      template< class U >
      struct GetDiscreteFunctionSpaceType< U, true >
      {
        typedef typename U::DiscreteFunctionSpaceType Type;
      };

      template< class U >
      struct GetDiscreteFunctionSpaceType< U, false >
      {
        typedef void Type;
      };

    public:
      static const bool v = (sizeof( test( makeT() ) ) == sizeof( Small ));
      typedef typename GetDiscreteFunctionSpaceType< T, v >::Type Type;
    };



    // DFSpaceIdentifier
    // -----------------

    //! \brief enumerator for identification of spaces 
    enum DFSpaceIdentifier {
      CombinedSpace_id,       //!< id for Combined Space 
      DFAdapter_id,           //!< id for DiscreteFunctionSpace Adapter
      DGSpace_id,             //!< id for Discontinuous Galerkin Space 
      FiniteVolumeSpace_id,   //!< id for Finite Volume Space 
      FourierSpace_id,        //!< id for Fourier space
      GenericSpace_id,        //!< id for Generic Space
      LagrangeSpace_id,       //!< id for Lagrange Space
      RannacherTurekSpace_id  //!< id for Rannacher-Turek space
    };


    struct isGenericDiscreteFunctionSpace
    {};

    template< class DiscreteFunctionSpaceImp, 
              class NewFunctionSpace>
    struct DifferentDiscreteFunctionSpace;

    template <class FunctionSpaceImp,
              class GridPartImp,
              int polOrd,
              template <class> class StorageImp,
              template <class,class,int,template <class> class> class DiscreteFunctionSpaceImp,
              class NewFunctionSpace> 
    struct DifferentDiscreteFunctionSpace<
        DiscreteFunctionSpaceImp<FunctionSpaceImp,GridPartImp,polOrd,StorageImp>, 
            NewFunctionSpace>
    {
      typedef DiscreteFunctionSpaceImp< NewFunctionSpace, GridPartImp, polOrd, StorageImp > Type;
    };

    //**************************************************************************
    //
    //  --DiscreteFunctionSpaceInterface
    //
    /**  
      \brief This is the interface for discrete function spaces. All methods
      declared here have to be implemented by the implementation class.

      The discrete function space always depends on a given grid. 
      For all diffrent element types of the grid the function space provides 
      a set of base functions for the different element types. 
      Because of the knowledge of on the one hand the grid an on the other
      hand the base functions sets, the discrete function space provides the size
      of the function space and a mapping from entity and local dof number
      to global dof number of the level of the entity.
      \note A DiscreteFunctionSpace is defined on a certain grid part.
     
      \interfaceclass 
    */
    template< class FunctionSpaceTraits >
    class DiscreteFunctionSpaceInterface
    : public FunctionSpaceTraits :: FunctionSpaceType
    {
    public:
      //! type of traits class 
      typedef FunctionSpaceTraits Traits;

      //! type of DiscretefunctionSapce implementation (Barton-Nackman)
      typedef typename Traits :: DiscreteFunctionSpaceType
        DiscreteFunctionSpaceType;
      //! type of \ref Dune::Fem::FunctionSpaceInterface "function space"
      typedef typename Traits :: FunctionSpaceType FunctionSpaceType;
      
    private:
      typedef FunctionSpaceType BaseType;

    public:
      //! type of \ref Dune::Fem::BasisFunctionSet "basis function set" of this space 
      typedef typename Traits :: BasisFunctionSetType BasisFunctionSetType;
      //! type of \ref Dune::DofMapper "DoF mapper" of this space
      typedef typename Traits :: MapperType MapperType;
      //! type of block mapper of this space
      typedef typename Traits :: BlockMapperType BlockMapperType;

      //! size of local blocks
      enum { localBlockSize = Traits :: localBlockSize };

      //! type of underlying \ref GridPart "grid part" 
      typedef typename Traits :: GridPartType GridPartType;

      //! type of underlying dune grid  
      typedef typename GridPartType :: GridType GridType;
      //! type of used dune index set 
      typedef typename GridPartType :: IndexSetType IndexSetType;
      /** \brief type of iterator for grid traversal
       *
       *  \note Only grid traversal for codimension 0 is currently supported.
       */
      typedef typename GridPartType :: template Codim< Traits::codimension > :: IteratorType
        IteratorType;
      //! type of entity of codimension 0
      typedef typename GridPartType :: template Codim< Traits::codimension > :: EntityType EntityType;
      //! type of the intersections
      typedef typename GridPartType :: IntersectionType IntersectionType;

      /** \brief defines type of data handle for communication
       *  \param  DiscreteFunction  type of \ref Dune::Fem::DiscreteFunctionInterface
       *                            "discrete function" to communicate
       *  \param  Operation         type of operation to perform on communication
       *                            (defaults to copy)
       */
      template< class DiscreteFunction,
                class Operation =  // get default type from traits 
                  typename Traits :: template CommDataHandle< DiscreteFunction > :: OperationType
              >
      struct CommDataHandle
      {
        //! type of communication data handle
        typedef typename Traits
          :: template CommDataHandle< DiscreteFunction, Operation > :: Type
          Type;

        //! type of operation to perform on scatter
        typedef typename Traits
          :: template CommDataHandle< DiscreteFunction, Operation > :: OperationType
          OperationType;
      };

      //! type of communication manager 
      typedef CommunicationManager< DiscreteFunctionSpaceType > CommunicationManagerType;

      //! \brief typedef struct for defining the same discrete function space with a different function space 
      template< class NewFunctionSpace >
      struct ToNewFunctionSpace
      {
        //! type of my discrete function space with new function space
        typedef typename DifferentDiscreteFunctionSpace< DiscreteFunctionSpaceType, NewFunctionSpace> :: Type Type;
      };

      //! \brief typedef struct for defining the same discrete function space with a different dimRange
      template< int newDimRange >
      struct ToNewDimRange
      {
        typedef typename ToNewDimRangeFunctionSpace< FunctionSpaceType, newDimRange > :: Type NewFunctionSpaceType;

        //! type of my discrete function space with new dim range 
        typedef typename ToNewFunctionSpace< NewFunctionSpaceType > :: Type  Type;
      };

    private:
      dune_static_assert( (Conversion<typename BaseType::DomainFieldType,
                                      typename GridType::ctype>::sameType),
                          "Domain field type of function space must equal field type of grid." );

    protected:
      DiscreteFunctionSpaceInterface ()
      {}

    public:

      // Methods Provided by the Implementation
      // --------------------------------------

      /** \brief return type identifier of discrete function space 
          \return return type identifier of discrete function space
      */
      DFSpaceIdentifier type () const 
      {
        CHECK_INTERFACE_IMPLEMENTATION(asImp().type());
        return asImp().type();
      }

   
      /** \brief get basis function set for given entity
       *
       *  \param[in]  entity  entity (of codim 0) for which base function is
       *                      requested
       *
       *  \returns BasisFunctionSet for the entity
       */
      inline const BasisFunctionSetType basisFunctionSet ( const EntityType &entity ) const
      {
        CHECK_INTERFACE_IMPLEMENTATION( asImp().basisFunctionSet( entity ) );
        return asImp().basisFunctionSet( entity );
      }

      /** \brief returns true if the space contains DoFs of given codimension
       * 
       *  \param[in]  codim  codimension to check for DoFs
       *  
       *  \returns \b true if codimension contains DoFs,
       *           \b false otherwise
       */
      DUNE_VERSION_DEPRECATED(1,4,remove) 
      inline bool contains ( const int codim ) const
      { 
        return blockMapper().contains( codim ); 
      }

      /** \brief returns true if the space contains only globally continuous
       *         functions
       *
       *  For example, a \ref Dune::Fem::LagrangeDiscreteFunctionSpace
       *  "Lagrange space" returns \b true while a \ref
       *  Dune::Fem::DiscontinuousGalerkinSpace "discontiuous Galerkin space" returns
       *  \b false.
       *
       *  \returns \b true  if the space contians only globally continous
       *                    functions,
       *           \b false otherwise
       */
      inline bool continuous () const
      { 
        CHECK_INTERFACE_IMPLEMENTATION( asImp().continuous() );
        return asImp().continuous(); 
      }

      /** \brief get index of the sequence in grid sequences
       *
       *  \return number of current sequence
       */
      inline int sequence () const
      { 
        CHECK_INTERFACE_IMPLEMENTATION( asImp().sequence() );
        return asImp().sequence();
      }

      /** \brief get global order of space
       *
       *  \return order of space, i.e., the maximal polynomial order of base
       *          functions 
       */
      inline int order () const 
      { 
        CHECK_INTERFACE_IMPLEMENTATION( asImp().order() );
        return asImp().order();
      } 
    
      /** \brief get order of space for given entity 
       *  \param entity Entity for which we want to obtain the polynomial order
       *
       *  \return polorder of space on the given entity 
       */
      inline int order ( const EntityType& entity ) const DUNE_DEPRECATED
      { 
        CHECK_INTERFACE_IMPLEMENTATION( asImp().order( entity ) );
        return asImp().order( entity );
      } 
    
      /** \brief returns true if discrete functions over this space have zero jump
       *         over the given intersection.
       *
       *  For example, a \ref Dune::Fem::LagrangeDiscreteFunctionSpace
       *  "Lagrange space" returns \b true iff the intersection is conforming while a \ref
       *  Dune::Fem::DiscontinuousGalerkinSpace "discontiuous Galerkin space" always returns
       *  \b false.
       *
       *  \param intersection Intersection for which we want to know the continuety 
       *  \returns \b true  if the space contians functions which are continuous over the
       *                    intersection,
       *           \b false otherwise
       */
      inline bool continuous (const IntersectionType &intersection) const
      { 
        CHECK_INTERFACE_IMPLEMENTATION( asImp().continuous(intersection) );
        return asImp().continuous(intersection); 
      }


      /** \brief get a reference to the DoF mapper
       *
       *  \returns refernce to mapper
       */    
      inline 
      DUNE_VERSION_DEPRECATED(1,4,remove) 
      MapperType &mapper () const
      {
        CHECK_INTERFACE_IMPLEMENTATION( asImp().mapper() );
        return asImp().mapper();
      }

      /** \brief get a reference to the block mapper
       *
       *  \returns refernce to the block mapper
       */    
      inline BlockMapperType &blockMapper () const
      {
        CHECK_INTERFACE_IMPLEMENTATION( asImp().blockMapper() );
        return asImp().blockMapper();
      }
      
      /** \brief get reference to grid this discrete function space belongs to
       * 
       *  \returns constant reference to grid  
       */
      inline const GridType &grid () const
      { 
        CHECK_INTERFACE_IMPLEMENTATION( asImp().grid() );
        return asImp().grid(); 
      }

      /** \brief get reference to grid this discrete function space belongs to
       * 
       *  \returns reference to grid  
       */
      inline GridType &grid ()
      { 
        CHECK_INTERFACE_IMPLEMENTATION( asImp().grid() );
        return asImp().grid(); 
      }

#if 0
      /** \brief get a reference to the associated grid partition
       *
       *  \returns constant reference to the grid partition
       */
      inline const GridPartType &gridPart () const
      { 
        CHECK_INTERFACE_IMPLEMENTATION( asImp().gridPart() );
        return asImp().gridPart(); 
      }
#endif
      
      /** \brief get a reference to the associated grid partition
       *
       *  \returns reference to the grid partition
       */
      inline GridPartType &gridPart ()
      { 
        CHECK_INTERFACE_IMPLEMENTATION(asImp().gridPart());
        return asImp().gridPart(); 
      }

      /** \brief Get a reference to the associated index set
       *
       *  \returns const reference to index set
       */ 
      inline const IndexSetType &indexSet () const
      {
        CHECK_INTERFACE_IMPLEMENTATION( asImp().indexSet() );
        return asImp().indexSet();
      }

      /** \brief get number of DoFs for this space
       *
       *  \returns number of DoFs (degrees of freedom)
       */
      inline int size () const
      { 
        CHECK_INTERFACE_IMPLEMENTATION( asImp().size() );
        return asImp().size();
      }

      /** \brief get iterator pointing to the first entity of the associated grid
       *         partition
       *
       *  \returns iterator pointing to first entity
       */
      inline IteratorType begin () const
      {
        CHECK_INTERFACE_IMPLEMENTATION( asImp().begin() );
        return asImp().begin();
      }

      /** \brief get iterator pointing behind the last entity of the associated
       *         grid partition
       *
       *  \returns iterator pointing behind last entity
       */
      inline IteratorType end () const
      {
        CHECK_INTERFACE_IMPLEMENTATION( asImp().end() );
        return asImp().end();
      }
      
      /** \brief apply a functor to each entity in the associated grid partition
       *
       *  The functor must provide an the following operator
       *  \code
       *  template< class EntityType >
       *  void operator() ( const EntityType & );
       *  \endcode
       *
       *  \param[in]  f  functor to apply
       */
      template< class FunctorType >
      inline void forEach ( FunctorType &f ) const
      {
        CHECK_AND_CALL_INTERFACE_IMPLEMENTATION( asImp().forEach( f ) );
      }

      /** \brief returns true if the grid has more than one geometry type
       *
       *  \return \b true if the underlying grid has more than one geometry type
       *          (hybrid grid), \b false otherwise 
       */
      inline bool multipleGeometryTypes () const
      { 
        CHECK_INTERFACE_IMPLEMENTATION( asImp().multipleGeometryTypes() );
        return asImp().multipleGeometryTypes();
      }

      /** \brief returns true if base function sets depend on the entity
       *
       *  \returns \b true if base function set depend on entities, \b false
       *           otherwise
       */
      inline bool multipleBaseFunctionSets () const DUNE_DEPRECATED
      {
        return multipleBasisFunctionSets();
      }
      
      /** \brief returns true if base function sets depend on the entity
       *
       *  \returns \b true if base function set depend on entities, \b false
       *           otherwise
       */
      inline bool multipleBasisFunctionSets () const
      {
        CHECK_INTERFACE_IMPLEMENTATION( asImp().multipleBasisFunctionSets() );
        return asImp().multipleBasisFunctionSets();
      }

      /** \brief Map local DoF number to global DoF number
       *
       *  Maps an entity and a local DoF number to a global DoF number, i.e.,
       *  the index of the DoF within the DoF vector.
       *
       *  \param[in]  entity    entity (of codim 0) for which the mapping is done
       *  \param[in]  localDof  local dof number
       *
       *  \returns global DoF number
       */    
      inline int mapToGlobal ( const EntityType &entity,
                               const int localDof ) const DUNE_DEPRECATED
      {
        CHECK_INTERFACE_IMPLEMENTATION( asImp().mapToGlobal( entity, localDof ) );
        return asImp().mapToGlobal( entity, localDof );
      }


      /** \brief return the communication interface appropriate for this space 
          \return communication interface 
      */
      InterfaceType communicationInterface() const
      {
        CHECK_INTERFACE_IMPLEMENTATION( asImp().communicationInterface() );
        return asImp().communicationInterface();
      }

      /** \brief return the communication direction appropriate for this space 
          \return communication direction  
      */
      CommunicationDirection communicationDirection() const
      {
        CHECK_INTERFACE_IMPLEMENTATION( asImp().communicationDirection() );
        return asImp().communicationDirection();
      }

      /** \brief return reference to communicator (see CommunicationManager)
          \return reference to communicator 
      */
      const CommunicationManagerType& communicator() const
      {
        CHECK_INTERFACE_IMPLEMENTATION( asImp().communicator() );
        return asImp().communicator();
      }

      /** \brief communicate data for given discrete function using the space's
       *         default communication operation
       *
       *  \param  discreteFunction  discrete function to be communicated
       */
      template <class DiscreteFunction>
      void communicate(DiscreteFunction& discreteFunction) const
      {
        CHECK_AND_CALL_INTERFACE_IMPLEMENTATION(
            asImp().communicate( discreteFunction ) );
      }

      /** \brief communicate data for given discrete function
       *
       *  \param      discreteFunction  discrete function to be communicated
       *  \param[in]  op                communication operation to use
       *                                (see DFCommunicationOperation)
       */
      template <class DiscreteFunction, class Operation>
      void communicate(DiscreteFunction& discreteFunction, const Operation* op) const
      {
        CHECK_AND_CALL_INTERFACE_IMPLEMENTATION(
            asImp().communicate( discreteFunction , op ) );
      }

      /** \brief return maximal number of local DoFs
       *
       *  \returns an upper bound for the number of local DoFs
       */
      inline int maxNumLocalDofs () const DUNE_DEPRECATED
      {
        CHECK_INTERFACE_IMPLEMENTATION( asImp().maxNumLocalDofs() );
        return asImp().maxNumLocalDofs();
      }

      /** \brief Creates DataHandle for given discrete function
       *
       *  \param[in]  discreteFunction  \ref DiscreteFunctionInterface
       *                                "discrete function" to create the data
       *                                handle for
       *  \param[in]  operation         operation to perform on scatter
       */
      template< class DiscreteFunction, class Operation >
      inline typename CommDataHandle< DiscreteFunction, Operation > :: Type
      createDataHandle ( DiscreteFunction& discreteFunction,
                        const Operation *operation ) const
      {
        CHECK_INTERFACE_IMPLEMENTATION
          ( asImp().createDataHandle( discreteFunction, operation ) );
        return asImp().createDataHandle( discreteFunction, operation );
      }

    protected:
      // Barton-Nackman trick 
      inline const DiscreteFunctionSpaceType &asImp () const
      { 
        return static_cast< const DiscreteFunctionSpaceType & >( *this );
      }

      // Barton-Nackman trick 
      inline DiscreteFunctionSpaceType &asImp()
      { 
        return static_cast< DiscreteFunctionSpaceType & >( *this ); 
      }
    }; // end class DiscreteFunctionSpaceInterface



    /** \brief check two spaces for equality
     *  \relates DiscreteFunctionSpaceInterface
     *  
     *  This is a default implemented equality operator for discrete function
     *  spaces. It assumes the mapper to be a singleton and then compares the
     *  addresses of the two mappers.
     *
     *  Note that this method can be specialized by implementing another version
     *  that uses the exact traits of the discrete function space.
     */
    template< class Traits >
    inline bool operator== ( const DiscreteFunctionSpaceInterface< Traits > &X,
                             const DiscreteFunctionSpaceInterface< Traits > &Y )
    {
      return &(X.blockMapper()) == &(Y.blockMapper());
    }



    //---------------------------------------------------------------------------
    //-
    //-  --DiscreteFunctionSpaceDefault
    //-
    //-
    //---------------------------------------------------------------------------
    /** \brief This is the class with default implementations for discrete
       function.
       The  methods not marked with having a default
       in the interface class must be provided by
       the implementation; all other methods
       have a default implementation here.
       
       \remark An reference to the GridPart is
               stored in the default implementation. */
    template< class FunctionSpaceTraits >
    class DiscreteFunctionSpaceDefault
    : public DiscreteFunctionSpaceInterface< FunctionSpaceTraits >
    {
    public:
      typedef FunctionSpaceTraits Traits;
      
    private:
      typedef DiscreteFunctionSpaceDefault< Traits > ThisType;
      typedef DiscreteFunctionSpaceInterface< Traits > BaseType;
      
    public:
      typedef typename Traits :: DiscreteFunctionSpaceType
        DiscreteFunctionSpaceType;

      typedef typename BaseType :: GridPartType GridPartType;
      typedef typename BaseType :: GridType GridType;
      typedef typename BaseType :: IndexSetType IndexSetType;
      typedef typename BaseType :: IteratorType IteratorType;
      typedef typename BaseType :: EntityType EntityType;

      typedef TemporaryLocalFunctionFactory< DiscreteFunctionSpaceType, typename Traits::FunctionSpaceType::RangeFieldType >
        LocalFunctionFactoryType;
      typedef LocalFunctionStack< LocalFunctionFactoryType > LocalFunctionStorageType;

      typedef typename LocalFunctionStorageType :: LocalFunctionType
        LocalFunctionType;

      //! size of local blocks 
      enum { localBlockSize = BaseType :: localBlockSize };

    protected:
      using BaseType :: asImp;

    public:
      using BaseType :: blockMapper;
      using BaseType :: mapper;
      using BaseType :: order ;

      //! type of DoF manager
      typedef DofManager< GridType > DofManagerType;

      //! type of communication manager 
      typedef CommunicationManager< DiscreteFunctionSpaceType > CommunicationManagerType;
    protected:
      GridPartType &gridPart_;

      const LocalFunctionFactoryType lfFactory_;
      mutable LocalFunctionStorageType lfStorage_;
   
      // set of all geometry types possible 
      typedef AllGeomTypes< IndexSetType, GridType > AllGeometryTypes;
      const AllGeometryTypes allGeomTypes_;

      // reference to dof manager 
      DofManagerType& dofManager_;

      // communication manager 
      const InterfaceType commInterface_;
      const CommunicationDirection commDirection_;
      mutable CommunicationManagerType *communicator_;
   
    public:
      //! constructor
      explicit DiscreteFunctionSpaceDefault( GridPartType &gridPart,
          const InterfaceType commInterface = InteriorBorder_All_Interface,
          const CommunicationDirection commDirection = ForwardCommunication )
      : BaseType(),
        gridPart_( gridPart ),
        lfFactory_( asImp() ),
        lfStorage_( lfFactory_ ),
        allGeomTypes_( gridPart.indexSet() ),
        dofManager_( DofManagerType :: instance( gridPart.grid() ) ),
        commInterface_( commInterface ),
        commDirection_( commDirection ),
        communicator_( 0 )
      {}

    protected:
      ~DiscreteFunctionSpaceDefault ()
      {
        if( communicator_ != 0 )
          delete communicator_;
      }

    public:
      /** \copydoc Dune::Fem::DiscreteFunctionSpaceInterface::sequence */
      inline int sequence () const
      { 
        return dofManager_.sequence();
      }

      /** \brief default implementation of the method order 
        *
        *  \return returns max polynomial order for each entity using the method order()
      */
      inline int order ( const EntityType& entity ) const 
      { 
        return asImp().basisFunctionSet( entity ).order();
      } 
    
      /** obtain a local function for an entity (to store intermediate values)
       *  
       *  \param[in]  entity  entity (of codim 0) for which a local function is
       *                      desired
       *
       *  \returns a local function backed by a small, fast array
       */
      LocalFunctionType localFunction ( const EntityType &entity ) const
      {
        return lfStorage_.localFunction( entity );
      }
      
      /** \copydoc Dune::Fem::DiscreteFunctionSpaceInterface::grid() const */
      inline const GridType &grid () const
      {
        return asImp().gridPart().grid();
      }

      /** \copydoc Dune::Fem::DiscreteFunctionSpaceInterface::grid() */
      inline GridType &grid ()
      {
        return asImp().gridPart().grid();
      }

      /** \copydoc Dune::Fem::DiscreteFunctionSpaceInterface::gridPart() const */
      inline GridPartType &gridPart () const
      {
        return gridPart_;
      }
     
      /** \copydoc Dune::Fem::DiscreteFunctionSpaceInterface::indexSet() const */
      inline const IndexSetType &indexSet () const
      {
        return asImp().gridPart().indexSet();
      }

      /** \copydoc Dune::Fem::DiscreteFunctionSpaceInterface::size */
      inline int size () const
      {
        return blockMapper().size() * localBlockSize ;
      }
    
      /** \copydoc Dune::Fem::DiscreteFunctionSpaceInterface::begin() const
       *
       *  \note The default implementation uses the codim 0 iterators of the
       *        associated grid partition.
       */
      inline IteratorType begin () const
      {
        return asImp().gridPart().template begin< 0 >();
      }

      /** \copydoc Dune::Fem::DiscreteFunctionSpaceInterface::end() const
       *
       *  \note The default implementation uses the codim 0 iterators of the
       *        associated grid partition.
       */
      inline IteratorType end () const
      {
        return asImp().gridPart().template end< 0 >();
      }

      /** \copydoc Dune::Fem::DiscreteFunctionSpaceInterface::forEach(FunctorType &f) const
       *
       *  \note The default implementation simply does the following:
       *  \code
       *  const IteratorType end = asImp().end();
       *  for( IteratorType it = asImp().begin(); it != end; ++it )
       *    f( *it );
       *  \endcode
       */
      template< class FunctorType >
      inline void forEach ( FunctorType &f ) const
      {
        const IteratorType end = asImp().end();
        for( IteratorType it = asImp().begin(); it != end; ++it )
          f( *it );
      }

      /** \copydoc Dune::Fem::DiscreteFunctionSpaceInterface::multipleGeometryTypes */
      inline bool multipleGeometryTypes () const
      {
        return allGeomTypes_.multipleGeomTypes();
      }

      /** \copydoc Dune::Fem::DiscreteFunctionSpaceInterface::multipleBasisFunctionSets
       *
       *  \note The default implementation returns \b false.
       */
      inline bool multipleBasisFunctionSets () const
      {
        return false;
      }

      /** \copydoc Dune::Fem::DiscreteFunctionSpaceInterface::mapToGlobal(const EntityType &entity,const int localDof) const */
      inline 
      DUNE_VERSION_DEPRECATED(1,4,remove) 
      int mapToGlobal ( const EntityType &entity,
                               const int localDof ) const DUNE_DEPRECATED
      {
        return mapper().mapToGlobal( entity, localDof );
      }

      /** \copydoc Dune::Fem::DiscreteFunctionSpaceInterface::maxNumLocalDofs */
      inline int maxNumLocalDofs () const DUNE_VERSION_DEPRECATED(1,4,remove)
      {
        return mapper().maxNumDofs();
      }

      /** \copydoc Dune::Fem::DiscreteFunctionSpaceInterface::communicationInterface() */
      InterfaceType communicationInterface () const
      {
        return commInterface_;
      }

      /** \copydoc Dune::Fem::DiscreteFunctionSpaceInterface::communicationInterface() */
      CommunicationDirection communicationDirection () const
      {
        return commDirection_;
      }

      /** \copydoc Dune::Fem::DiscreteFunctionSpaceInterface::communicator() */
      const CommunicationManagerType& communicator() const
      {
        if( communicator_ == 0 )
        {
          communicator_
            = new CommunicationManagerType( asImp(), commInterface_, commDirection_ );
        }
        assert( communicator_ != 0 );
        return *communicator_;
      }

      /** \copydoc Dune::Fem::DiscreteFunctionSpaceInterface::communicate(DiscreteFunction &discreteFunction) const */
      template <class DiscreteFunction>
      void communicate(DiscreteFunction& discreteFunction) const
      {
        // get type of default operation 
        typedef typename DiscreteFunction :: DiscreteFunctionSpaceType :: template
          CommDataHandle< DiscreteFunction > :: OperationType  DefaultOperationType;

        // exchange data 
        communicate( discreteFunction, (DefaultOperationType*) 0);
      }

      /** \copydoc Dune::Fem::DiscreteFunctionSpaceInterface::communicate(DiscreteFunction &discreteFunction, const Operation *) const */
      template <class DiscreteFunction, class Operation>
      void communicate(DiscreteFunction& discreteFunction, const Operation *op ) const
      {
        communicator().exchange( discreteFunction, (Operation *) 0);
      }

      /** \copydoc Dune::Fem::DiscreteFunctionSpaceInterface::createDataHandle(DiscreteFunction &discreteFunction.const Operation *operation) const
       *
       *  \note The default implementation is
       *  \code
       *  return CommDataHandle< DiscreteFunction, Operation > :: Type( discreteFunction );
       *  \endcode
       */
      template< class DiscreteFunction, class Operation >
      inline typename BaseType
        :: template CommDataHandle< DiscreteFunction, Operation > :: Type
      createDataHandle( DiscreteFunction &discreteFunction,
                        const Operation *operation ) const
      {
        return typename BaseType
          :: template CommDataHandle< DiscreteFunction, Operation >
          :: Type( discreteFunction );
      }

      /** \brief default implementation of addFunction does nothing at the moment */
      template <class DiscreteFunction>
      void addFunction( DiscreteFunction& df ) const
      {
      }

      /** \brief default implementation of removeFunction does nothing at the moment */
      template <class DiscreteFunction>
      void removeFunction( DiscreteFunction& df ) const
      {
      }

      /** \brief default implementation of adapt does nothing,
                 its only used in PAdaptiveLagrangeSpace */
      template <class Vector>
      void adapt( const Vector& polynomialOrders, const int polOrderShift = 0 ) const
      {
      }

    protected:  
      /** \brief returns true if the grid has more than one geometry type
       *
       *  \return \b true if the underlying grid has more than one geometry type
       *          (hybrid grid), \b false otherwise 
       */
      inline const std::vector<GeometryType>& geomTypes(int codim) const 
      { 
        return allGeomTypes_.geomTypes(codim);
      }

      // only combined space should use geomTypes 
      template <class , int , DofStoragePolicy> friend class CombinedSpace;
    };



    ////////////////////////////////////////////////////////////
    //
    //  DiscreteFunctionSpaceAdapter 
    //
    ////////////////////////////////////////////////////////////
    /** \brief Create Obejct that behaves like a discrete function space 
        without to provide functions with the iterator facilities.

        \note DiscreteFunctionSpaceAdapter is itself derived from the template
              argument FunctionSpaceImp. Hence, the constructor will call the
              default constructor of FunctionSpaceImp when this class is
              instanciated. So do not use discrete function spaces for the
              first template argument.
    */
    template< class FunctionSpaceImp, class GridPartImp >
    class DiscreteFunctionSpaceAdapter
    : public FunctionSpaceImp
    {
    public:
      // type of the underlying function space
      typedef FunctionSpaceImp FunctionSpaceType;
      //! type of the grid partition
      typedef GridPartImp GridPartType;

    private:
      typedef DiscreteFunctionSpaceAdapter< FunctionSpaceType, GridPartType >
        ThisType;
      typedef FunctionSpaceType BaseType;

    public:  
      enum { polynomialOrder = 111 };
     
      //! type of the grid
      typedef typename GridPartType :: GridType GridType;
      //! type of the index set 
      typedef typename GridPartType :: IndexSetType IndexSetType; 
      //! type of the grid iterator 
      typedef typename GridPartType :: template Codim< 0 > :: IteratorType
        IteratorType;
      //- type of used entity
      typedef typename GridType :: template Codim< 0 > :: Entity EntityType;
      //- type of intersections
      typedef typename GridPartType :: IntersectionType IntersectionType;

      //! type of communication manager (only the default communication is valid here) 
      typedef DefaultCommunicationManager< ThisType > CommunicationManagerType;

    protected:
      const GridPartType &gridPart_;
      const unsigned int order_;

    public:
      //! constructor taking grid Part 
      inline explicit DiscreteFunctionSpaceAdapter
        ( const GridPartType &gridPart,
          unsigned int order = polynomialOrder )
      : BaseType(),
        gridPart_( gridPart ),
        order_( order )
      {
      }

      //! copy constructor
      inline DiscreteFunctionSpaceAdapter( const ThisType &other )
      : BaseType( other ),
        gridPart_( other.gridPart_ ),
        order_( other.order_ )
      {
      }

      /** \copydoc Dune::Fem::DiscreteFunctionSpaceInterface::begin */
      inline IteratorType begin () const
      {
        return gridPart_.template begin< 0 >();
      }
      
      /** \copydoc Dune::Fem::DiscreteFunctionSpaceInterface::end */
      inline IteratorType end () const
      {
        return gridPart_.template end< 0 >();
      }

      /** \copydoc Dune::Fem::DiscreteFunctionSpaceInterface::forEach(FunctorType &f) const */
      template< class FunctorType >
      inline void forEach ( FunctorType &f ) const
      {
        const IteratorType endit = end();
        for( IteratorType it = begin(); it != endit; ++it )
          f( *it );
      }

      /** \copydoc Dune::Fem::DiscreteFunctionSpaceInterface::gridPart */
      inline const GridPartType &gridPart () const
      {
        return gridPart_;
      }
      
      /** \copydoc Dune::Fem::DiscreteFunctionSpaceInterface::indexSet */
      inline const IndexSetType &indexSet () const
      {
        return gridPart_.indexSet();
      }
      
      /** \copydoc Dune::Fem::DiscreteFunctionSpaceInterface::grid */
      inline const GridType& grid () const
      {
        return gridPart_.grid();
      }

      /** \copydoc Dune::Fem::DiscreteFunctionSpaceInterface::continuous */
      inline bool continuous () const
      {
        return true;
      }
      /** \copydoc Dune::Fem::DiscreteFunctionSpaceInterface::continuous */
      inline bool continuous (const IntersectionType &intersection) const
      { 
        return true;
      }

      /** \copydoc Dune::Fem::DiscreteFunctionSpaceInterface::order */
      inline int order () const
      {
        return order_;
      }

      /** \copydoc Dune::Fem::DiscreteFunctionSpaceInterface::order */
      inline int order ( const EntityType& ) const
      {
        return order();
      }

      /** \copydoc Dune::Fem::DiscreteFunctionSpaceInterface::type */
      inline DFSpaceIdentifier type () const
      {
        return DFAdapter_id;
      }
    };

  ///@}  

    /**\ingroup HelperClasses 
       \brief 
       BasisFunctionSetSingletonFactory provides method createObject and
       deleteObject for the SingletonList  
    */
    template <class KeyImp, class ObjectImp, class ObjectFactoryImp>
    class BaseFunctionSetSingletonFactory
    { 
    public:
      //! create new BaseFunctionSet 
      static ObjectImp * createObject( const KeyImp & key )
      {
        ObjectFactoryImp fac(key); 
        return new ObjectImp(fac); 
      }
      
      //! delete BaseFunctionSet 
      static void deleteObject( ObjectImp * obj ) 
      {
        delete obj;
      }
    };

  } // namespace Fem 

#if DUNE_FEM_COMPATIBILITY  
// put this in next version 1.4 

  using Fem :: DifferentDiscreteFunctionSpace ;

#endif // DUNE_FEM_COMPATIBILITY
  
} // namespace Dune 
#endif // #ifndef DUNE_FEM_DISCRETEFUNCTIONSPACE_HH
