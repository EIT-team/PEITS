/**************************************************************************
 
  The dune-fem module is a module of DUNE (see www.dune-project.org).
  It is based on the dune-grid interface library 
  extending the grid interface by a number of discretization algorithms
  for solving non-linear systems of partial differential equations.

  Copyright (C) 2003 - 2013 Robert Kloefkorn
  Copyright (C) 2003 - 2010 Mario Ohlberger 
  Copyright (C) 2004 - 2013 Andreas Dedner
  Copyright (C) 2005        Adrian Burri
  Copyright (C) 2005 - 2012 Mirko Kraenkel
  Copyright (C) 2006 - 2013 Christoph Gersbacher
  Copyright (C) 2006 - 2013 Martin Nolte
  Copyright (C) 2011 - 2013 Tobias Malkmus

  The dune-fem module is free software; you can redistribute it and/or 
  modify it under the terms of the GNU General Public License as 
  published by the Free Software Foundation; either version 2 of 
  the License, or (at your option) any later version.

  The dune-fem module is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along
  with this program; if not, write to the Free Software Foundation, Inc.,
  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 
**************************************************************************/
#ifndef DUNE_FEM_DOFSTORAGE_HH
#define DUNE_FEM_DOFSTORAGE_HH

namespace Dune 
{
  
  namespace Fem
  {

    //! Indicates how the dofs shall be stored in the discrete functions
    //! Point based means that all dofs belonging to one local degree in a
    //! contained spaced are stored consecutively, whereas in the variable based
    //! approach all dofs belonging to one subspace are stored consecutively
    enum DofStoragePolicy { PointBased, VariableBased };

    //! Utility class that helps in the transformation between dofs in the
    //! combined space and its enclosed spaces
    template <DofStoragePolicy p>
    class DofConversionUtility {
    public:
      DofConversionUtility(int size);

      //! Sets new size (in case the number of dofs changes)
      void newSize(int size);

      //! Component which the actual base function index gives a contribution
      //! \return is in range {0, dimRange-1}
      int component(int combinedIndex) const;
      //! Number of the (scalar) base function belonging to base function index
      int containedDof(int combinedIndex) const;
      
      //! Reverse operation of containedDof, component
      //! i == combinedDof(containedDof(i), component(i))
      int combinedDof(int enclosedIndex, int component) const;
    private:
      int size_;
    };

    //! Specialisation for PointBased approach
    template <>
    class DofConversionUtility<PointBased> {
    public:
      //! Constructor
      //! \param numComponents Number of components in range vector (==dimRange).
      DofConversionUtility(int numComponents) :
        numComponents_(numComponents)
      {}

      //! Find out what type of policy this is.
      static DofStoragePolicy policy() { return PointBased; }

      //! The size of the range vector cannot change, hence this method does
      //! nothing. (In fact, this method is only here so that you can treat
      //! all DofStorageUtility objects identically without knowing whether they
      //! are PointBased or VariableBased.)
      void newSize(int size) {} // just do nothing

      //! Component which the actual base function index gives a contribution
      //! \return is in range {0, dimRange-1}
      int component(int combinedIndex) const { 
        return combinedIndex%numComponents_; 
      }
      //! Number of the (scalar) base function belonging to base function index
      int containedDof(int combinedIndex) const {
        return combinedIndex/numComponents_;
      }

      //! Reverse operation of containedDof, component
      //! i == combinedDof(containedDof(i), component(i))
      int combinedDof(int containedIndex, int component) const {
        return containedIndex*numComponents_ + component;
      }

    private:
      const int numComponents_;
    };

    //! Specialisation for VariableBased approach
    template <>
    class DofConversionUtility<VariableBased> {
    public:
      //! Constructor
      //! \param size Number of global dofs per component.
      DofConversionUtility(int size) :
        size_(size)
      {}

      //! Find out what type of policy this is.
      static DofStoragePolicy policy() { return VariableBased; }

      //! Set new size after adaptation.
      void newSize(int size) { size_ = size; }

      //! Component which the actual base function index gives a contribution
      //! \return is in range {0, dimRange-1}
      int component(int combinedIndex) const { 
        return combinedIndex/size_; 
      }

      //! Number of the (scalar) base function belonging to base function index
      int containedDof(int combinedIndex) const {
        return combinedIndex%size_;
      }

      //! Reverse operation of containedDof, component
      //! i == combinedDof(containedDof(i), component(i))
      int combinedDof(int containedIndex, int component) const {
        return containedIndex + component*size_;
      }

    private:
      int size_;
    };

    //! Specialisation for PointBased approach
    template <unsigned int dimRange>
    class PointBasedDofConversionUtility {
    public:
      //! Constructor
      //! \param numComponents Number of components in range vector (==dimRange).
      PointBasedDofConversionUtility(int numComponents) 
      {}

      //! Find out what type of policy this is.
      static DofStoragePolicy policy() { return PointBased; }

      //! The size of the range vector cannot change, hence this method does
      //! nothing. (In fact, this method is only here so that you can treat
      //! all DofStorageUtility objects identically without knowing whether they
      //! are PointBased or VariableBased.)
      void newSize(const int size) {} // just do nothing

      //! Component which the actual base function index gives a contribution
      //! \return is in range {0, dimRange-1}
      int component(const int combinedIndex) const { 
        return combinedIndex % dimRange; 
      }
      //! Number of the (scalar) base function belonging to base function index
      int containedDof(const int combinedIndex) const {
        return combinedIndex / dimRange;
      }

      //! Reverse operation of containedDof, component
      //! i == combinedDof(containedDof(i), component(i))
      int combinedDof(const int containedIndex, 
                      const int component) const {
        return containedIndex * dimRange + component;
      }
    };

  } // namespace Fem

} // namespace Dune

#endif // #ifndef DUNE_FEM_DOFSTORAGE_HH
