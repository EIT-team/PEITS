/**************************************************************************
 
  The dune-fem module is a module of DUNE (see www.dune-project.org).
  It is based on the dune-grid interface library 
  extending the grid interface by a number of discretization algorithms
  for solving non-linear systems of partial differential equations.

  Copyright (C) 2003 - 2013 Robert Kloefkorn
  Copyright (C) 2003 - 2010 Mario Ohlberger 
  Copyright (C) 2004 - 2013 Andreas Dedner
  Copyright (C) 2005        Adrian Burri
  Copyright (C) 2005 - 2012 Mirko Kraenkel
  Copyright (C) 2006 - 2013 Christoph Gersbacher
  Copyright (C) 2006 - 2013 Martin Nolte
  Copyright (C) 2011 - 2013 Tobias Malkmus

  The dune-fem module is free software; you can redistribute it and/or 
  modify it under the terms of the GNU General Public License as 
  published by the Free Software Foundation; either version 2 of 
  the License, or (at your option) any later version.

  The dune-fem module is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along
  with this program; if not, write to the Free Software Foundation, Inc.,
  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 
**************************************************************************/
#ifndef DUNE_FEM_ADAPTCALLBACKHANDLE_HH
#define DUNE_FEM_ADAPTCALLBACKHANDLE_HH

#include <dune/grid/common/gridenums.hh>
#include <dune/grid/common/adaptcallback.hh>

/** \file
 *  \author Martin Nolte
 *  \brief  interfaces and wrappers needed for the callback adaptation provided
 *          by AlbertaGrid and ALUGrid
 */

namespace Dune
{

  namespace Fem 
  {

    // RestrictProlongWrapper
    // ----------------------

    template< class Grid, class DofManager, class RestrictProlongOperator >
    class RestrictProlongWrapper
    : public AdaptDataHandle
      < Grid, RestrictProlongWrapper< Grid, DofManager, RestrictProlongOperator > >
    {
      typedef RestrictProlongWrapper< Grid, DofManager, RestrictProlongOperator > This;
      typedef AdaptDataHandle< Grid, This > Base;

    protected:  
      DofManager &dofManager_;
      RestrictProlongOperator &rpOp_;

      // flag that is set to true when at least one entity was coarsend or refined 
      mutable bool wasChanged_ ;

    public:
      typedef typename Base::Entity Entity;

      RestrictProlongWrapper ( DofManager &dofManager, RestrictProlongOperator &rpOp )
      : dofManager_( dofManager ),
        rpOp_( rpOp ),
        wasChanged_( false )
      {}

      RestrictProlongWrapper ( const RestrictProlongWrapper& org ) 
      : dofManager_( org.dofManager_ ), 
        rpOp_( org.rpOp_ ),
        wasChanged_( org.wasChanged_ )
      {}

      bool isValidEntity( const Entity& entity ) const
      {
        // grid was changed, if this method is called
        wasChanged_ = true ;

        // ghosts are not valid for restriction/prolongation
        assert( entity.partitionType() != GhostEntity );
        return true ;
      }

      void preAdapt ( const unsigned int estimatedAdditionalElements )
      {
        // unset was changed 
        wasChanged_ = false;
        // reserve memory 
        dofManager_.reserveMemory( estimatedAdditionalElements );
      }

      void postAdapt ()
      {
        // notifyGlobalChange make wasChanged equal on all cores
        if( dofManager_.notifyGlobalChange( wasChanged_ ) )
        {
          // make sure that no communication calls 
          // are done during DofManager::compress
          dofManager_.compress();

          // unset was changed flag
          wasChanged_ = false;
        }
      }

      void preCoarsening ( const Entity &father ) const
      {
        if( isValidEntity( father ) )
        {
          typedef typename Entity::HierarchicIterator HIterator;

          bool initialize = true;
          const int childLevel = father.level() + 1;
          const HIterator end = father.hend( childLevel );
          for( HIterator it = father.hbegin( childLevel ); it != end; ++it )
          {
            restrictLocal( father, *it, initialize );
            initialize = false;
          }
        }
      }
      
      void restrictLocal ( const Entity &father, const Entity &son, bool initialize ) const
      {
        if( isValidEntity( father ) )
        {
          dofManager_.indexSetRestrictProlong().restrictLocal( const_cast< Entity & >( father ), const_cast< Entity & >( son ), initialize );
          rpOp_.restrictLocal( const_cast< Entity & >( father ), const_cast< Entity & >( son ), initialize );
        }
      }

      void postRefinement ( const Entity &father ) const
      {
        if( isValidEntity( father ) )
        {
          typedef typename Entity::HierarchicIterator HIterator;

          bool initialize = true;
          const int childLevel = father.level() + 1;
          const HIterator end = father.hend( childLevel );
          for( HIterator it = father.hbegin( childLevel ); it != end; ++it )
          {
            prolongLocal( father, *it, initialize );
            initialize = false;
          }
        }
      }

      void prolongLocal ( const Entity &father, const Entity &son, bool initialize ) const
      {
        if( isValidEntity( father ) ) 
        {
          dofManager_.indexSetRestrictProlong().prolongLocal( const_cast< Entity & >( father ), const_cast< Entity & >( son ), initialize );
          rpOp_.prolongLocal( const_cast< Entity & >( father ), const_cast< Entity & >( son ), initialize );
        }
      }
    };

  } // namespace Fem 

} // namespace Dune 

#endif // #ifndef DUNE_FEM_ADAPTCALLBACKHANDLE_HH
