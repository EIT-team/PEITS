/**************************************************************************
 
  The dune-fem module is a module of DUNE (see www.dune-project.org).
  It is based on the dune-grid interface library 
  extending the grid interface by a number of discretization algorithms
  for solving non-linear systems of partial differential equations.

  Copyright (C) 2003 - 2013 Robert Kloefkorn
  Copyright (C) 2003 - 2010 Mario Ohlberger 
  Copyright (C) 2004 - 2013 Andreas Dedner
  Copyright (C) 2005        Adrian Burri
  Copyright (C) 2005 - 2012 Mirko Kraenkel
  Copyright (C) 2006 - 2013 Christoph Gersbacher
  Copyright (C) 2006 - 2013 Martin Nolte
  Copyright (C) 2011 - 2013 Tobias Malkmus

  The dune-fem module is free software; you can redistribute it and/or 
  modify it under the terms of the GNU General Public License as 
  published by the Free Software Foundation; either version 2 of 
  the License, or (at your option) any later version.

  The dune-fem module is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along
  with this program; if not, write to the Free Software Foundation, Inc.,
  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 
**************************************************************************/
#ifndef DUNE_FEM_LOCALRESTRICTPROLONG_HH
#define DUNE_FEM_LOCALRESTRICTPROLONG_HH

#include <dune/fem/function/localfunction/localfunction.hh>

namespace Dune
{

  namespace Fem 
  {

    // DefaultLocalRestrictProlong
    // ---------------------------

    template< class DiscreteFunctionSpace >
    class DefaultLocalRestrictProlong;



    // ConstantLocalRestrictProlong
    // ----------------------------

    template< class DiscreteFunctionSpace >
    class ConstantLocalRestrictProlong
    {
      typedef ConstantLocalRestrictProlong< DiscreteFunctionSpace > ThisType;

    public:
      typedef DiscreteFunctionSpace DiscreteFunctionSpaceType;

      typedef typename DiscreteFunctionSpaceType::DomainFieldType DomainFieldType;

      ConstantLocalRestrictProlong ()
      : weight_( -1 )
      {}

      /** \brief explicit set volume ratio of son and father
       *
       *  \param[in]  weight  volume of son / volume of father
       *
       *  \note If this ratio is set, it is assume to be constant.
       */
      void setFatherChildWeight ( const DomainFieldType &weight )
      {
        weight_ = weight;
      }

      //! restrict data to father 
      template< class FT, class ST, class LocalGeometry >
      void restrictLocal ( LocalFunction< FT > &lfFather, const LocalFunction< ST > &lfSon, 
                           const LocalGeometry &geometryInFather, bool initialize ) const
      {
        const DomainFieldType weight = (weight_ < DomainFieldType( 0 ) ? calcWeight( lfFather.entity(), lfSon.entity() ) : weight_); 

        assert( weight > 0.0 );
        //assert( std::abs( geometryInFather.volume() - weight ) < 1e-8 );

        const int numDofs = lfFather.numDofs();
        assert( lfFather.numDofs() == lfSon.numDofs() );
        if( initialize )
        {
          for( int i = 0; i < numDofs; ++i )
            lfFather[ i ] = weight * lfSon[ i ];
        }
        else 
        {
          for( int i = 0; i < numDofs; ++i )
            lfFather[ i ] += weight * lfSon[ i ];
        }
      }

      //! prolong data to children 
      template< class FT, class ST, class LocalGeometry >
      void prolongLocal ( const LocalFunction< FT > &lfFather, LocalFunction< ST > &lfSon,
                          const LocalGeometry &geometryInFather, bool initialize ) const
      {
        const int numDofs = lfFather.numDofs();
        assert( lfFather.numDofs() == lfSon.numDofs() );
        for( int i = 0; i < numDofs; ++i )
          lfSon[ i ] = lfFather[ i ];
      } 

      //! do discrete functions need a communication after restriction / prolongation?
      bool needCommunication () const { return true; }


      template< class Entity >
      static DomainFieldType calcWeight ( const Entity &father, const Entity &son )
      {
        return son.geometry().volume() / father.geometry().volume();
      }

    protected:
      DomainFieldType weight_;
    };



    // EmptyLocalRestrictProlong
    // -------------------------

    template< class DiscreteFunctionSpace >
    class EmptyLocalRestrictProlong
    {
      typedef EmptyLocalRestrictProlong< DiscreteFunctionSpace > ThisType;

    public:
      typedef DiscreteFunctionSpace DiscreteFunctionSpaceType;

      typedef typename DiscreteFunctionSpaceType::DomainFieldType DomainFieldType;

      /** \brief explicit set volume ratio of son and father
       *
       *  \param[in]  weight  volume of son / volume of father
       *
       *  \note If this ratio is set, it is assume to be constant.
       */
      void setFatherChildWeight ( const DomainFieldType &weight ) {}

      //! restrict data to father 
      template< class FT, class ST, class LocalGeometry >
      void restrictLocal ( LocalFunction< FT > &lfFather, const LocalFunction< ST > &lfSon, 
                           const LocalGeometry &geometryInFather, bool initialize ) const
      {}

      //! prolong data to children 
      template< class FT, class ST, class LocalGeometry >
      void prolongLocal ( const LocalFunction< FT > &lfFather, LocalFunction< ST > &lfSon,
                          const LocalGeometry &geometryInFather, bool initialize ) const
      {}

      //! do discrete functions need a communication after restriction / prolongation?
      bool needCommunication () const { return false; }
    };

  } // namespace Fem 

} // namespace Dune

#endif // #ifndef DUNE_FEM_LOCALRESTRICTPROLONG_HH
