/**************************************************************************
 
  The dune-fem module is a module of DUNE (see www.dune-project.org).
  It is based on the dune-grid interface library 
  extending the grid interface by a number of discretization algorithms
  for solving non-linear systems of partial differential equations.

  Copyright (C) 2003 - 2013 Robert Kloefkorn
  Copyright (C) 2003 - 2010 Mario Ohlberger 
  Copyright (C) 2004 - 2013 Andreas Dedner
  Copyright (C) 2005        Adrian Burri
  Copyright (C) 2005 - 2012 Mirko Kraenkel
  Copyright (C) 2006 - 2013 Christoph Gersbacher
  Copyright (C) 2006 - 2013 Martin Nolte
  Copyright (C) 2011 - 2013 Tobias Malkmus

  The dune-fem module is free software; you can redistribute it and/or 
  modify it under the terms of the GNU General Public License as 
  published by the Free Software Foundation; either version 2 of 
  the License, or (at your option) any later version.

  The dune-fem module is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along
  with this program; if not, write to the Free Software Foundation, Inc.,
  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 
**************************************************************************/
#ifndef DUNE_FEM_BASEFUNCTIONSET_FUNCTOR_HH
#define DUNE_FEM_BASEFUNCTIONSET_FUNCTOR_HH

#include <dune/common/fmatrix.hh>
#include <dune/common/fvector.hh>

#include <dune/fem/misc/functor.hh>

namespace Dune
{

  namespace Fem
  {

    // Internal Forward Declarations
    // -----------------------------

    template< class T >
    inline void axpy ( const T &a, const T &x, T &y );

    template< class K, int SIZE >
    inline void axpy ( const typename FieldTraits< K >::field_type &a,
                       const FieldVector< K, SIZE > &x,
                       FieldVector< K, SIZE > &y );

    template< class K, int ROWS, int COLS >
    inline void axpy ( const typename FieldTraits< K >::field_type &a,
                       const FieldMatrix< K, ROWS, COLS > &x,
                       FieldMatrix< K, ROWS, COLS > &y );



    // axpy
    // ----

    template< class T >
    inline void axpy ( const T &a, const T &x, T &y )
    {
      y += a*x;
    }

    template< class K, int SIZE >
    inline void axpy ( const typename FieldTraits< K >::field_type &a,
                       const FieldVector< K, SIZE > &x,
                       FieldVector< K, SIZE > &y )
    {
      for( int i = 0; i < SIZE; ++i )
        axpy( a, x[ i ], y[ i ] );
    }

    template< class K, int ROWS, int COLS >
    inline void axpy ( const typename FieldTraits< K >::field_type &a,
                       const FieldMatrix< K, ROWS, COLS > &x,
                       FieldMatrix< K, ROWS, COLS > &y )
    {
      y.axpy( a, x );
    }



    // scalarProduct
    // -------------

    template< class T >
    inline typename T::field_type scalarProduct ( const T &a, const T &b )
    {
      return a * b;
    }

    template< class K, int ROWS, int COLS >
    inline K scalarProduct ( const FieldMatrix< K, ROWS, COLS > &a, const FieldMatrix< K, ROWS, COLS > &b )
    {
      K s( 0 );
      for( int r = 0; r < ROWS; ++r )
        s += a[ r ] * b[ r ];
      return s;
    }



    // AxpyFunctor
    // -----------

    template< class Vector, class Value >
    struct AxpyFunctor
    {
      AxpyFunctor ( const Vector &vector, Value &value )
      : vector_( vector ),
        value_( value )
      {}

      void operator() ( const std::size_t i, const Value &v )
      {
        axpy( vector_[ i ], v, value_ );
      }

    private:
      const Vector &vector_;
      Value &value_;
    };



    // FunctionalAxpyFunctor
    // ---------------------

    template< class Value, class Vector >
    struct FunctionalAxpyFunctor
    {
      FunctionalAxpyFunctor ( const Value &value, Vector &vector )
      : value_( value ),
        vector_( vector )
      {}

      void operator() ( const std::size_t i, const Value &v )
      {
        vector_[ i ] += scalarProduct( v, value_ );
      }

    private:
      const Value &value_;
      Vector &vector_;
    };

  } // namespace Fem

} // namespace Dune

#endif // #ifndef DUNE_FEM_BASEFUNCTIONSET_FUNCTOR_HH
