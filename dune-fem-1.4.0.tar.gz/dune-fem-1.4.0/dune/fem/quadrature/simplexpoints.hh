/**************************************************************************
 
  The dune-fem module is a module of DUNE (see www.dune-project.org).
  It is based on the dune-grid interface library 
  extending the grid interface by a number of discretization algorithms
  for solving non-linear systems of partial differential equations.

  Copyright (C) 2003 - 2013 Robert Kloefkorn
  Copyright (C) 2003 - 2010 Mario Ohlberger 
  Copyright (C) 2004 - 2013 Andreas Dedner
  Copyright (C) 2005        Adrian Burri
  Copyright (C) 2005 - 2012 Mirko Kraenkel
  Copyright (C) 2006 - 2013 Christoph Gersbacher
  Copyright (C) 2006 - 2013 Martin Nolte
  Copyright (C) 2011 - 2013 Tobias Malkmus

  The dune-fem module is free software; you can redistribute it and/or 
  modify it under the terms of the GNU General Public License as 
  published by the Free Software Foundation; either version 2 of 
  the License, or (at your option) any later version.

  The dune-fem module is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along
  with this program; if not, write to the Free Software Foundation, Inc.,
  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 
**************************************************************************/
#ifndef DUNE_FEM_SIMPLEXPOINTS_HH
#define DUNE_FEM_SIMPLEXPOINTS_HH

#include <vector>
#include <cassert>

//- Dune includes
#include <dune/common/fvector.hh>

// include pardg quadratures 
#include <dune/fem/solver/pardg.hh>

namespace Dune 
{

  namespace Fem 
  {

    //! Adapter to the quadratures defined by parDG.
    template <int dim>
    class ParDGSimplexPointsAdapter {
    public:
      enum { numCorners = dim+1 };
      typedef typename PARDG::Quadrature<dim> ParDGQuadratureType;
      typedef FieldVector<double, dim> CoordinateType;

    public:
      //! Constructor.
      ParDGSimplexPointsAdapter(int order) :
        quad_(ParDGQuadratureType::quadrature(order)),
        order_(order)
      {
      }

      //! Number of quadrature points.
      int numPoints() const 
      {
        return quad_.number_of_points();
      }

      //! The actual order of the quadrature.
      int order() const 
      {
        return order_;
      }

      //! Access to the ith quadrature point.
      CoordinateType point(int i) const 
      {
        assert(i >= 0 && i < numPoints());
        CoordinateType result;
        for (size_t j = 0; j < dim; ++j) 
        {
          result[j] = quad_.x(i)[j];
        }
        return result;
      }

      //! Access to the ith quadrature weight.
      double weight(int i) const 
      {
        assert(i >= 0 && i < numPoints());
        // scale with volume of reference element!
        return quad_.w(i);
      }
      
    private:
      const ParDGQuadratureType& quad_;
      const int order_;
    };

  } // namespace Fem

} // namespace Dune

#endif // #ifndef DUNE_FEM_SIMPLEXPOINTS_HH
