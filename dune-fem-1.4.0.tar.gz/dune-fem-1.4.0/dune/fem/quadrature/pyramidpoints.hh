/**************************************************************************
 
  The dune-fem module is a module of DUNE (see www.dune-project.org).
  It is based on the dune-grid interface library 
  extending the grid interface by a number of discretization algorithms
  for solving non-linear systems of partial differential equations.

  Copyright (C) 2003 - 2013 Robert Kloefkorn
  Copyright (C) 2003 - 2010 Mario Ohlberger 
  Copyright (C) 2004 - 2013 Andreas Dedner
  Copyright (C) 2005        Adrian Burri
  Copyright (C) 2005 - 2012 Mirko Kraenkel
  Copyright (C) 2006 - 2013 Christoph Gersbacher
  Copyright (C) 2006 - 2013 Martin Nolte
  Copyright (C) 2011 - 2013 Tobias Malkmus

  The dune-fem module is free software; you can redistribute it and/or 
  modify it under the terms of the GNU General Public License as 
  published by the Free Software Foundation; either version 2 of 
  the License, or (at your option) any later version.

  The dune-fem module is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along
  with this program; if not, write to the Free Software Foundation, Inc.,
  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 
**************************************************************************/
#ifndef DUNE_FEM_PYRAMIDPOINTS_HH
#define DUNE_FEM_PYRAMIDPOINTS_HH

#include <dune/common/fvector.hh>

namespace Dune 
{

  namespace Fem 
  {

    //! Single point of reference for the quadrature points for pyramids.
    //! This class is a singleton, i.e. all points for all quadratures are
    //! created once.
    class PyramidPoints 
    {  
    public:
      enum { numQuads = 2 };
      enum { MAXP = 8 };
      enum { highest_order = 2 };
    
      //! Access to the singleton object.
      inline static const PyramidPoints& instance() {
        static PyramidPoints pyramidPoints;
        return pyramidPoints;
      }
    
      //! Access to the ith point of quadrature rule m.
      const FieldVector<double, 3>& point(int m, int i) const
      {
        return G[m][i];
      }

      //! Access to the ith weight of quadrature rule m.
      double weight (int m, int i) const
      {
        return W[m][i];
      }

      //! Actual order of quadrature rule m.
      int order (int m) const
      {
        return O[m];
      }
    
      //! Number of points in the quadrature rule m.
      int numPoints(int m) const
      {
        return N[m];
      }

    private:
      //! initialize quadrature points on the interval for all orders
      PyramidPoints()
      {
        int m = 0;
        O[m] = 0;
        N[m] = 0;
        
        // polynom degree 2  ???
        m = 1;
        G[m][0][0] =0.58541020;
        G[m][0][1] =0.72819660;
        G[m][0][2] =0.13819660;
        
        G[m][1][0] =0.13819660;
        G[m][1][1] =0.72819660;
        G[m][1][2] =0.13819660;
        
        G[m][2][0] =0.13819660;
        G[m][2][1] =0.27630920;
        G[m][2][2] =0.58541020;
        
        G[m][3][0] =0.13819660;
        G[m][3][1] =0.27630920;
        G[m][3][2] =0.13819660;
        
        G[m][4][0] =0.72819660;
        G[m][4][1] =0.13819660;
        G[m][4][2] =0.13819660;
        
        G[m][5][0] =0.72819660;
        G[m][5][1] =0.58541020;
        G[m][5][2] =0.13819660;
        
        G[m][6][0] =0.27630920;
        G[m][6][1] =0.13819660;
        G[m][6][2] =0.58541020;
        
        G[m][7][0] =0.27630920;
        G[m][7][1] =0.13819660;
        G[m][7][2] =0.13819660;
        
        W[m][0] = 0.041666667;
        W[m][1] = 0.041666667;
        W[m][2] = 0.041666667;
        W[m][3] = 0.041666667;
        W[m][4] = 0.041666667;
        W[m][5] = 0.041666667;
        W[m][6] = 0.041666667;
        W[m][7] = 0.041666667;
        
        O[m] = 2;// verify ????????
        N[m] = 8;
      }
    
    private:
      FieldVector<double, 3> G[numQuads][MAXP];
      double W[numQuads][MAXP]; // weights associated with points       
      int O[numQuads];          // order of the rule
      int N[numQuads];          // number of points in quadrature rule

    };

  } // namespace Fem

}  // namespace Dune

#endif // #ifndef DUNE_FEM_PYRAMIDPOINTS_HH
