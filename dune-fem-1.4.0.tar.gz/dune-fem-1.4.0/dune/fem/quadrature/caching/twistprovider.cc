/**************************************************************************
 
  The dune-fem module is a module of DUNE (see www.dune-project.org).
  It is based on the dune-grid interface library 
  extending the grid interface by a number of discretization algorithms
  for solving non-linear systems of partial differential equations.

  Copyright (C) 2003 - 2013 Robert Kloefkorn
  Copyright (C) 2003 - 2010 Mario Ohlberger 
  Copyright (C) 2004 - 2013 Andreas Dedner
  Copyright (C) 2005        Adrian Burri
  Copyright (C) 2005 - 2012 Mirko Kraenkel
  Copyright (C) 2006 - 2013 Christoph Gersbacher
  Copyright (C) 2006 - 2013 Martin Nolte
  Copyright (C) 2011 - 2013 Tobias Malkmus

  The dune-fem module is free software; you can redistribute it and/or 
  modify it under the terms of the GNU General Public License as 
  published by the Free Software Foundation; either version 2 of 
  the License, or (at your option) any later version.

  The dune-fem module is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along
  with this program; if not, write to the Free Software Foundation, Inc.,
  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 
**************************************************************************/
namespace Dune 
{

  namespace Fem 
  {

    template <class ct, int dim>
    TwistStorage<ct, dim>::TwistStorage(int minTwist, int maxTwist) :
      mappers_(Traits::twistOffset_ + maxTwist),
      points_(),
      minTwist_(minTwist),
      maxTwist_(maxTwist)
    {}

    template <class ct, int dim>
    void TwistStorage<ct, dim>::addMapper(const MapperType& mapper,
                                          int twist)
    {
      mappers_[twist + Traits::twistOffset_] = mapper;
    }

    template <class ct, int dim>
    size_t TwistStorage<ct, dim>::addPoint(const PointType& point)
    {
      size_t indexOfPoint = points_.size();
      points_.push_back(point);

      return indexOfPoint;
    }

    template <class ct, int dim>
    const typename TwistStorage<ct, dim>::MapperType& 
    TwistStorage<ct, dim>::getMapper(int twist) const 
    {
      return mappers_[twist + Traits::twistOffset_];
    }

    template <class ct, int dim>
    const typename TwistStorage<ct, dim>::PointVectorType&
    TwistStorage<ct, dim>::getPoints() const 
    {
      return points_;
    }

    template <class ct, int dim>
    int TwistStorage<ct, dim>::minTwist() const 
    {
      return minTwist_;
    }

    template <class ct, int dim>
    int TwistStorage<ct, dim>::maxTwist() const 
    {
      return maxTwist_;
    }

    template <class ct, int dim>
    const typename TwistProvider<ct, dim>::TwistStorageType& 
    TwistProvider<ct, dim>::getTwistStorage(const QuadratureType& quad)
    {
      typedef const TwistStorageType* TwistStoragePtr; 
      assert( quad.id() < MapperContainer::instance().size() );
      TwistStoragePtr& ptr = MapperContainer::instance()[ quad.id() ];

      if( ptr == 0 )
      {
        TwistMapperCreator<ct, dim> creator(quad);
        ptr = creator.createStorage();
      }
      
      assert( ptr != 0 );
      return *ptr ;
    }
    
    template <class ct, int dim>
    const ct TwistMapperCreator<ct, dim>::eps_ = 1.0e-5;

    template <class ct, int dim>
    TwistMapperCreator<ct, dim>::TwistMapperCreator(const QuadratureType& quad) :
      quad_(quad),
      helper_( 0 )
    {
      const GeometryType geoType = quad.geometryType();
      if (dim == 0) {
        helper_ = new PointTwistMapperStrategy<ct,dim>( geoType );
      }
      else if (dim == 1) {
        helper_ = new LineTwistMapperStrategy<ct, dim>( geoType );
      } 
      else 
      {
        assert (dim == 2);

        if(geoType.isTriangle()) 
        {
          helper_ = new TriangleTwistMapperStrategy<ct, dim>( geoType );
          return ;
        }
        if( geoType.isQuadrilateral())
        {
          helper_ = new QuadrilateralTwistMapperStrategy<ct,dim>( geoType );
          return ;
        }
        DUNE_THROW(NotImplemented, 
                   "No creator for given GeometryType exists");
      }
    }

    template <class ct, int dim>
    TwistMapperCreator<ct, dim>::~TwistMapperCreator()
    {
      delete helper_ ; helper_ = 0 ;
    }

    template <class ct, int dim>
    const typename TwistMapperCreator<ct, dim>::TwistStorageType* 
    TwistMapperCreator<ct, dim>::createStorage() const 
    {
      TwistStorageType* storage = 
        new TwistStorageType(helper_->minTwist(), helper_->maxTwist());

      // Add quadrature points
      for (size_t i = 0; i < quad_.nop(); ++i) {
        storage->addPoint(quad_.point(i));
      }

      // Loop over all twists
      // and find all mapped quad points 
      for (int twist = helper_->minTwist(); 
           twist < helper_->maxTwist(); ++twist) 
      {
        MapperType mapper(quad_.nop());
        
        const MatrixType& mat = helper_->buildTransformationMatrix(twist);

        for (size_t i = 0; i < quad_.nop(); ++i) 
        {
          // get local quad point 
          PointType pFace = quad_.point(i);

          // create barycentric coordinate
          CoordinateType c(0.0);
          c[0] = 1.0;
          for (int d = 0; d < dim; ++d) {
            c[0] -= pFace[d];
            c[d+1] = pFace[d];
          }

          // apply mapping 
          PointType pRef(0.);     
          mat.umtv(c, pRef);

          bool found = false;
          // find equivalent quadrature point
          for (size_t j = 0; j < quad_.nop(); ++j) 
          {
            // check if | pRef - quad_j | < eps 
            if( (pRef - quad_.point(j)).infinity_norm() < eps_)
            {
              mapper[i] = j;
              found = true;
              break;
            }
          }

          // add point if it is not one of the quadrature points
          if (!found) {
            //if point not found, something is wrong,
            //could be the quadratue or the mapping 
            assert( found ); 
            std::cout << "TwistMapperCreator<ct, dim>::createStorage failed! in: "<<__FILE__<<" line: " << __LINE__ <<"\n";
            abort();
          }
          
        } // for all quadPoints
        storage->addMapper(mapper, twist);
      } // for all twists
      
      return storage;
    }

    template <class ct, int dim>
    PointTwistMapperStrategy<ct, dim>::
    PointTwistMapperStrategy(GeometryType geo) :
      TwistMapperStrategy<ct, dim>(0, 1),
      refElem_(Dune::ReferenceElements<ct, dim>::cube()),
      mat_(0.)
    {
      assert(dim == 0);
    }

    template <class ct, int dim>
    const typename TwistMapperStrategy<ct, dim>::MatrixType&
    PointTwistMapperStrategy<ct, dim>::buildTransformationMatrix(int twist) const 
    {
      assert( twist == 0 );
      mat_[ 0 ] = refElem_.position( 0, dim );
      return mat_;
    }

    template <class ct, int dim>
    LineTwistMapperStrategy<ct, dim>::
    LineTwistMapperStrategy(GeometryType geo) :
      TwistMapperStrategy<ct, dim>(0, 2),
      refElem_(Dune::ReferenceElements<ct, dim>::cube()),
      mat_(0.)
    {
      assert(dim == 1);
    }

    template <class ct, int dim>
    const typename TwistMapperStrategy<ct, dim>::MatrixType&
    LineTwistMapperStrategy<ct, dim>::buildTransformationMatrix(int twist) const 
    {
      assert( (twist == 0) || (twist == 1) );
      mat_[ twist   ] = refElem_.position( 0, dim );
      mat_[ 1-twist ] = refElem_.position( 1, dim );
      return mat_;
    }

    template <class ct, int dim>
    TriangleTwistMapperStrategy<ct, dim>::
    TriangleTwistMapperStrategy(GeometryType geo) :
      TwistMapperStrategy<ct, dim>(-3, 3),
      refElem_(Dune::ReferenceElements<ct, dim>::simplex()),
      mat_(0.)
    {
      assert(dim == 2);
    }

    template <class ct, int dim>
    const typename TwistMapperStrategy<ct, dim>::MatrixType&
    TriangleTwistMapperStrategy<ct, dim>::
    buildTransformationMatrix(int twist) const 
    {
      typedef Dune::Fem::FaceTopologyMapping<tetra> FaceTopo;
      mat_ = 0.0;
      for (int idx = 0; idx < dim+1; ++idx) 
      {
        mat_[idx] = refElem_.position( 
            FaceTopo::twistedDuneIndex(idx, twist), dim); // dim == codim here
      }
      
      return mat_;
    }

    template <class ct, int dim>
    QuadrilateralTwistMapperStrategy<ct, dim>::
    QuadrilateralTwistMapperStrategy(GeometryType geo) :
      TwistMapperStrategy<ct, dim>(-4, 4),
      refElem_(Dune::ReferenceElements<ct, dim>::cube()),
      mat_(0.)
    {
      assert(dim == 2);
    }

    template <class ct, int dim>
    const typename TwistMapperStrategy<ct, dim>::MatrixType& 
    QuadrilateralTwistMapperStrategy<ct, dim>::
    buildTransformationMatrix(int twist) const 
    {
      typedef Dune::Fem::FaceTopologyMapping<hexa> FaceTopo;
      mat_ = 0.0;
      for (int idx = 0; idx < dim+1; ++idx) 
      {
        mat_[idx] = refElem_.position(
            FaceTopo::twistedDuneIndex(idx, twist), dim); // dim == codim here
      }

      return mat_;
    }

  } // namespace Fem

} // namespace Dune
