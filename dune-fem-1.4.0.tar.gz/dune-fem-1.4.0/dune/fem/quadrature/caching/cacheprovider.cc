/**************************************************************************
 
  The dune-fem module is a module of DUNE (see www.dune-project.org).
  It is based on the dune-grid interface library 
  extending the grid interface by a number of discretization algorithms
  for solving non-linear systems of partial differential equations.

  Copyright (C) 2003 - 2013 Robert Kloefkorn
  Copyright (C) 2003 - 2010 Mario Ohlberger 
  Copyright (C) 2004 - 2013 Andreas Dedner
  Copyright (C) 2005        Adrian Burri
  Copyright (C) 2005 - 2012 Mirko Kraenkel
  Copyright (C) 2006 - 2013 Christoph Gersbacher
  Copyright (C) 2006 - 2013 Martin Nolte
  Copyright (C) 2011 - 2013 Tobias Malkmus

  The dune-fem module is free software; you can redistribute it and/or 
  modify it under the terms of the GNU General Public License as 
  published by the Free Software Foundation; either version 2 of 
  the License, or (at your option) any later version.

  The dune-fem module is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along
  with this program; if not, write to the Free Software Foundation, Inc.,
  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 
**************************************************************************/
namespace Dune 
{
  namespace Fem 
  {

    template <class GridPart>
    typename CacheProvider<GridPart, 1>::MapperContainerType
    CacheProvider<GridPart, 1>::mappers_;


    template <class GridPart>
    typename CacheProvider<GridPart, 1>::MapperIteratorType
    CacheProvider<GridPart, 1>::createMapper(const QuadratureType& quad,
                                             GeometryType elementGeometry,
                                             integral_constant< bool, true > )
    {
      typedef TwistProvider<ct, dim-codim> TwistProviderType;
      typedef typename TwistProviderType::TwistStorageType TwistStorageType;

      const TwistStorageType& twistMappers =
        TwistProviderType::getTwistStorage(quad);
      const MapperVectorType pointMappers =
        PointProvider<ct, dim, codim>::getMappers(quad, 
                                                  twistMappers.getPoints(),
                                                  elementGeometry);

      const int numFaces = pointMappers.size();
      const int maxTwist = twistMappers.maxTwist();
      const int minTwist = twistMappers.minTwist();

      QuadratureKeyType key ( elementGeometry, quad.id() );
      MapperIteratorType it = mappers_.insert
        (std::make_pair( key,
                         CacheStorageType(numFaces, maxTwist))).first;

      for (int face = 0; face < numFaces; ++face) 
      {
        for (int twist = minTwist; twist < maxTwist; ++twist) {
          it->second.addMapper(pointMappers[face],
                               twistMappers.getMapper(twist),
                               face, twist);
        }
      }

      return it;
    }



    template <class GridPart>
    typename CacheProvider<GridPart, 1>::MapperIteratorType
    CacheProvider<GridPart, 1>::createMapper(const QuadratureType& quad,
                                             GeometryType elementGeometry,
                                             integral_constant< bool, false > )
    {
      const MapperVectorType pointMappers =
        PointProvider<ct, dim, codim>::getMappers(quad, elementGeometry);

      const int numFaces = pointMappers.size();

      QuadratureKeyType key ( elementGeometry, quad.id() );
      
      MapperIteratorType it
        = mappers_.insert(std::make_pair(key, CacheStorageType(numFaces))).first;

      for (int face = 0; face < numFaces; ++face)
        it->second.addMapper(pointMappers[face], face);

      return it;
    }
  
  } // namespace Fem

} // namespace Dune
