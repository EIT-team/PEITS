/**************************************************************************
 
  The dune-fem module is a module of DUNE (see www.dune-project.org).
  It is based on the dune-grid interface library 
  extending the grid interface by a number of discretization algorithms
  for solving non-linear systems of partial differential equations.

  Copyright (C) 2003 - 2013 Robert Kloefkorn
  Copyright (C) 2003 - 2010 Mario Ohlberger 
  Copyright (C) 2004 - 2013 Andreas Dedner
  Copyright (C) 2005        Adrian Burri
  Copyright (C) 2005 - 2012 Mirko Kraenkel
  Copyright (C) 2006 - 2013 Christoph Gersbacher
  Copyright (C) 2006 - 2013 Martin Nolte
  Copyright (C) 2011 - 2013 Tobias Malkmus

  The dune-fem module is free software; you can redistribute it and/or 
  modify it under the terms of the GNU General Public License as 
  published by the Free Software Foundation; either version 2 of 
  the License, or (at your option) any later version.

  The dune-fem module is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along
  with this program; if not, write to the Free Software Foundation, Inc.,
  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 
**************************************************************************/
#ifndef DUNE_FEM_QUADRATURE_CACHING_REGISTRY_HH
#define DUNE_FEM_QUADRATURE_CACHING_REGISTRY_HH

// system includes 
#include <cstddef>
#include <algorithm>
#include <list>

// dune-geometry includes 
#include <dune/geometry/type.hh>

// dune-fem includes
#include <dune/fem/misc/threads/threadmanager.hh>

namespace Dune 
{

  namespace Fem 
  {

    // QuadratureStorageRegistry
    // -------------------------

    class QuadratureStorageRegistry
    {
      typedef QuadratureStorageRegistry ThisType;

    public:
      struct StorageInterface
      {
        virtual ~StorageInterface () {}
        virtual void cacheQuadrature ( std::size_t id, std::size_t codim, std::size_t quadSize ) = 0;
        virtual GeometryType type () const = 0;
      };

    private:
      typedef std::list< StorageInterface * > StorageListType;

      struct QuadratureInfo
      {
        std::size_t id;
        std::size_t codim;
        std::size_t size;
        GeometryType type;
      };

      typedef std::list< QuadratureInfo > QuadratureInfoListType;

      static StorageListType &storageList ()
      {
        static StorageListType storageList;
        return storageList;
      }

      static QuadratureInfoListType &quadratureInfoList ()
      {
        static QuadratureInfoListType quadratureInfoList;
        return quadratureInfoList;
      }
      
    public:
      static void registerStorage ( StorageInterface &storage )
      {
        assert( ThreadManager::singleThreadMode() );
        storageList().push_back( &storage );

        const GeometryType type = storage.type();
        for( QuadratureInfoListType::iterator it = quadratureInfoList().begin(); it != quadratureInfoList().end(); ++it )
        {
          // only cache shape functions for quadratures with same geometry type 
          if( type == it->type )
            storage.cacheQuadrature( it->id, it->codim, it->size );
        }
      }

      static void unregisterStorage ( StorageInterface &storage )
      {
        assert( ThreadManager::singleThreadMode() );
        const StorageListType::iterator pos
          = std::find( storageList().begin(), storageList().end(), &storage );
        if( pos != storageList().end() )
          storageList().erase( pos );
      }

      template< class Quadrature >
      static void registerQuadrature ( const Quadrature &quadrature )
      {
        registerQuadrature( quadrature, quadrature.geometryType(), Quadrature::codimension );
      }

      template< class Quadrature >
      static void registerQuadrature ( const Quadrature &quadrature,
                                       const GeometryType &type, std::size_t codim )
      {
        assert( ThreadManager::singleThreadMode() );
        QuadratureInfo quadInfo = { quadrature.id(), codim, std::size_t( quadrature.nop() ), type };
        quadratureInfoList().push_back( quadInfo );

        for( typename StorageListType::iterator it = storageList().begin(); it != storageList().end(); ++it )
        {
          // only cache shape functions for quadratures with same geometry type 
          if( (*it)->type() == type )
            (*it)->cacheQuadrature( quadInfo.id, quadInfo.codim, quadInfo.size );
        }
      }
    };

  } // namespace Fem

} // namespace Dune

#endif // #ifndef DUNE_FEM_QUADRATURE_CACHING_REGISTRY_HH
