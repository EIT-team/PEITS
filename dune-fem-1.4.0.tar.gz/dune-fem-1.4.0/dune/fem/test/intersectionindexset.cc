/**************************************************************************
 
  The dune-fem module is a module of DUNE (see www.dune-project.org).
  It is based on the dune-grid interface library 
  extending the grid interface by a number of discretization algorithms
  for solving non-linear systems of partial differential equations.

  Copyright (C) 2003 - 2013 Robert Kloefkorn
  Copyright (C) 2003 - 2010 Mario Ohlberger 
  Copyright (C) 2004 - 2013 Andreas Dedner
  Copyright (C) 2005        Adrian Burri
  Copyright (C) 2005 - 2012 Mirko Kraenkel
  Copyright (C) 2006 - 2013 Christoph Gersbacher
  Copyright (C) 2006 - 2013 Martin Nolte
  Copyright (C) 2011 - 2013 Tobias Malkmus

  The dune-fem module is free software; you can redistribute it and/or 
  modify it under the terms of the GNU General Public License as 
  published by the Free Software Foundation; either version 2 of 
  the License, or (at your option) any later version.

  The dune-fem module is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along
  with this program; if not, write to the Free Software Foundation, Inc.,
  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 
**************************************************************************/
#undef NDEBUG
#ifdef YASPGRID
#define SKIP_TEST
#endif

// without this define this code won't compile for Yasp
#define ENABLE_ADAPTIVELEAFINDEXSET_FOR_YASPGRID

#include <config.h>
#include <iostream>

#include <dune/fem/gridpart/hierarchicgridpart.hh>
#include <dune/fem/gridpart/adaptiveleafgridpart.hh>
#include <dune/fem/misc/gridwidth.hh>

#if defined  USE_FILTEREDGRID 
#include <dune/fem/gridpart/filteredgrid.hh>
#endif

#include "testgrid.hh"
#include "dfspace.hh"
#include "exactsolution.hh"

using namespace Dune;
using namespace Fem;

#ifndef SKIP_TEST
typedef GridSelector::GridType MyGridType;
// typedef HierarchicGridPart< MyGridType >  ContainedGridPartType;
typedef IntersectionAdaptiveLeafGridPart< MyGridType > ContainedGridPartType;

// use filtered grid for testing 
#if defined  USE_FILTEREDGRID 
  typedef RadialFilter< ContainedGridPartType > FilterType;
  typedef FilteredGridPart<ContainedGridPartType, FilterType, true > GridPartType;
#else
  typedef ContainedGridPartType GridPartType;
#endif

template <class GridPartType> 
void checkIntersectionIndexSet( const GridPartType& gridPart ) 
{
  enum { dim = GridPartType :: GridType :: dimension };
  typedef typename GridPartType :: IndexSetType IndexSetType ;
  const IndexSetType& indexSet = gridPart.indexSet();

  typedef typename GridPartType :: template Codim< 0 > :: IteratorType IteratorType ;
  typedef typename IteratorType :: Entity  EntityType ;
  typedef typename GridPartType :: IntersectionIteratorType IntersectionIteratorType;
  typedef typename GridPartType :: IntersectionType         IntersectionType;
  
  int count = 0 ;
  const IteratorType endit = gridPart.template end<0> ();
  for( IteratorType it = gridPart.template begin<0> ();
       it != endit; ++it ) 
  {
    const EntityType& entity = *it;
    const IntersectionIteratorType endiit = gridPart.iend( entity );
    for( IntersectionIteratorType iit = gridPart.ibegin( entity );
         iit != endiit ; ++ iit ) 
    {
      const IntersectionType&  intersection = *iit ; 

      const int index = indexSet.index( *iit ); 
      std::cout << index << " index of intersection " << std::endl;
      ++ count ;
      if( intersection.boundary() ) 
        ++ count ;
    }
  }

  const size_t noIntersections = count / 2;
  std::cout << indexSet.size( dim + 1 ) << " size " << std::endl;
  if( noIntersections != indexSet.size( dim + 1 ) ) 
  {
    std::cerr << "ERROR: size of intersection set wrong! " << std::endl;
  }
}
#endif

// main program 
int main(int argc, char ** argv) 
{
  MPIManager :: initialize( argc, argv );
  try
  {
#ifndef SKIP_TEST
    MyGridType &grid = TestGrid :: grid();
    const int step = TestGrid :: refineStepsForHalf();
    grid.globalRefine( 2*step );

    GridPartType gridPart( grid );
    // add check for grid width 
    std::cout << "Grid width: " 
      << GridWidth :: calcGridWidth( gridPart ) << std::endl; 

    checkIntersectionIndexSet( gridPart );
#endif
    return 0;
  }
  catch( Exception e )
  {
    std :: cerr << e.what() << std :: endl;
    return 1;
  }
}
