/**************************************************************************
 
  The dune-fem module is a module of DUNE (see www.dune-project.org).
  It is based on the dune-grid interface library 
  extending the grid interface by a number of discretization algorithms
  for solving non-linear systems of partial differential equations.

  Copyright (C) 2003 - 2013 Robert Kloefkorn
  Copyright (C) 2003 - 2010 Mario Ohlberger 
  Copyright (C) 2004 - 2013 Andreas Dedner
  Copyright (C) 2005        Adrian Burri
  Copyright (C) 2005 - 2012 Mirko Kraenkel
  Copyright (C) 2006 - 2013 Christoph Gersbacher
  Copyright (C) 2006 - 2013 Martin Nolte
  Copyright (C) 2011 - 2013 Tobias Malkmus

  The dune-fem module is free software; you can redistribute it and/or 
  modify it under the terms of the GNU General Public License as 
  published by the Free Software Foundation; either version 2 of 
  the License, or (at your option) any later version.

  The dune-fem module is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along
  with this program; if not, write to the Free Software Foundation, Inc.,
  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 
**************************************************************************/
#ifndef DUNE_FEM_TEST_DFSPACE_HH
#define DUNE_FEM_TEST_DFSPACE_HH

#include <dune/fem/misc/double.hh>

#include <dune/fem/space/discontinuousgalerkin.hh>
#include <dune/fem/space/common/dofstorage.hh>
#if defined USE_COMBINEDSPACE
#  include <dune/fem/space/combinedspace.hh>
#endif
#if defined USE_LAGRANGESPACE
#  include <dune/fem/space/lagrange.hh>
#endif
#if defined USE_FVSPACE
#  include <dune/fem/space/finitevolume.hh>
#endif


#ifndef POLORDER
#  define POLORDER 2
#endif

#ifndef DIMRANGE
#  define DIMRANGE 4
#endif


namespace Dune
{

  namespace Fem
  {

  typedef FunctionSpace< double, double, GridSelector::dimworld, DIMRANGE >
    TestFunctionSpace;


  template< class GridPart >
  struct TestDiscreteFunctionSpaceTraits
  {
    enum { polOrder = POLORDER };

    typedef GridPart GridPartType;

    typedef TestFunctionSpace FunctionSpaceType;
    
    typedef DiscontinuousGalerkinSpace
      < FunctionSpaceType :: ScalarFunctionSpaceType, GridPartType, polOrder >
      SingleDiscreteFunctionSpaceType;
    enum { dimRange = FunctionSpaceType :: dimRange };

#ifdef USE_VARIABLEBASE
    static const DofStoragePolicy policy = VariableBased;
#else
    static const DofStoragePolicy policy = PointBased;
#endif

#if defined USE_COMBINEDSPACE
    typedef Fem::CombinedSpace< SingleDiscreteFunctionSpaceType, dimRange, policy >
      DiscreteFunctionSpaceType;
#elif defined USE_FVSPACE
    typedef FiniteVolumeSpace< FunctionSpaceType, GridPartType, 0 >
      DiscreteFunctionSpaceType;
#elif defined USE_LAGRANGESPACE
#warning USING LAGRANGE
    typedef LagrangeDiscreteFunctionSpace< FunctionSpaceType, GridPartType, polOrder >
      DiscreteFunctionSpaceType;
#elif defined USE_LEGENDRESPACE 
    typedef LegendreDiscontinuousGalerkinSpace< FunctionSpaceType, GridPartType, polOrder >
      DiscreteFunctionSpaceType;
#elif defined USE_HIERARCHCILEGENDRESPACE 
    typedef HierarchicLegendreDiscontinuousGalerkinSpace< FunctionSpaceType, GridPartType, polOrder >
      DiscreteFunctionSpaceType;
#else
    typedef DiscontinuousGalerkinSpace< FunctionSpaceType, GridPartType, polOrder >
      DiscreteFunctionSpaceType;
#endif
  };


  template< class GridPart >
  class TestDiscreteFunctionSpace
  : public TestDiscreteFunctionSpaceTraits< GridPart > :: DiscreteFunctionSpaceType
  {
  public:
    typedef GridPart GridPartType;

  private:
    typedef typename TestDiscreteFunctionSpaceTraits< GridPartType >
      :: DiscreteFunctionSpaceType
      BaseType;

  public:
    TestDiscreteFunctionSpace ( GridPartType &gridPart )
    : BaseType( gridPart )
    {}
  };

  }
}

#endif
