/**************************************************************************
 
  The dune-fem module is a module of DUNE (see www.dune-project.org).
  It is based on the dune-grid interface library 
  extending the grid interface by a number of discretization algorithms
  for solving non-linear systems of partial differential equations.

  Copyright (C) 2003 - 2013 Robert Kloefkorn
  Copyright (C) 2003 - 2010 Mario Ohlberger 
  Copyright (C) 2004 - 2013 Andreas Dedner
  Copyright (C) 2005        Adrian Burri
  Copyright (C) 2005 - 2012 Mirko Kraenkel
  Copyright (C) 2006 - 2013 Christoph Gersbacher
  Copyright (C) 2006 - 2013 Martin Nolte
  Copyright (C) 2011 - 2013 Tobias Malkmus

  The dune-fem module is free software; you can redistribute it and/or 
  modify it under the terms of the GNU General Public License as 
  published by the Free Software Foundation; either version 2 of 
  the License, or (at your option) any later version.

  The dune-fem module is distributed in the hope that it will be useful, 
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along
  with this program; if not, write to the Free Software Foundation, Inc.,
  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 
**************************************************************************/
#ifndef DUNE_FEM_COMMON_TYPEINDEXEDTUPLE_HH
#define DUNE_FEM_COMMON_TYPEINDEXEDTUPLE_HH

#include <dune/common/tuples.hh>
#include <dune/common/tupleutility.hh>

#include <dune/fem/common/tupleutility.hh>

namespace Dune
{

  // TypeIndexedTuple
  // ----------------

  /*
   * \brief Please doc me. 
   */
  template< class Tuple, class Types >
  class TypeIndexedTuple 
  {
    template< class T >
    struct Position
    {
      static const int value = Dune::FirstTypeIndex< Types, T >::value; 
    };

  public:
    template< class T >
    struct Value
    {
      typedef typename Dune::tuple_element< Position< T >::value, Tuple >::type Type;
    };

    template< class T >
    struct DUNE_DEPRECATED Get
    : public Value< T >
    {};

    explicit TypeIndexedTuple ( const Tuple &tuple = Tuple() )
    : tuple_( tuple )
    {}

    //! \brief please doc me
    template< class T >
    typename Value< T >::Type &at ()
    {
      return Dune::get< Position< T >::value >( tuple_ );
    }

    //! \brief please doc me
    template< class T >
    const typename Value< T >::Type &at () const
    {
      return Dune::get< Position< T >::value >( tuple_ );
    }

    template< class T >
    DUNE_DEPRECATED typename Value< T >::Type &get () { return at< T >(); }

    template< class T >
    DUNE_DEPRECATED const typename Value< T >::Type &get () const { return at< T >(); }

    //! \brief please doc me
    template< class T >
    typename Value< T >::Type &operator[] ( const T & )
    {
      return at< T >();
    }

    //! \brief please doc me
    template< class T >
    const typename Value< T >::Type &operator[] ( const T & ) const
    {
      return at< T >();
    }

    //! \brief cast to Tuple
    operator Tuple & () { return tuple_; }

    //! \brief cast to const Tuple
    operator const Tuple & () const { return tuple_; }

  private:
    Tuple tuple_;
  };



  // get for TypeIndexedTuple
  // ------------------------

  template< int i, class Tuple, class Types >
  typename tuple_element< i, Tuple >::type &
  get ( Dune::TypeIndexedTuple< Tuple, Types > &tuple )
  {
    return get< i >( static_cast< Tuple & >( tuple ) );
  }

  template< int i, class Tuple, class Types >
  const typename tuple_element< i, Tuple >::type &
  get ( const Dune::TypeIndexedTuple< Tuple, Types > &tuple )
  {
    return get< i >( static_cast< const Tuple & >( tuple ) );
  }

} // namespace Dune



// Some Specializations for Tuple Access
// -------------------------------------

DUNE_OPEN_TUPLE_NAMESPACE

  // tuple_element for TypeIndexedTuple
  // ----------------------------------

  template< size_t i, class Tuple, class Types >
  struct tuple_element< i, Dune::TypeIndexedTuple< Tuple, Types > > 
  {
    typedef typename tuple_element< i, Tuple >::type type;
  };

DUNE_CLOSE_TUPLE_NAMESPACE

#endif // #ifndef DUNE_FEM_COMMON_TYPEINDEXEDTUPLE_HH
